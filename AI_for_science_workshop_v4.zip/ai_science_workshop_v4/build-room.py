from pathlib import Path
import base64, shutil
root=Path(__file__).resolve().parent
src=root/'room-src'
html=(src/'room.html').read_text().replace('/*STYLE*/',(src/'room.css').read_text()).replace('/*SCRIPT*/',(src/'room.js').read_text())
(root/'public/room/index.html').write_text(html)
# The standalone review embeds the small template. It never simulates shared storage.
if (root/'public/room/template.pptx').exists():
    b64=base64.b64encode((root/'public/room/template.pptx').read_bytes()).decode()
    preview=html.replace('href="template.pptx"','href="data:application/vnd.openxmlformats-officedocument.presentationml.presentation;base64,'+b64+'"')
else:
    preview=html
preview=preview.replace('<a href="../" class="back-course">Full workshop ↗</a>', '<span class="back-course" title="The full course is included in the project ZIP.">Full course in project ZIP</span>')
preview=preview.replace('href="../" class="brand"', 'href="#" class="brand"')
(root.parent/'AI_for_science_room_review.html').write_text(preview)
# Preserve all existing course sections, progress keys and original downloads.
index=root/'public/index.html'
text=index.read_text()
if 'room/index.html' not in text:
    text=text.replace('<nav>','<nav><a href="room/index.html">New: one idea, one slide</a>',1)
    marker='<h2>Follow the teaching route</h2>'
    card='<div class="route-card" style="margin:22px 0;padding:24px"><span class="eyebrow">New room exercise · About 20 minutes</span><h2>One idea. One shared slide.</h2><p>Use Plan mode for an interview, approve a bounded use case, create a PowerPoint slide through computer use, then contribute to the shared workshop room.</p><a class="btn primary" href="room/index.html">Open the slide exercise →</a></div>'
    text=text.replace(marker,card+marker,1)
    index.write_text(text)
shutil.copytree(root/'public',root/'dist',dirs_exist_ok=True)
print('Built participant page, extended course and standalone offline review.')
