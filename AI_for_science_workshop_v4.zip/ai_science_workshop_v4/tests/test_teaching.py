#!/usr/bin/env python3
"""Additional v3 teaching-view tests; document injection, not hosted navigation."""
from pathlib import Path
from decimal import Decimal
import base64,csv,hashlib,io,json,os,sys,urllib.request,urllib.error,zipfile
from collections import Counter
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];PUB=ROOT/'public';OUT=ROOT/'tests/artifacts';OUT.mkdir(exist_ok=True)
HTML=(PUB/'index.html').read_text();soup=BeautifulSoup(HTML,'html.parser');topics=json.loads(soup.find(id='teaching-data').string)
results=[]
def check(name,ok,detail=''):
 results.append(dict(test=name,passed=bool(ok),detail=str(detail)));print(('PASS ' if ok else 'FAIL ')+name,flush=True)
check('30 teaching topics reuse existing chapter components',len(topics)==30 and len(soup.select('.teaching-topic'))==30)
check('Suggested topic timings total exactly 90 minutes',sum(t['minutes'] for t in topics)==90)
expected={'why':10,'agents':18,'usage':10,'privacy':12,'cytometry':28,'verification':12}
check('Chapter timings match all six presentation slots',all(sum(t['minutes'] for t in topics if t['chapter']==c)==n for c,n in expected.items()))
ids=[e['id'] for e in soup.select('[id]')];check('All DOM IDs remain unique',len(ids)==len(set(ids)))
with zipfile.ZipFile(ROOT/'recovery/saved_site_v2.zip') as z:
 old=next(n for n in z.namelist() if n.endswith('/public/index.html'))
 before=BeautifulSoup(z.read(old),'html.parser')
 legacy_ids={e['id'] for e in before.select('[id]')}
 check('Every v2 deep-link target and existing control ID retained',legacy_ids.issubset(set(ids)),str(legacy_ids-set(ids)))
 oldfields={e['data-course-field'] for e in before.select('[data-course-field]')}
 check('Every previous course progress field retained',oldfields.issubset({e['data-course-field'] for e in soup.select('[data-course-field]')}))
 downloads=[n for n in z.namelist() if '/public/downloads/' in n and not n.endswith('/')]
 check('All 16 downloads also byte-identical to immediate v2 baseline',len(downloads)==16 and all((PUB/'downloads'/Path(n).name).read_bytes()==z.read(n) for n in downloads))
# Text in original prompts is never edited by the teaching additions.
for rnd in 'ABC':
 expectedprompt=(PUB/'downloads'/f'prompt_{rnd}.txt').read_text()
 check('Displayed prompt '+rnd+' remains exact',soup.find(id='prompt-'+rnd).get_text()==expectedprompt)
check('Statistical plan is outside all six descriptive practical sections',soup.find(id='prepared-plan').find_parent('section')['id']=='prepared')
check('Prepared raw figures are unchanged embedded assets',all(base64.b64decode(soup.select('[data-zoom] img')[i]['src'].split(',',1)[1])==(PUB/'assets'/f'figure-{i+1}.png').read_bytes() for i in range(3)))
check('New teaching outline embedded for single-file downloads','teaching_outline.md' in json.loads(soup.find(id='course-data').string)['assets'])
# Every internal anchor, including the 50-position content map, resolves.
anchors=[a['href'][1:] for a in soup.select('a[href^="#"]') if a['href']!='#']
check('All in-page links resolve',all(a in ids for a in anchors),len(anchors))
rows=list(csv.DictReader((PUB/'downloads/data.csv').open()))
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1440,'height':1000},accept_downloads=True);page.set_default_timeout(4000)
 errors=[];requests=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:requests.append(r.url))
 page.set_content(HTML,wait_until='domcontentloaded');page.wait_for_timeout(100)
 def go(id):
  page.evaluate('(id)=>{location.hash=id;window.WorkshopCourse.route()}',id);page.wait_for_timeout(30)
 page.locator('[data-start-guided]').click();page.wait_for_timeout(100)
 check('Guided entry opens the first teaching topic in focus mode',page.locator('body').get_attribute('data-teaching-mode')=='focus' and page.locator('.teaching-topic:visible').count()==1 and page.locator('#teach-why-1').is_visible())
 for idx,t in enumerate(topics):
  if idx:page.locator(f'#{topics[idx-1]["chapter"]} [data-teach-next]').click();page.wait_for_timeout(30)
  check('Sequential teaching navigation: '+t['id'],page.locator('.teaching-topic:visible').count()==1 and page.locator('#'+t['id']).is_visible())
 check('Closing topic offers a return to course home','Finish at course home' in page.locator('#verification [data-teach-next]').inner_text())
 page.locator('#verification [data-teach-next]').click();page.wait_for_timeout(30);check('Guided sequence closes at course home',page.locator('#course').is_visible())
 go('skill-inspector');check('Deep link reveals the correct otherwise hidden topic',page.locator('#teach-agents-7').is_visible() and page.locator('.teaching-topic:visible').count()==1)
 page.locator('#agents [data-teach-prev]').click();page.wait_for_timeout(30);check('Previous topic moves backwards within chapter',page.locator('#teach-agents-6').is_visible())
 page.locator('#topic-select-agents').select_option('teach-agents-3');page.wait_for_timeout(30);check('Topic dropdown jumps without duplicate content',page.locator('#plan-mode').is_visible() and page.locator('#brief-builder:visible').count()==0)
 page.locator('#teach-agents-3-title').focus();page.keyboard.press('ArrowRight');page.wait_for_timeout(30);check('Arrow key advances from teaching heading',page.locator('#teach-agents-4').is_visible())
 go('brief-builder');page.locator('#brief-outcome').fill('Audit identifiers');page.locator('#brief-outcome').focus();hashbefore=page.evaluate('location.hash');page.keyboard.press('ArrowLeft');check('Arrow keys do not navigate while editing a field',page.evaluate('location.hash')==hashbefore)
 # A visible keyboard focus indicator, not solely a colour change.
 page.locator('#agents [data-teaching-view="read"]').focus();focus=page.locator('#agents [data-teaching-view="read"]').evaluate('(e)=>({style:getComputedStyle(e).outlineStyle,width:getComputedStyle(e).outlineWidth})')
 check('Keyboard focus has a visible outline',focus['style']!='none' and focus['width']!='0px',focus)
 page.keyboard.press('Enter');check('Read-whole-chapter restores all topics',page.locator('#agents .teaching-topic:visible').count()==7)
 go('writing-evidence');check('Dated writing evidence opens via direct link',page.locator('#writing-evidence').get_attribute('open') is not None and '1,194,287' in page.locator('#writing-evidence').inner_text())
 go('cytometry');
 for key,v in [('donor','D01'),('treatment','Vehicle'),('stimulation','Unstimulated')]:page.locator('#trace-'+key).select_option(v)
 actual=sum(Decimal(r['activation_percent']) for r in rows if r['donor_id']=='D01' and r['treatment']=='Vehicle' and r['stimulation']=='Unstimulated')/2
 page.locator('#trace-your-mean').fill(str(actual));page.locator('#check-trace-mean').click();check('Participant arithmetic accepts actual CSV mean','Matches the supplied' in page.locator('#trace-arithmetic-feedback').inner_text())
 page.locator('#trace-your-mean').fill('99');page.locator('#check-trace-mean').click();check('Participant arithmetic rejects incorrect mean','Does not match' in page.locator('#trace-arithmetic-feedback').inner_text())
 page.locator('#trace-your-mean').fill('');page.locator('#check-trace-mean').click();check('Empty arithmetic input is not treated as zero','Enter a percentage' in page.locator('#trace-arithmetic-feedback').inner_text())
 page.locator('#trace-your-mean').fill(str(actual));page.locator('#check-trace-mean').click();page.locator('#trace-donor').select_option('D02');check('Changing a source selection clears stale arithmetic verdict',page.locator('#trace-arithmetic-feedback').inner_text()=='')
 go('resources');
 with page.expect_download() as pending:page.locator('[data-course-download="teaching_outline.md"]').click()
 dest=OUT/'teaching_outline.md';pending.value.save_as(dest);check('Teaching-outline download matches built file',dest.read_bytes()==(PUB/'course-downloads/teaching_outline.md').read_bytes())
 go('why');page.locator('#why [data-teaching-view="focus"]').click();page.wait_for_timeout(40)
 go('resources');
 with page.expect_download() as pending:page.locator('#export-progress').click()
 dest=OUT/'v3_progress.json';pending.value.save_as(dest);payload=json.loads(dest.read_text());check('Focus preference exported with original compatible progress format',payload['version']==2 and payload['course']['fields']['teaching-view']=='focus')
 page.on('dialog',lambda d:d.accept());page.locator('#reset-course').click();check('Reset restores default whole-chapter reading view',page.locator('body').get_attribute('data-teaching-mode')=='read')
 page.locator('#import-progress').set_input_files(dest);page.wait_for_timeout(100);check('Progress import restores the teaching preference without new storage key',page.locator('body').get_attribute('data-teaching-mode')=='focus')
 page.wait_for_timeout(4200)
 invalid=dict(payload);invalid['course']={'fields':dict(payload['course']['fields'],**{'trace-donor':'NOT_A_DONOR'})}
 bad=OUT/'invalid_selection.json';bad.write_text(json.dumps(invalid));page.locator('#import-progress').set_input_files(bad);page.wait_for_timeout(80)
 check('Invalid saved selector is rejected before mutating the current state','Import not applied' in page.locator('#import-status').inner_text() and page.locator('#trace-donor').input_value()=='D02')
 for width in [1440,768,390,375]:
  page.set_viewport_size({'width':width,'height':1000 if width>700 else 844})
  failures=[]
  for t in topics:
   go(t['id']);
   if page.evaluate('document.documentElement.scrollWidth>innerWidth+1'):failures.append(t['id'])
  check(f'All 30 focused topics fit at {width}px without page overflow',not failures,failures)
  if width in [1440,390]:
   go('teach-agents-1');page.evaluate("document.activeElement.blur();window.scrollTo({top:0,behavior:'instant'})");page.screenshot(path=str(OUT/f'focus_agents_{width}.png'),full_page=True)
   go('trace-point');page.evaluate("document.activeElement.blur();window.scrollTo({top:0,behavior:'instant'})");page.screenshot(path=str(OUT/f'focus_trace_{width}.png'),full_page=True)
 check('No runtime errors from new teaching interactions',not errors,errors)
 check('New teaching interactions make no automatic network requests',not [u for u in requests if u.startswith(('https://','http://'))],requests)
 browser.close()
report={'date':'2026-09-16','suite':'Teaching extension','harness':'Chromium Playwright document injection; no normal hosted or file URL navigation. Real browser controls, Blob downloads and in-memory progress fallback.', 'passed':sum(x['passed'] for x in results),'total':len(results),'results':results}
(ROOT/'TEACHING_TEST_RESULTS.json').write_text(json.dumps(report,indent=2))
print(f"\n{report['passed']} / {report['total']} passed")
if report['passed']!=report['total']:sys.exit(1)
