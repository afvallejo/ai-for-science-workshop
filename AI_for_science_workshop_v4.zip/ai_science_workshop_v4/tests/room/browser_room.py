"""Real Chromium UI exercised against the FastAPI app via an explicit request bridge.
The environment blocks browser URL navigation. Documents are injected; fetch
requests are serialised to the actual application, not simulated responses.
"""
from pathlib import Path
import os, sys, tempfile, base64, json, io
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
os.environ['WORKSHOP_DATA']=tempfile.mkdtemp(prefix='workshop-browser-')
os.environ['WORKSHOP_HOST_KEY']='browser-test-only-key-never-deploy-123456789'
from fastapi.testclient import TestClient
from room_app import app, HOST_KEY
from playwright.sync_api import sync_playwright
from pptx import Presentation
OUT=ROOT/'tests/room/artifacts';OUT.mkdir(exist_ok=True)
HTML=(ROOT/'public/room/index.html').read_text()
results=[]
def check(name,ok,detail=''):
 results.append({'test':name,'passed':bool(ok),'detail':detail});print(('PASS ' if ok else 'FAIL ')+name,flush=True)
BRIDGE='''<script>window.fetch=async function(input,opt={}){
const payload={url:String(input),method:opt.method||'GET',headers:Object.fromEntries(new Headers(opt.headers||{})),fields:[],files:[],body:null};
if(opt.body instanceof FormData){for(const [name,value]of opt.body.entries()){if(value instanceof File){const bytes=new Uint8Array(await value.arrayBuffer());let s='';for(let i=0;i<bytes.length;i+=8192)s+=String.fromCharCode(...bytes.subarray(i,i+8192));payload.files.push({name,filename:value.name,type:value.type,data:btoa(s)});}else payload.fields.push([name,String(value)]);}}
else if(opt.body!=null)payload.body=String(opt.body);
const out=await window.__realApi(payload);const bytes=Uint8Array.from(atob(out.data),c=>c.charCodeAt(0));return new Response(bytes,{status:out.status,headers:out.headers});};</script>'''

def bridged_page(browser):
 context=browser.new_context(viewport={'width':1440,'height':1000},accept_downloads=True)
 page=context.new_page();page.set_default_timeout(4500);errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 client=TestClient(app)
 def transport(v):
  kw={'headers':v['headers']}
  if v['files']:
   kw['files']=[(f['name'],(f['filename'],base64.b64decode(f['data']),f['type'] or 'application/octet-stream')) for f in v['files']];kw['data']=dict(v['fields'])
  elif v['body'] is not None:kw['content']=v['body']
  r=client.request(v['method'],v['url'],**kw)
  return {'status':r.status_code,'headers':dict(r.headers),'data':base64.b64encode(r.content).decode()}
 page.expose_function('__realApi',transport)
 page.set_content(HTML.replace('<script>',BRIDGE+'<script>',1),wait_until='domcontentloaded')
 page.wait_for_function('state.online===true')
 return page,errors

with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
 host,errors=bridged_page(browser)
 check('Browser connected to real API through disclosed test bridge','connected' in host.locator('#connection-text').inner_text())
 host.screenshot(path=str(OUT/'desktop_exercise.png'),full_page=True)
 check('Initial slide creation disabled pending approval',host.locator('#copy-create').is_disabled())
 host.locator('#tab-1').click()
 values={'brief-title':'Check sample IDs','brief-science':'Transcriptomics','brief-task':'Flag inconsistent sample IDs','brief-check':'A synthetic test set','brief-risk':'No automatic corrections'}
 for k,v in values.items():host.locator('#'+k).fill(v)
 host.locator('#approve-plan').check();host.locator('#tab-2').click()
 check('Complete approved brief enables action prompt',host.locator('#copy-create').is_enabled())
 check('Creation prompt requires actual app operation and no code', 'Do not silently substitute Python' in host.locator('#create-prompt').inner_text())
 host.locator('#tab-1').click();host.locator('#brief-task').fill('Flag missing identifiers')
 check('Editing the brief invalidates approval',not host.locator('#approve-plan').is_checked() and host.locator('#copy-create').is_disabled())
 host.locator('#tab-0').focus();host.keyboard.press('ArrowRight')
 check('Keyboard step tabs work',host.locator('#tab-1').get_attribute('aria-selected')=='true')
 host.locator('[data-view="host"].nav-btn').click();host.locator('#server-key').fill(HOST_KEY);host.locator('#create-room-btn').click();host.wait_for_function('state.room && state.room.host')
 code=host.locator('#host-code').inner_text();check('Facilitator creates a real eight-character room',len(code)==8)
 host.screenshot(path=str(OUT/'host_empty.png'),full_page=True)
 participants=[]
 for ix,fixture in enumerate(['sample_A.pptx','sample_B.pptx']):
  pg,errs=bridged_page(browser);participants.append((pg,errs));pg.locator('#room-code').fill(code);pg.locator('#join-form button').click();pg.wait_for_function('state.room!==null')
  pg.locator('#tab-3').click();pg.locator('#alias').fill('Participant '+str(ix+1));pg.locator('#idea-title').fill('Idea '+str(ix+1));pg.locator('#method').select_option('Computer use');pg.locator('#deck').set_input_files(str(ROOT/'tests/room/fixtures'/fixture));pg.locator('#consent').check();pg.locator('#submit-slide').click();pg.wait_for_function('state.receipt!==null')
  check('Independent participant '+str(ix+1)+' receives server receipt',bool(pg.evaluate('state.receipt.id')))
  check('Sharing notice names room '+str(ix+1),code in pg.locator('#share-prompt').inner_text())
  if ix==0:pg.screenshot(path=str(OUT/'participant_receipt.png'),full_page=True)
 host.evaluate('refreshRoom(true)');host.wait_for_function('state.submissions.length===2')
 check('Host sees both independent participants',host.locator('.host-row').count()==2)
 host.screenshot(path=str(OUT/'host_populated.png'),full_page=True)
 with host.expect_download() as download:
  host.locator('#export-deck').click()
 dest=OUT/'browser_export.pptx';download.value.save_as(str(dest))
 check('Export button downloads two editable slides',len(Presentation(dest).slides)==2)
 host.locator('[data-view="gallery"].nav-btn').click();check('Gallery reflects real submissions',host.locator('#gallery-count').inner_text()=='2')
 check('Text-only preview is honestly labelled',host.locator('.text-preview').count()==2 and 'NOT A SLIDE RENDERING' in host.locator('.text-preview').first.inner_text())
 host.locator('#present').click();check('Presenter opens actual contribution',host.locator('#presenter').is_visible());host.locator('#next-slide').click();check('Presenter moves to second contribution','2 / 2' in host.locator('#presenter-position').inner_text());host.locator('#close-presenter').click()
 host.screenshot(path=str(OUT/'gallery.png'),full_page=True)
 p1=participants[0][0];p1.locator('#submit-slide').click();p1.wait_for_function('state.receipt.replaced===true');check('Resubmission replaces rather than duplicates',p1.evaluate('state.receipt.replaced'))
 host.locator('[data-view="host"].nav-btn').click();host.locator('#toggle-room').click();host.wait_for_function('state.room.accepting===false');p1.evaluate('refreshRoom(true)');check('Closed room disables participant upload',p1.locator('#submit-slide').is_disabled())
 for width in [768,390,375]:
  host.set_viewport_size({'width':width,'height':900})
  for view in ['exercise','gallery','host']:
   host.evaluate('(v)=>showView(v)',view)
   if view=='exercise':
    for step in range(4):
     host.evaluate('(n)=>setStep(n,false)',step)
     check(f'No horizontal overflow {width}px step {step+1}',host.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
   else:check(f'No horizontal overflow {width}px {view}',host.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
  host.evaluate("showView('exercise');setStep(0,false)");host.screenshot(path=str(OUT/f'mobile_{width}.png'),full_page=True)
 check('No unhandled JavaScript errors across three sessions',not errors and all(not e for _,e in participants),str(errors)+str([e for _,e in participants]))
 # Native blocked storage/offline path: no successful server or simulated upload.
 offline=browser.new_page(viewport={'width':1280,'height':900});offline_errors=[];offline.on('pageerror',lambda e:offline_errors.append(str(e)))
 offline.set_content(HTML,wait_until='domcontentloaded');offline.wait_for_timeout(150)
 check('Offline review stays honest about disconnected storage',not offline.evaluate('state.online') and offline.locator('#submit-slide').is_disabled())
 check('Offline planning prompt works even with blocked storage','Ask one question at a time' in offline.locator('#plan-prompt').inner_text() and not offline_errors)
 browser.close()
report={'version':'4.0.0','date':'2026-09-17','method':__doc__,'passed':sum(r['passed'] for r in results),'total':len(results),'results':results}
(ROOT/'ROOM_BROWSER_TESTS.json').write_text(json.dumps(report,indent=2))
print(f"RESULT {report['passed']}/{report['total']}")
if report['passed']!=report['total']:raise SystemExit(1)
