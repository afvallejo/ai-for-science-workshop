from pathlib import Path
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from PIL import Image, ImageDraw
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'tests/room/fixtures';OUT.mkdir(exist_ok=True)
W,H=12192000,6858000

def box(slide,x,y,w,h,text,size=22,bold=False,colour='102D38'):
    shape=slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    frame=shape.text_frame;frame.word_wrap=True
    frame.margin_left=0;frame.margin_right=0;frame.margin_top=0;frame.margin_bottom=0
    for i,line in enumerate(text.split('\n')):
        p=frame.paragraphs[0] if i==0 else frame.add_paragraph()
        p.text=line;p.font.name='Arial';p.font.size=Pt(size);p.font.bold=bold;p.font.color.rgb=RGBColor.from_string(colour)
    return shape

def make(path,title,items,alias='Your display name or alias',image=False,notes=False):
    p=Presentation();p.slide_width=W;p.slide_height=H;s=p.slides.add_slide(p.slide_layouts[6])
    s.background.fill.solid();s.background.fill.fore_color.rgb=RGBColor(255,255,255)
    box(s,.65,.4,8,.3,'AI FOR SCIENCE  /  MY PROPOSED USE CASE',12,True,'236B66')
    box(s,.65,.97,12,1.05,title,34,True)
    for i,(label,value) in enumerate(items):
        x=.65+(i%2)*6.25;y=2.38+(i//2)*1.87
        rect=s.shapes.add_shape(MSO_SHAPE.RECTANGLE,Inches(x),Inches(y),Inches(5.7),Inches(.02))
        rect.fill.solid();rect.fill.fore_color.rgb=RGBColor.from_string('CEDDD5');rect.line.fill.background()
        box(s,x,y+.17,5.7,.33,label.upper(),13,True,'236B66')
        box(s,x,y+.65,5.65,1.05,value,23)
    box(s,.65,6.78,10,.32,alias+'  |  Proposed use, not an established result',12,False,'587079')
    if image:
        picture=OUT/'small.png'
        im=Image.new('RGB',(240,160),'white');d=ImageDraw.Draw(im);d.rectangle((25,25,200,120),outline='black',width=4);d.line((30,100,185,45),fill='black',width=5);im.save(picture)
        s.shapes.add_picture(str(picture),Inches(11.9),Inches(.3),Inches(.72),Inches(.48))
    if notes:s.notes_slide.notes_text_frame.text='PRIVATE_SPEAKER_NOTE_SHOULD_BE_REMOVED'
    p.core_properties.author='' if path==ROOT/'public/room/template.pptx' else 'PRIVATE_AUTHOR_SHOULD_BE_REMOVED'
    p.save(path)

template=ROOT/'public/room/template.pptx'
make(template,'[One specific AI task in your science]',[
 ('My science','[Your research interest and scientific context]'),
 ('AI could help with','[One bounded task and a concrete output]'),
 ('I will verify by','[An independent check and a failure criterion]'),
 ('My boundary or risk','[What the AI must not do or decide]')])
make(OUT/'sample_A.pptx','Check sample IDs before analysis',[
 ('My science','Transcriptomics and reproducible analysis.'),('AI could help with','Flag missing or mismatched sample IDs.'),('I will verify by','Compare flags with a known synthetic test set.'),('My boundary or risk','No automatic corrections or patient information.')],alias='Example A',image=True,notes=True)
make(OUT/'sample_B.pptx','Build a checkable evidence table',[
 ('My science','Comparing published experimental methods.'),('AI could help with','Extract study design and stated limitations.'),('I will verify by','Check every entry against the full source.'),('My boundary or risk','No invented references or unsupported conclusions.')],alias='Example B')
p=Presentation(OUT/'sample_A.pptx');p.slides.add_slide(p.slide_layouts[6]);p.save(OUT/'two_slides.pptx')
p=Presentation(OUT/'sample_B.pptx');p.slide_width=Inches(10);p.slide_height=Inches(7.5);p.save(OUT/'wrong_size.pptx')
im=Image.new('RGB',(1280,720),'white');im.save(OUT/'preview.png')
print('Created template and test fixtures.')
