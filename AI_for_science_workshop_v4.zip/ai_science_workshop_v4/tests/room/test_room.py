"""Local API and native PowerPoint package tests. No external services required."""
from pathlib import Path
from io import BytesIO
from zipfile import ZipFile, ZIP_DEFLATED
import os, sys, json, hashlib, tempfile
import pytest
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
os.environ['WORKSHOP_DATA']=tempfile.mkdtemp(prefix='workshop-tests-')
os.environ['WORKSHOP_HOST_KEY']='test-only-server-key-not-for-deployment-123456'
from fastapi.testclient import TestClient
from pptx import Presentation
from room_app import app, HOST_KEY, db
from room_decks import validate_and_clean, clean_png, merge_decks, DeckError, xml, P
FIX=ROOT/'tests/room/fixtures'
A=(FIX/'sample_A.pptx').read_bytes(); B=(FIX/'sample_B.pptx').read_bytes()

def rewrite(raw, change):
    with ZipFile(BytesIO(raw)) as z: parts={n:z.read(n) for n in z.namelist()}
    change(parts)
    out=BytesIO()
    with ZipFile(out,'w',ZIP_DEFLATED) as z:
        for n,b in parts.items():z.writestr(n,b)
    return out.getvalue()

def upload(c,code,token='a'*32,raw=A,**options):
    data={'participant_token':token,'alias':'Researcher','title':'An AI idea','theme':'Data checks','method':'Computer use','consent':'yes'}
    data.update(options)
    return c.post(f'/api/rooms/{code}/submissions',data=data,files={'deck':('idea.pptx',raw,'application/octet-stream')})

@pytest.fixture
def room():
    c=TestClient(app)
    r=c.post('/api/rooms',json={'title':'Test workshop'},headers={'X-Facilitator-Key':HOST_KEY})
    assert r.status_code==200,r.text
    d=r.json(); code=d['code']; head={'Authorization':'Bearer '+d['owner_token']}
    yield c,code,head
    c.delete('/api/rooms/'+code,headers=head)
    c.close()

def test_two_independent_participants_and_native_merge(room):
    c,code,head=room
    r1=upload(c,code);assert r1.status_code==200,r1.text
    c2=TestClient(app)
    r2=upload(c2,code,'b'*32,B);assert r2.status_code==200,r2.text
    gallery=c2.get('/api/rooms/'+code).json();assert gallery['count']==2
    assert not gallery['host'];assert all('participant_hash' not in s and 'deck' not in s for s in gallery['submissions'])
    assert r1.json()['id']!=r2.json()['id'];assert r1.json()['shared']
    r=c.get(f'/api/rooms/{code}/export/pptx',headers=head);assert r.status_code==200,r.text
    assert r.headers['x-slide-count']=='2'
    p=Presentation(BytesIO(r.content));assert len(p.slides)==2
    texts=[[s.text for s in slide.shapes if s.has_text_frame] for slide in p.slides]
    assert any('Check sample IDs' in t for t in texts[0]);assert any('evidence table' in t for t in texts[1])
    assert len(p.slides[0].shapes)==16;assert len(p.slides[1].shapes)==15
    assert any(s.shape_type==13 for s in p.slides[0].shapes)
    (FIX/'combined_verified.pptx').write_bytes(r.content)
    r=c.get(f'/api/rooms/{code}/export/zip',headers=head);assert r.status_code==200
    with ZipFile(BytesIO(r.content)) as z:
        m=json.loads(z.read('manifest.json'));assert len(m['slides'])==2
        for s in m['slides']:assert hashlib.sha256(z.read(s['file'])).hexdigest()==s['sha256']

def test_duplicate_replaces_same_participant(room):
    c,code,head=room;a=upload(c,code).json();b=upload(c,code,raw=B).json()
    assert a['id']==b['id'];assert b['replaced'];assert c.get('/api/rooms/'+code).json()['count']==1
    assert 'evidence table' in c.get('/api/rooms/'+code).json()['submissions'][0]['slide_text']

def test_moderation_reordering_and_owner_only_export(room):
    c,code,head=room;a=upload(c,code).json();b=upload(c,code,'b'*32,B).json()
    assert c.get(f'/api/rooms/{code}/export/pptx').status_code==403
    assert c.patch(f'/api/rooms/{code}/submissions/{a["id"]}',json={'included':False}).status_code==403
    assert c.patch(f'/api/rooms/{code}/submissions/{a["id"]}',json={'included':False},headers=head).status_code==200
    assert c.get('/api/rooms/'+code).json()['count']==1
    assert c.get('/api/rooms/'+code,headers=head).json()['count']==2
    assert c.get(f'/api/rooms/{code}/submissions/{a["id"]}/pptx').status_code==404
    assert c.get(f'/api/rooms/{code}/submissions/{a["id"]}/pptx',headers=head).status_code==200
    assert c.patch('/api/rooms/'+code,json={'order':[b['id'],a['id']]},headers=head).status_code==200
    assert c.get('/api/rooms/'+code,headers=head).json()['submissions'][0]['id']==b['id']
    assert c.patch('/api/rooms/'+code,json={'order':[a['id']]},headers=head).status_code==409
    assert c.get(f'/api/rooms/{code}/export/pptx',headers=head).headers['x-slide-count']=='1'

def test_closing_withdrawal_and_room_deletion(room):
    c,code,head=room;a=upload(c,code).json()
    assert c.patch('/api/rooms/'+code,json={'accepting':False},headers=head).status_code==200
    assert upload(c,code,'b'*32).status_code==409
    assert c.delete(f'/api/rooms/{code}/submissions/{a["id"]}').status_code==403
    assert c.delete(f'/api/rooms/{code}/submissions/{a["id"]}',headers={'X-Participant-Token':'a'*32}).status_code==200
    assert c.get('/api/rooms/'+code).json()['count']==0
    assert c.patch('/api/rooms/'+code,json={'accepting':True},headers=head).status_code==200
    assert upload(c,code).status_code==200
    assert c.delete('/api/rooms/'+code,headers=head).status_code==200
    assert c.get('/api/rooms/'+code).status_code==404
    with db() as con:assert con.execute('SELECT COUNT(*) FROM submissions WHERE room=?',(code,)).fetchone()[0]==0

@pytest.mark.parametrize('file',['two_slides.pptx','wrong_size.pptx'])
def test_invalid_deck_returns_actionable_422(room,file):
    c,code,head=room;r=upload(c,code,raw=(FIX/file).read_bytes());assert r.status_code==422,r.text
    assert r.json()['detail'];assert c.get('/api/rooms/'+code).json()['count']==0

def test_required_consent_identity_and_file(room):
    c,code,head=room
    assert upload(c,code,consent='no').status_code==422
    assert upload(c,code,token='short').status_code==422
    assert upload(c,code,alias='').status_code==422
    assert upload(c,code,method='Fake automation').status_code==422
    assert upload(c,code,raw=b'not a ZIP').status_code==422

def test_cross_origin_and_invalid_json(room):
    c,code,head=room
    assert c.patch('/api/rooms/'+code,json={'accepting':False},headers={**head,'Origin':'https://unrelated.invalid'}).status_code==403
    for payload in ([],42,None):
        r=c.patch('/api/rooms/'+code,content=json.dumps(payload),headers={**head,'Content-Type':'application/json'})
        assert r.status_code==422,r.text
    r=c.patch('/api/rooms/'+code,content=b'bad json',headers=head);assert r.status_code==422

def test_notes_author_hyperlinks_removed():
    cleaned,text=validate_and_clean(A);assert 'sample IDs' in text
    with ZipFile(BytesIO(cleaned)) as z:
        assert not any('notes' in n.lower() or n.startswith('docProps/') for n in z.namelist())
        assert not any(b'PRIVATE_SPEAKER_NOTE' in z.read(n) or b'PRIVATE_AUTHOR' in z.read(n) for n in z.namelist())
    assert len(Presentation(BytesIO(cleaned)).slides)==1

def test_bad_size_xml_returns_validation_error():
    def change(p): p['ppt/presentation.xml']=p['ppt/presentation.xml'].replace(b'cx="12192000"',b'cx="invalid"')
    with pytest.raises(DeckError):validate_and_clean(rewrite(A,change))

@pytest.mark.parametrize('bad_name',['ppt/embeddings/evil.bin','ppt/vbaProject.bin','ppt/charts/chart1.xml','ppt/media/video.mp4'])
def test_unsupported_active_or_complex_parts_rejected(bad_name):
    with pytest.raises(DeckError):validate_and_clean(rewrite(A,lambda p:p.update({bad_name:b'payload'})))

def test_xml_entity_and_archive_traversal_rejected():
    with pytest.raises(DeckError):xml(b'<!DOCTYPE r [<!ENTITY e SYSTEM "file:///etc/passwd">]><r>&e;</r>')
    with pytest.raises(DeckError):validate_and_clean(rewrite(A,lambda p:p.update({'../escape.xml':b'<r/>'})))

def test_png_and_bad_png():
    good=clean_png((FIX/'preview.png').read_bytes());assert good.startswith(b'\x89PNG')
    with pytest.raises(DeckError):clean_png(b'not PNG')
    with pytest.raises(DeckError):clean_png((FIX/'small.png').read_bytes())

def test_static_assets_and_security_headers(room):
    c,code,head=room
    for path in ('/','/room/','/room/template.pptx','/downloads/data.csv'):
        r=c.get(path);assert r.status_code==200,path
    for path in ('/room_app.py','/.room-data/facilitator-key.txt','/README.md'):
        assert c.get(path).status_code==404
    assert c.get('/api/health').headers['cache-control']=='no-store'
    assert c.get('/room/').headers['x-content-type-options']=='nosniff'
