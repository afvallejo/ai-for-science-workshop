#!/usr/bin/env python3
"""Actual browser and preservation checks for the expanded workshop.
Chromium is loaded with set_content: this environment's policy blocks URL navigation.
Native downloads and blocked-storage fallback are exercised. A named localStorage
shim is used only for persistence/migration checks, clearly reported as such.
"""
from pathlib import Path
from decimal import Decimal
import base64, csv, hashlib, io, json, os, sys, zipfile
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];PUB=ROOT/'public'
OUT=ROOT/'tests'/'artifacts';OUT.mkdir(exist_ok=True)
HTML=(PUB/'index.html').read_text();SOUP=BeautifulSoup(HTML,'html.parser')
results=[]
def check(name, condition, detail=''):
    ok=bool(condition);results.append({'test':name,'passed':ok,'detail':str(detail)});print(('PASS ' if ok else 'FAIL ')+name,flush=True);return ok

def digest(b):return hashlib.sha256(b).hexdigest()
with zipfile.ZipFile(ROOT/'recovery/original_site_v1.zip') as z:
    entries={Path(n).name:z.read(n) for n in z.namelist() if '/public/downloads/' in n and not n.endswith('/')}
assets=json.loads(SOUP.find(id='workshop-assets').string)
check('All original download files byte-identical',len(entries)==16 and all((PUB/'downloads'/n).read_bytes()==v for n,v in entries.items()),f'{len(entries)} original files, including CSV, study context, prompts, skill and all ZIPs')
check('All original embedded download bytes preserved',set(assets)==set(entries) and all(base64.b64decode(assets[n]['base64'])==v for n,v in entries.items()))
for r in 'ABC':check(f'Exact round {r} prompt displayed',SOUP.find(id='prompt-'+r).get_text()==entries['prompt_'+r+'.txt'].decode())
check('Unchanged original skill display',(PUB/'downloads/SKILL.md').read_text() in SOUP.find(id='skill').get_text())
for r in 'ABC':
    with zipfile.ZipFile(io.BytesIO(entries[f'round_{r}.zip'])) as z:
        names=z.namelist();has_skill=any(n.endswith('SKILL.md') for n in names)
        check(f'Round {r} skill isolation',has_skill==(r!='A'))
        check(f'Round {r} original CSV',any(z.read(n)==entries['data.csv'] for n in names if n.endswith('data.csv')))
ids=[x['id'] for x in SOUP.select('[id]')]
check('No duplicate HTML IDs',len(ids)==len(set(ids)))
internal=[a['href'][1:] for a in SOUP.select('a[href^="#"]') if a['href']!='#']
check('All internal section links resolve',all(x in ids for x in internal),f'{len(internal)} internal links')
local=[a['href'] for a in SOUP.select('a[href]') if not a['href'].startswith(('#','https:','http:','mailto:'))]
check('All relative download links exist',all((PUB/h).is_file() for h in local),f'{len(local)} links')
check('No remote scripts, styles, images or frames',not SOUP.select('script[src],link[rel="stylesheet"],iframe') and all(im.get('src','').startswith('data:') or im.get('id')=='zoom-image' for im in SOUP.select('img')))
check('No em/en dashes in website','\u2013' not in HTML and '\u2014' not in HTML)
check('Content map covers every actual slide',len(list(csv.DictReader((PUB/'course-downloads/content_map.csv').open())))==50)
check('Private material absent from public files',not any(any(b in p.name.lower() for b in ('facilitator','slides_','s07','receipt')) for p in PUB.rglob('*') if p.is_file()))
check('Three figure image downloads unmodified',all(digest((PUB/'assets'/f'figure-{i}.png').read_bytes())==digest(base64.b64decode(SOUP.select('[data-zoom] img')[i-1]['src'].split(',',1)[1])) for i in (1,2,3)))
rows=list(csv.DictReader(io.StringIO(entries['data.csv'].decode())))
check('Original synthetic design',len(rows)==80 and len({r['donor_id'] for r in rows})==10 and len({r['sample_id'] for r in rows})==40 and all(r['data_origin']=='synthetic' for r in rows))

STORAGE_SHIM='''() => { const store={};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>Object.prototype.hasOwnProperty.call(store,k)?store[k]:null,setItem:(k,v)=>{store[k]=String(v)},removeItem:k=>{delete store[k]},clear:()=>{for(const k in store)delete store[k]}}});window.__testStorage=store; }'''
with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
    context=browser.new_context(viewport={'width':1440,'height':1000},accept_downloads=True)
    page=context.new_page();page.set_default_timeout(4000)
    errors=[];requests=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:requests.append(r.url))
    # Start with native blocked storage, not a simulated successful store.
    page.set_content(HTML,wait_until='domcontentloaded');page.wait_for_timeout(100)
    check('Native blocked-storage fallback notice','unavailable' in page.locator('#course-storage-status').inner_text())
    check('Homepage initial route',page.locator('main>section:visible').evaluate_all('(e)=>e.map(x=>x.id)')==['course'])
    page.locator('body').click(position={'x':1390,'y':40});page.screenshot(path=str(OUT/'desktop_home.png'),full_page=True)
    def go(ident):
        page.evaluate('(id)=>{location.hash=id;window.WorkshopCourse.route()}',ident);page.wait_for_timeout(40)
    def download(action,name):
        with page.expect_download(timeout=4000) as pending:action()
        d=pending.value;dest=OUT/name;d.save_as(str(dest));return dest
    for r in ['why','agents','usage','privacy','cytometry','verification','prepared','audit','glossary','resources','sources']:
        go(r);check('Navigation: '+r,page.locator('main>section:visible').evaluate_all('(e)=>e.map(x=>x.id)')==[r])
    go('data');check('Legacy practical route groups preserved',page.locator('main>section:visible').count()==6)
    page.locator('#filter-donor').select_option('D01');check('Original donor filter','of 8' in page.locator('#data-count').inner_text())
    page.locator('#filter-stimulation').select_option('Stimulated');check('Original donor and stimulation filter','of 4' in page.locator('#data-count').inner_text())
    page.locator('#filter-donor').select_option('');page.locator('#filter-stimulation').select_option('');page.locator('#data-next').click();check('Original data pagination','Rows 11 to 20 of 80' in page.locator('#data-count').inner_text())
    exported=download(lambda:page.locator('[data-download="data.csv"]').first.click(),'downloaded_data.csv')
    check('Native data download has exact bytes',exported.read_bytes()==entries['data.csv'])
    for r in 'ABC':
        go('rounds');page.locator('#tab-'+r).click();check(f'Original round {r} tab',page.locator('#panel-'+r).is_visible())
        exported=download(lambda r=r:page.locator(f'#panel-{r} [data-download="round_{r}.zip"]').click(),f'download_round_{r}.zip')
        check(f'Native round {r} ZIP exact bytes',exported.read_bytes()==entries[f'round_{r}.zip'])
    page.locator('#tab-A').focus();page.keyboard.press('ArrowRight');check('Keyboard round-tab navigation',page.locator('#tab-B').get_attribute('aria-selected')=='true' and page.locator('#tab-B').evaluate('(e)=>document.activeElement===e'))
    # Exercise selection fallback under explicitly denied clipboard operations.
    page.evaluate('''() => {Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:()=>Promise.reject(new Error('blocked'))}});document.execCommand=()=>false;}''')
    page.locator('#panel-B [data-copy]').click();check('Copy fallback selects full prompt (terminal newline excluded by browser)',page.evaluate('window.getSelection().toString()')==entries['prompt_B.txt'].decode().rstrip('\n'), 'Browser selection omits the terminal LF; displayed textContent and downloaded prompt bytes remain exact.')
    go('agents');page.locator('[data-mode="Chat"]').count() # content exists but separate chapter
    page.locator('#brief-outcome').fill('Audit these identifiers.');page.locator('#brief-inputs').fill('samples.csv; sample_id');page.locator('#build-brief').click()
    text=page.locator('#brief-output').inner_text();check('Brief builder uses entries and flags gaps','Audit these identifiers.' in text and '[TO BE SPECIFIED BY THE RESEARCHER]' in text and 'No task has been executed' in text)
    for n in (1,2,3):page.locator(f'[data-plan="{n}"][data-choice="Audit and ask"]').click()
    check('Proposed-plan review shows evidence-based explanations',all('Audit and ask' in page.locator(f'#plan-answer-{n}').inner_text() for n in (1,2,3)))
    go('why');page.locator('[data-scenario="3"][data-mode="Chat"]').click();check('Mode scenarios allow overlapping capabilities','Other tool-enabled contexts' in page.locator('#mode-answer-3').inner_text())
    go('usage');check('Default workload arithmetic',[page.locator('#cost-'+n).inner_text() for n in ['luna','terra','astra']]==['0.25','2.50','11.25'])
    page.locator('#cost-cache').fill('50');page.locator('#cost-calls').fill('2');check('Cached-input multi-call arithmetic',page.locator('#cost-luna').inner_text()=='0.41')
    page.locator('#cost-speed').select_option('2.5');check('Historical multiplier with caveat',page.locator('#cost-luna').inner_text()=='1.025' and 'freshly confirms Astra' in page.locator('#cost-formula').inner_text())
    page.locator('#cost-cache').fill('101');check('Invalid calculator input is rejected',page.locator('#cost-error').is_visible() and page.locator('#cost-astra').inner_text()=='Not calculated')
    page.locator('#cost-cache').fill('0');page.locator('#cost-calls').fill('1');page.locator('#cost-speed').select_option('1')
    go('cytometry')
    expected={}
    for r in rows:
        k=(r['donor_id'],r['treatment'],r['stimulation']);expected.setdefault(k,[]).append(Decimal(r['activation_percent']))
    calculated=page.evaluate('''keys=>keys.map(([d,t,s])=>window.WorkshopCourse.culture(d,t,s))''',[list(k) for k in expected])
    check('All 40 culture means match Decimal calculation',all(abs(float(sum(expected[k])/2)-v)<1e-12 for k,v in zip(expected,calculated)))
    page.locator('#trace-donor').select_option('D10');page.locator('#trace-stimulation').select_option('Stimulated');page.locator('#trace-treatment').select_option('Compound_X')
    expectedMean=sum(expected[('D10','Compound_X','Stimulated')])/2
    check('Trace selector uses actual two-aliquot data',page.locator('#trace-mean').inner_text()==f'{expectedMean:.3f}%')
    check('Trace states correct parent and absent counts','live, singlet CD3+CD8+' in page.locator('#trace-results').inner_text() and 'those counts are absent' in page.locator('#trace-point').inner_text())
    page.locator('#trace-caption').fill('Two technical aliquots per culture; ten simulated donors.');tracefile=download(lambda:page.locator('#export-trace').click(),'trace.txt')
    check('Trace record exports selected values and notes',str(expectedMean) in tracefile.read_text() and 'Two technical aliquots' in tracefile.read_text())
    page.locator('#trace-point').scroll_into_view_if_needed();page.screenshot(path=str(OUT/'desktop_trace.png'))
    go('privacy');page.locator('[data-course-field="privacy-classification"]').check();check('Privacy tick without evidence not accepted','1 ticked item lacks' in page.locator('#privacy-status').inner_text())
    page.locator('[data-course-field="privacy-evidence-classification"]').fill('Synthetic workshop CSV, see study_context.md.');check('Privacy evidence recorded but no approval','1 / 6' in page.locator('#privacy-status').inner_text() and 'does not authorise' in page.locator('#privacy-status').inner_text())
    go('verification');page.locator('[data-course-field="verify-numerical"]').check();check('Verification requires concrete evidence','1 ticked item lacks' in page.locator('#verify-status').inner_text())
    page.locator('[data-course-field="verify-evidence-numerical"]').fill('D10 mean checked against both input rows.');check('Verification remains self-reported','1 / 5' in page.locator('#verify-status').inner_text() and 'Self-reported' in page.locator('#verify-status').inner_text())
    for case in ['diagram','plot','image','method','abstract','cover','review','grammar']:
        page.locator('#publication-case').select_option(case);check('Publication scenario: '+case,len(page.locator('#publication-answer').inner_text())>90)
    page.locator('#take-task').fill('Check a figure caption against plot_data.csv.');planfile=download(lambda:page.locator('#export-take-home').click(),'plan.txt');check('Take-home plan export', 'Check a figure caption' in planfile.read_text() and '[NOT YET SPECIFIED]' in planfile.read_text())
    go('prepared');check('Prepared condition labels initially concealed',page.locator('#figure-label-1').inner_text()=='Figure 1' and not page.locator('#figure-reveal-1').is_visible())
    check('All three embedded images load',page.locator('[data-zoom] img').evaluate_all('(imgs)=>imgs.every(i=>i.complete&&i.naturalWidth>1000)'))
    page.locator('[data-zoom="2"]').click();check('Figure zoom opens native modal',page.locator('#figure-dialog').evaluate('(e)=>e.open'))
    page.locator('#zoom-in').click();check('Figure zoom changes display only',page.locator('#zoom-image').get_attribute('style')=='width: 150%;')
    page.keyboard.press('Escape');check('Escape closes modal and restores keyboard focus',not page.locator('#figure-dialog').is_visible() and page.locator('[data-zoom="2"]').evaluate('(e)=>document.activeElement===e'))
    page.locator('#reveal-figures').click();check('Prepared outcomes revealed without winner claim','A · Basic' in page.locator('#figure-label-1').inner_text() and 'zero revisions' in page.locator('#figure-reveal-3').inner_text())
    page.locator('#prepared-figures').scroll_into_view_if_needed();page.screenshot(path=str(OUT/'desktop_figures.png'))
    check('Prepared statistics explicitly source-attributed','Not newly computed' in page.locator('#prepared').inner_text() and '0.001260401780' in page.locator('#prepared-results').evaluate('(e)=>e.nextElementSibling.nextElementSibling.textContent'))
    go('glossary');page.locator('#glossary-search').fill('paired t-test');check('Glossary filtering',page.locator('.term:visible').count()==1);page.locator('#glossary-search').fill('qqq-no-match');check('Glossary no-result state',page.locator('#glossary-empty').is_visible());page.locator('#glossary-search').fill('')
    go('review');page.locator('#review-label').fill('Figure blind 1');page.locator('[data-score="scientific_integrity"]').select_option('2');page.locator('[data-evidence="scientific_integrity"]').fill('Culture means compared with all source rows.');page.locator('[data-review="1"]').click();page.locator('#review-label').fill('Figure blind 2');page.locator('#review-note').fill('=This must not become a spreadsheet formula');page.locator('[data-review="2"]').click();page.locator('#review-label').fill('Figure blind 3');page.locator('[data-review="0"]').click()
    check('Three independent original scorecards',page.locator('#review-label').input_value()=='Figure blind 1' and page.locator('[data-score="scientific_integrity"]').input_value()=='2')
    reviewfile=download(lambda:page.locator('#export-reviews').click(),'reviews.csv');reviewrows=list(csv.DictReader(io.StringIO(reviewfile.read_text(encoding='utf-8-sig'))));check('Original scorecard CSV export and formula safety',len(reviewrows)==3 and reviewrows[1]['notes'].startswith("'="))
    go('run-log');page.locator('#run-log details summary').first.click();page.locator('[data-course-field="log-A-model_label"]').fill('Observed model label');page.locator('[data-course-field="log-A-notes"]').fill('=do not execute');logfile=download(lambda:page.locator('#export-run-log').click(),'run_log.csv');logrows=list(csv.DictReader(io.StringIO(logfile.read_text(encoding='utf-8-sig'))));check('Run log exact schema and safe CSV',list(logrows[0])==next(csv.reader(io.StringIO(entries['run_log.csv'].decode()))) and len(logrows)==3 and logrows[0]['notes'].startswith("'="))
    go('resources');exportfile=download(lambda:page.locator('#export-progress').click(),'progress.json');saved=json.loads(exportfile.read_text());check('Full progress export works when storage blocked',saved['practical']['reviews'][1]['label']=='Figure blind 2' and saved['course']['fields']['trace-caption'].startswith('Two technical'))
    page.on('dialog',lambda d:d.accept());page.locator('#reset-course').click();go('review');check('Reset clears live original scorecards',page.locator('#review-label').input_value()=='');go('resources');page.locator('#import-progress').set_input_files(str(exportfile));page.wait_for_timeout(100);go('review');check('Progress import restores original independent scorecards',page.locator('#review-label').input_value()=='Figure blind 1');go('cytometry');check('Progress import restores course fields',page.locator('#trace-caption').input_value().startswith('Two technical'))
    bad=OUT/'invalid.json';bad.write_text('{"format":"wrong","version":2}');go('resources');page.locator('#import-progress').set_input_files(str(bad));check('Invalid progress export rejected','Import not applied' in page.locator('#import-status').inner_text())
    check('No script runtime errors during native interaction tests',not errors,'; '.join(errors))
    check('No automatic remote requests',not [u for u in requests if u.startswith(('http:','https:'))],requests)
    # Mobile layouts: real browser rendering, document-injection harness.
    for width in (390,375):
        page.set_viewport_size({'width':width,'height':844})
        for route in ['course','agents','usage','privacy','cytometry','verification','overview','prepared','resources','sources']:
            go(route);overflow=page.evaluate('document.documentElement.scrollWidth>innerWidth+1');check(f'No page overflow at {width}px: {route}',not overflow)
        go('course');page.locator('body').click(position={'x':5,'y':100});page.screenshot(path=str(OUT/f'mobile_home_{width}.png'),full_page=True)
    go('usage');page.locator('#mobile-nav').select_option('cytometry');page.wait_for_timeout(50);check('Mobile chapter navigation',page.locator('#cytometry').is_visible())
    # Persistence and legacy migration specifically use a storage shim, not a false native claim.
    shim=context.new_page();shim.evaluate(STORAGE_SHIM)
    legacy={'progress':{'setup':True},'reviews':[{'label':'Legacy '+str(i),'reviewer':'','scores':{},'evidence':{},'scientificGate':'','regeneration':'','note':''} for i in range(3)]}
    shim.evaluate('(v)=>localStorage.setItem("codex-science-workshop-v1",JSON.stringify(v))',legacy);shim.set_content(HTML)
    check('Legacy key loaded (storage shim)',shim.evaluate('window.WorkshopPractical.getState().reviews[0].label')=='Legacy 0' and shim.locator('#progress-text').inner_text()=='1 / 5')
    shim.evaluate('location.hash="agents";window.WorkshopCourse.route()');shim.locator('#brief-outcome').fill('Persisted teaching entry');stored=shim.evaluate('JSON.parse(localStorage.getItem("codex-science-course-v2"))');check('Course write persistence (storage shim)',stored['fields']['brief-outcome']=='Persisted teaching entry')
    # Reload-equivalent new page with the serialized stores. Actual origin reload unavailable.
    savedStore=shim.evaluate('window.__testStorage');shim2=context.new_page();shim2.evaluate(STORAGE_SHIM);shim2.evaluate('(obj)=>{for(const[k,v]of Object.entries(obj))localStorage.setItem(k,v)}',savedStore);shim2.set_content(HTML)
    check('Course restore across new document (storage shim)',shim2.locator('#brief-outcome').input_value()=='Persisted teaching entry' and shim2.evaluate('window.WorkshopPractical.getState().reviews[0].label')=='Legacy 0')
    browser.close()

report={'date':'2026-09-16','harness':'Chromium via Playwright set_content. Browser policy blocks normal URL navigation. Native Blob downloads and native blocked-storage fallback tested; explicit storage shim used only for migration/persistence.', 'passed':sum(r['passed'] for r in results),'total':len(results),'results':results,'not_performed':['Native localStorage across a real hosted origin reload (blocked by browser environment policy).','Normal hosted browser navigation / deployment to Sites.','Actual Codex A/B/C agent runs or FCS analyses.','Re-execution of prepared statistical figure masters, receipts or diagnostics.','Physical printing, vector-editor round trips, screen-reader testing, Safari/Firefox testing.','Exhaustive live validation of every external source URL.']}
(ROOT/'TEST_RESULTS.json').write_text(json.dumps(report,indent=2))
md=f"# Executed website tests\n\n16 September 2026. **{report['passed']} / {report['total']} checks passed.**\n\n## Harness and limits\n\n{report['harness']}\n\n## Checks\n\n"+'\n'.join(f"- {'PASS' if r['passed'] else 'FAIL'}: {r['test']}. {r['detail']}" for r in results)+'\n\n## Not performed\n\n'+'\n'.join('- '+s for s in report['not_performed'])+'\n'
(ROOT/'TEST_RESULTS.md').write_text(md)
print(f"\n{report['passed']} / {report['total']} passed")
if report['passed']<report['total']:sys.exit(1)
