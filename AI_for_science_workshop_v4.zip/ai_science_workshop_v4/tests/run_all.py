#!/usr/bin/env python3
"""Run reproducible browser suites and an independently served HTTP asset audit."""
from pathlib import Path
import sys,subprocess,json,os,time,hashlib,urllib.request,urllib.error,socket
ROOT=Path(__file__).resolve().parents[1];PUB=ROOT/'public'
if '--combine' not in sys.argv:
 subprocess.run([sys.executable,str(ROOT/'tests/test_site.py')],check=True)
 reg=json.loads((ROOT/'TEST_RESULTS.json').read_text())
 (ROOT/'REGRESSION_TEST_RESULTS.json').write_text(json.dumps(reg,indent=2))
 subprocess.run([sys.executable,str(ROOT/'tests/test_teaching.py')],check=True)
else:
 reg=json.loads((ROOT/'REGRESSION_TEST_RESULTS.json').read_text())
teach=json.loads((ROOT/'TEACHING_TEST_RESULTS.json').read_text())
checks=[]
def check(name,ok,detail=''):checks.append({'test':name,'passed':bool(ok),'detail':str(detail)})
with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
env=dict(os.environ,PORT=str(port))
proc=subprocess.Popen(['node','server.mjs'],cwd=ROOT,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
base=f'http://127.0.0.1:{port}'
def request(path,method='GET'):
 try:
  with urllib.request.urlopen(urllib.request.Request(base+path,method=method),timeout=5) as res:return res.status,dict(res.headers),res.read()
 except urllib.error.HTTPError as e:return e.code,dict(e.headers),e.read()
try:
 for attempt in range(30):
  try:
   code,headers,content=request('/');break
  except OSError:time.sleep(.1)
 else:raise RuntimeError('Static preview did not start')
 check('HTTP root serves exact built index',code==200 and content==(PUB/'index.html').read_bytes())
 for p in sorted(PUB.rglob('*')):
  if not p.is_file():continue
  code,h,b=request('/'+p.relative_to(PUB).as_posix())
  check('HTTP asset integrity: '+p.relative_to(PUB).as_posix(),code==200 and b==p.read_bytes())
 for path in ['/recovery/saved_site_v2.zip','/source/course.html.j2','/README.md','/%2e%2e%2frecovery/saved_site_v2.zip','/nonexistent-download.zip']:
  code,_,_=request(path);check('Nonpublic or missing path rejected: '+path,code in (400,403,404),code)
 code,_,_=request('/','POST');check('Server rejects participant-data writes',code==405)
 code,h,b=request('/downloads/data.csv','HEAD');check('HEAD metadata without body',code==200 and b==b'' and h['Content-Length']==str((PUB/'downloads/data.csv').stat().st_size))
finally:
 proc.terminate();proc.wait(timeout=5)
http={'date':'2026-09-16','harness':'Local static HTTP server checked with urllib, separately from browser navigation. No participant-data backend.','results':checks,'passed':sum(c['passed'] for c in checks),'total':len(checks)}
(ROOT/'STATIC_SERVER_CHECKS.json').write_text(json.dumps(http,indent=2))
allchecks=reg['results']+teach['results']+checks
report={'date':'2026-09-16','version':'3.0.0','passed':sum(c['passed'] for c in allchecks),'total':len(allchecks),'harness':'Chromium via Playwright document injection, real Blob downloads and native storage-unavailable fallback; explicit storage shim only for migration/persistence. Normal HTTP and file browser navigation attempted and blocked with ERR_BLOCKED_BY_ADMINISTRATOR. Static HTTP responses tested separately using urllib.','results':allchecks,'not_performed':reg['not_performed']}
(ROOT/'TEST_RESULTS.json').write_text(json.dumps(report,indent=2))
text=f"# Website test results\n\nReview version 3.0.0, 16 September 2026. **{report['passed']} / {report['total']} checks passed.**\n\n## What actually ran\n\n{report['harness']}\n\nThe original/browser suite ran {reg['total']} checks. The teaching suite ran {teach['total']} checks. The static HTTP suite ran {http['total']} checks. Timing checks cover the planned 90-minute structure, not an observed teaching session. Layout checks include every focused topic at 1440, 768, 390 and 375 pixels.\n\n## Results\n\n"
text+='\n'.join(f"- {'PASS' if c['passed'] else 'FAIL'}: {c['test']}." for c in allchecks)
text+='\n\n## Checks not performed\n\n'+'\n'.join('- '+x for x in report['not_performed'])
text+='\n\n## Release status\n\nSaved for review only. The live Sites project was not edited or published. Native hosted storage, mobile Safari, screen readers and host-specific downloads still require testing in the intended deployment environment.\n'
(ROOT/'TEST_RESULTS.md').write_text(text)
print(f"\nFINAL: {report['passed']} / {report['total']} checks passed")
if report['passed']!=report['total']:sys.exit(1)
