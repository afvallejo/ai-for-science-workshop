# Handoff for the existing Sites workshop

This is a saved, locally implemented extension. No Sites tool or project editor was available in the authoring session, so the existing live Site was not changed or published. Do not present the ZIP or HTML review as a hosted shared room.

## Paste into the existing Sites project with this ZIP attached

Extend this existing AI for science/Codex for science workshop with the attached version 4 room exercise. Do not create a replacement site. Preserve the existing course, A/B/C figure exercise, data, prompts, skills, downloadable files, progress migration and scorecards.

Inspect the current project, its runtime and storage capabilities before changing anything. The supplied `public/room/index.html` is the participant interface and `room-src/` contains its maintainable source. `room_app.py` implements a working Python ASGI/SQLite API. `room_decks.py` provides bounded intake and native editable PowerPoint merging. The Python server was tested locally, not as a Sites-compatible runtime. Do not assume it can run unchanged on the Sites host.

Preserve the API contract while using supported server-side metadata and binary-file storage in this actual project. Provision and verify persistent storage. Do not implement multi-participant sharing with localStorage, a seeded gallery, simulated receipts or an upload button with no backend. Use a supported merge implementation that preserves editable native slides; do not silently replace it with image-only slides or an unsupported third-party service. If the actual hosting runtime cannot support these requirements, state the blocker and keep sharing explicitly disabled rather than claiming completion.

The participant flow is: select real Plan mode, interview one question at a time, approve the exact brief, leave Plan mode, use actual computer use in PowerPoint, inspect the file, separately approve room sharing, and submit through the visible website. Upload success must come from server persistence. Keep the manual fallback explicit.

Preserve facilitator-only room creation, management keys, consent, one-slide format validation, upload limits, duplicate replacement, withdrawal controls, exclusion/reordering, editable combined export and ZIP export with checksums. Keep room access and retention disclosures visible. Do not expose real management keys in client-side code. A shared room code is not individual identity authentication.

Before release, test from two independent real devices on the intended URL: joining the same room, distinct uploads, replacement, authentic receipts, close/reopen, exclusion, reordering, combined export and reopening that deck in Microsoft PowerPoint. Verify storage survives an application restart/redeploy. Check keyboard navigation, narrow screens, real file-picker behaviour, blocked storage, offline states and failed requests. Verify all original downloadable files remain byte-identical.

Save the changes for review. Report exactly what was implemented, tested and not tested. Ask before deploying to the existing live site. Do not describe a saved version as a deployment or invent a private preview URL.

## Current references

Official documentation checked 17 September 2026:
- https://learn.chatgpt.com/docs/sites
- https://help.openai.com/en/articles/20001339-creating-and-managing-chatgpt-sites
- https://learn.chatgpt.com/docs/computer-use
- https://learn.chatgpt.com/docs/features

These references do not establish that this particular Python backend is supported by the target Sites runtime. Inspect and verify the actual project.
