# Version 4 workshop room: verification report

17 September 2026. This is a saved local project, not a hosted deployment.

## Completed checks

- **17 / 17 API and PowerPoint package tests passed.** These include independent participants, authentic committed receipts, duplicate replacement, owner-only exports and moderation, reordering, closure and withdrawal, deletion, invalid files, consent, origin and JSON checks, metadata removal, archive/XML controls, PNG handling and private-file protection.
- **40 / 40 Chromium UI checks passed.** They exercise three independent browser sessions, brief approval and invalidation, keyboard tabs, real room creation and uploads, downloadable editable export, the actual gallery/presenter, closed submissions, and layouts at 768, 390 and 375 pixels. Offline and blocked-storage fallbacks also passed.
- **10 / 10 separate HTTP and preservation checks passed.** A real uvicorn server accepted an upload over HTTP. Its room, uploaded slide and management authorisation survived a complete process restart. Private files were not served. All 16 original practical downloads remain byte-identical. The standalone review has no broken relative full-course route.
- The template and a two-slide merged deck were converted to PDF by LibreOffice. The template and both merged slides were visually inspected. Native text/shapes and an embedded image were retained, and the merged file reopened through python-pptx as two independently editable slides.

## Test environment and limits

This environment blocks normal browser navigation with `ERR_BLOCKED_BY_ADMINISTRATOR`. UI tests therefore inject the real HTML into Chromium and bridge fetch calls to the real FastAPI application. The bridge performs actual database-backed operations, but it is not a deployed-browser/network test. It is confined to `tests/room/browser_room.py`; the delivered website uses ordinary same-origin fetch. Separate HTTP tests use httpx against a real uvicorn process and test restart persistence.

The broader historical course regression suite was started and a subset completed successfully, but the process exceeded the tool time limit before completion. It is not claimed as a fully rerun suite. The original downloaded assets were independently rechecked byte-for-byte. Prior version 3 reports are retained as historical evidence, not current full-suite certification.

Not tested here: Microsoft PowerPoint itself, actual AI computer-use execution, native Sites runtime/storage, an existing Sites project update, live deployment, two physical workshop devices, institutional Wi-Fi, production authentication or penetration testing, Safari, screen-reader use, and arbitrary participant-created PowerPoints. Test the real hosted URL and reopen the combined deck on the presenting computer before the workshop.

## Evidence files

`ROOM_BROWSER_TESTS.json`, `ROOM_HTTP_TESTS.json`, `tests/room/api_tests.xml`, and reproducible code in `tests/room/`. Test screenshots and sample exports are under `tests/room/artifacts/`. They contain clearly synthetic test participants, not workshop submissions.

## Release status

No live Site was changed, no shared service is left running for participants, and no real participant data was uploaded. Server keys used in testing are not deployment credentials. Persistent private test databases and runtime key files are excluded from the deliverable.
