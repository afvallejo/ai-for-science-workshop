# AI for science: guided teaching sequence

Review version 3.0, saved 16 September 2026. Workshop date remains editable.

Scientific judgement stays with the researcher. Use exact inputs, limited authority, verifiable outputs and stopping conditions.

30 interactive topic views, not embedded slides. Suggested topic timings total 90 minutes, including the 9-minute abbreviated activity. The original 50-minute A/B/C practical is a separate route. No raw FCS dataset or executed FCS notebook is supplied.

## Why AI, and which tool?

### A polished answer is not yet a checked result (2 minutes)

Website section: #teach-why-1. Original presentation positions: 1, 11.

Discussion: Would a plausible figure be enough to put in a paper? Name the file or calculation you would need to inspect.

Transition: Start with a task you can check, then distinguish the model from its working environment.

Visual: Compare the literature, identifier-audit, figure and manuscript examples. Point to the inspectable evidence for each.

### The engine, the interface and the available actions (2 minutes)

Website section: #teach-why-2. Original presentation positions: 1, 5, 7.

Discussion: An assistant can describe a calculation. What additional capability lets it actually run that calculation?

Transition: Now choose the working context for the task, not a universal winner.

Visual: Use the four-part HTML strip: model, interface, tools, environment. Do not display the private account screenshot.

### Choose a task fit, not a favourite brand (1.5 minutes)

Website section: #teach-why-3. Original presentation positions: 12, 13.

Discussion: Give both systems equivalent permitted inputs. What would make the comparison fair?

Transition: Test that choice against three concrete scientific tasks.

Visual: Read across the product-family table by task. Treat the football comparison as an analogy, not a model ranking.

### Which inputs, tools and outputs does this task need? (1.5 minutes)

Website section: #teach-why-4. Original presentation positions: 16.

Discussion: Discuss one defensible working context for each scenario, and the evidence you would inspect.

Transition: Product choice does not tell us what AI-assisted writing estimates actually measure.

Visual: Use the three scenario cards. Reveal the rationale only after discussing inputs and evidence.

### A population estimate is not a paper detector (3 minutes)

Website section: #teach-why-5. Original presentation positions: 3.

Discussion: Does 89% mean 89% of every paper was generated? Explain why that interpretation is unsupported.

Transition: Writing assistance is one use. Agents add actions and feedback, which require explicit boundaries.

Visual: Open the attributed estimate table. Contrast the December estimate with the whole-corpus count and the limitations beneath it.

## Agents and a working method

### Inspect, choose, act, check (3 minutes)

Website section: #teach-agents-1. Original presentation positions: 8, 9, 10, 14, 15.

Discussion: When an audit finds a duplicate, should the next action be a merge or a request for evidence?

Transition: A useful loop needs a brief that defines what success means.

Visual: Follow the four-step strip. Use the advice/task cards and expandable orchestration explanation to show where tool evidence enters.

### Replace “analyse my experiment” with a reviewable task (3 minutes)

Website section: #teach-agents-2. Original presentation positions: 17, 18.

Discussion: Write an outcome, exact inputs, boundaries, evidence and a stopping condition. Leave unresolved choices unresolved.

Transition: A clear brief makes a proposed plan easier to challenge.

Visual: Fill the five fields live, then inspect the generated draft for unresolved placeholders. No agent execution is simulated.

### Agree the approach before implementation (1.5 minutes)

Website section: #teach-agents-3. Original presentation positions: 19.

Discussion: Which parts are inspection, which are proposed actions, and which still require a decision?

Transition: Read-only inspection is not permission to repair scientific metadata.

Visual: Read the bounded audit example and separate inspection from proposed implementation and validation.

### Three persuasive proposals that need a stop (2 minutes)

Website section: #teach-agents-4. Original presentation positions: 20.

Discussion: Challenge discarding duplicate records, filling batch labels and starting differential expression. What evidence is missing?

Transition: Turn the boundary into an explicit finish condition.

Visual: Use the three plan decisions and reveal why automatic repair or analysis would exceed the available evidence.

### Define “done”, including when to ask (1.5 minutes)

Website section: #teach-agents-5. Original presentation positions: 21.

Discussion: Could another researcher tell whether the objective had been met from the saved output alone?

Transition: Repeated tasks also benefit from inspectable procedures.

Visual: Expand the finish-condition explanation. Identify the saved artifact and the unresolved choice that triggers a stop.

### A procedure is not a permission (2 minutes)

Website section: #teach-agents-6. Original presentation positions: 23.

Discussion: A laboratory protocol describes a procedure; it is not the instrument or the key to the laboratory. Which concept does each represent here?

Transition: Inspect the actual figure skill before asking the system to use it.

Visual: Read the tool, skill, plugin, connection and MCP table as distinct roles, not interchangeable names.

### Quality requirements are not an instruction to keep revising (5 minutes)

Website section: #teach-agents-7. Original presentation positions: 22, 45 to 50.

Discussion: Find a scientific requirement, a rendering check and a stop condition. Which additional protocol belongs only to round C?

Transition: The work needed for those checks, not the length of the final answer, affects usage.

Visual: Expand each original SKILL.md section and its purpose annotation. Contrast acceptance criteria with the explicit round C loop.

## Models, tokens and usage

### A short answer can involve substantial processing (2 minutes)

Website section: #teach-usage-1. Original presentation positions: 24.

Discussion: Where could a one-sentence answer hide many file reads, model calls and reasoning tokens?

Transition: Hold a workload constant to understand rates, not to predict a whole task.

Visual: Use the input, processing and output cards to separate context capacity from time-window usage.

### Show the arithmetic, keep the assumptions visible (4 minutes)

Website section: #teach-usage-2. Original presentation positions: 25.

Discussion: Change cached input or the number of calls. Which assumptions are held constant and which costs are excluded?

Transition: A speed tier and reasoning effort are separate controls.

Visual: Change one assumption in the calculator and read the formula and rate table. The numbers are arithmetic, not a benchmark.

### Reasoning depth is different from latency (2 minutes)

Website section: #teach-usage-3. Original presentation positions: 26.

Discussion: Would faster model output necessarily make a workflow dominated by tool execution finish proportionally faster?

Transition: Account allowance is another separate quantity.

Visual: Contrast reasoning effort with service speed in the text and source-status note. No private usage screenshot is required.

### A budget is not a fixed number of prompts (2 minutes)

Website section: #teach-usage-4. Original presentation positions: 27.

Discussion: Why can two apparently similar requests consume different amounts of an allowance?

Transition: Before spending an allowance on research files, establish what happens to the information.

Visual: Contrast context capacity, reset windows, credits and API charges. Do not turn a remaining percentage into a prompt count.

## Privacy before sharing data

### Local files do not prove local-only processing (2 minutes)

Website section: #teach-privacy-1. Original presentation positions: 28.

Discussion: The FCS file stays on a laptop, but a plot is sent to a cloud model. What information crossed the boundary?

Transition: Account terms change the answers, but do not replace institutional approval.

Visual: Trace the four questions in the HTML strip. Contrast a local FCS file with information extracted and sent to a model.

### Check the account and sign-in route (4 minutes)

Website section: #teach-privacy-2. Original presentation positions: 29, 30.

Discussion: Separate personal, organisational, temporary or incognito, and API contexts. What evidence identifies the one actually being used?

Transition: A zero-retention claim needs an equally precise scope.

Visual: Read the OpenAI and Anthropic account tables alongside their dated-source labels. Do not imply institutional approval.

### Zero Data Retention is not a promise about every copy (2 minutes)

Website section: #teach-privacy-3. Original presentation positions: 31.

Discussion: Which organisation, model, endpoint, feature and connected service does the agreement cover?

Transition: Record the evidence before sharing, rather than treating an account label as permission.

Visual: Use the scoped-agreement explanation and current covered-model update. Ask which copy or service each promise concerns.

### Six questions before sharing data (4 minutes)

Website section: #teach-privacy-4. Original presentation positions: 28 to 31.

Discussion: Complete the checklist for the synthetic workshop material. What would still need institutional confirmation for confidential research?

Transition: Use only the supplied synthetic endpoints for the practical.

Visual: Complete the six evidence-backed checks. Leave unavailable information blank and observe that no certificate is issued.

## From scientific data to a figure

### Know what the available data cannot tell you (4 minutes)

Website section: #teach-cytometry-1. Original presentation positions: 32.

Discussion: Can a table of endpoint percentages reveal gate thresholds or event counts? What source files would be needed?

Transition: Follow the raw-data workflow conceptually, without pretending to run unavailable FCS data.

Visual: Read the explicit endpoint-table boundary before drawing any conclusions about raw acquisition.

### Preserve the path from events to an endpoint (6 minutes)

Website section: #teach-cytometry-2. Original presentation positions: 32, 33.

Discussion: Where would you record acquisition quality, corrections, transforms, controls and losses at each gate?

Transition: Many measured events still belong to a finite number of independent biological units.

Visual: Follow the conceptual FCS-to-endpoint strip. No sample-specific gate thresholds or event counts are invented.

### Eighty measurements are not eighty donors (5 minutes)

Website section: #teach-cytometry-3. Original presentation positions: 34.

Discussion: Explain 80 measurements, 40 cultures and 10 simulated donors without changing the unit of inference.

Transition: Choose each figure panel for the evidence it must communicate.

Visual: Use the replication cards to distinguish 80 measurements, 40 culture means and 10 simulated donors.

### Four panels, four distinct jobs (4 minutes)

Website section: #teach-cytometry-4. Original presentation positions: 35.

Discussion: Which proposed panels cannot be reconstructed from the supplied endpoint CSV?

Transition: Trace an actual culture summary and record one checked claim.

Visual: Inspect the four labelled conceptual cards: gating evidence, distributions, replicate summaries and effect/uncertainty.

### Trace one plotted point to its two source rows (9 minutes)

Website section: #teach-cytometry-5. Original presentation positions: 36.

Discussion: Select a donor and condition, inspect the aliquots, check their arithmetic mean and name the parent population. Which underlying counts remain unavailable?

Transition: Checking one point demonstrates a method. It is not verification of the complete figure.

Visual: Use the donor/condition selectors, the two actual aliquot values, arithmetic check and browser-calculated paired preview.

## Verification and publication

### Written, executed and checked are different states (1 minutes)

Website section: #teach-verification-1. Original presentation positions: 37.

Discussion: Which saved evidence would distinguish code that was written from code that actually ran?

Transition: A verification claim needs a specific observation or record.

Visual: Use the four-state strip to separate advice, code written, code executed and outputs checked.

### Ask what was checked, not how confident it sounds (2 minutes)

Website section: #teach-verification-2. Original presentation positions: 37.

Discussion: Record numerical readback, rendered inspection and regeneration evidence separately. Leave unperformed checks unmarked.

Transition: Scientific verification and permission to publish are distinct questions.

Visual: Record concrete observations next to each check. Show that a tick without evidence remains incomplete.

### Publication use depends on the material (3 minutes)

Website section: #teach-verification-3. Original presentation positions: 4, 38, 39.

Discussion: Why are a conceptual workflow, a data plot and a primary microscopy image treated differently?

Transition: Apply the policy to concrete cases, preserving its conditions and exceptions.

Visual: Compare manuscript support with research and peer-review uses, then inspect the definition of private supportive use.

### Make the publication decision explicit (3 minutes)

Website section: #teach-verification-4. Original presentation positions: 38, 39.

Discussion: Identify the required disclosure or restriction. Does paying for an account itself satisfy peer-review confidentiality?

Transition: Finish with one bounded task from your own workflow.

Visual: Switch among the eight scenarios, including primary images, graphical abstracts and cover art; inspect the source-linked conditions.

### One task, exact inputs, a result you can check (3 minutes)

Website section: #teach-verification-5. Original presentation positions: 40, 41.

Discussion: Write the task, inputs, expected output, verification and the point requiring a human decision. Export the plan.

Transition: Scientific judgement stays with the researcher. Expand the task only after inspecting its evidence.

Visual: Complete the five take-home fields, then export the text plan with an explicit human decision point.

## Prepared example and fallback

The prepared statistical comparison remains a separate extension, not part of the descriptive A/B/C instructions. Retrospective authorisation does not mean preregistration. Figures are unchanged embedded PNG assets from positions 46 to 48.

The optional audit reproduces only the visible sample table and matrix identifiers from positions 43 and 44. Missing fixtures are not invented.
