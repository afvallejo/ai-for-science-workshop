# AI for science workshop, version 4

**Saved project, not a published Sites deployment.** This extends the recovered version 3 workshop and adds a shared-room exercise. The existing course, A/B/C figure practical and original downloads are retained. The new exercise is at `/room/`; the existing full course is at `/`.

## What participants do

Allow about 20 minutes, with extra time for first-time computer-use setup.

1. Select Plan mode in their authorised desktop AI app. Paste the interview prompt. The AI asks one question at a time, up to six, about research interests, a specific task, their own AI idea, safe inputs, independent verification and limits.
2. Review the proposed slide text. Enter the title and four short sections into the page. Approve it. Changes invalidate approval.
3. Leave Plan mode in the app. Copy the creation prompt and use actual computer use to operate PowerPoint. Save and inspect one 16:9 slide. A programmatically generated deck is not presented as a computer-use demonstration. A manual fallback is explicitly labelled.
4. Separately approve sharing. Let the agent operate the site's upload form, or submit manually. Success requires the server-generated receipt. The facilitator combines accepted contributions into one editable deck.

The page does not contain an AI chatbot, run a model or request participants' AI API keys. The interview happens in their own authorised AI application.

## Review without running a server

Open `public/room/index.html` in a browser. The exercise, brief and prompts work, but shared uploads are disabled. The separate `AI_for_science_room_review.html` supplied with this project also embeds the PowerPoint template.

**Opening an HTML file, uploading only `public/` to static hosting, or using `node server.mjs` does not enable room sharing.** That distinction is visible on the page. Never send the offline review to participants as though it were an upload service.

## Run the complete website

Use Python 3.11 or newer. The supplied runtime requirements are pinned to the tested environment. From this project folder:

```bash
python -m venv .venv
# macOS/Linux:
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python run_workshop.py
# Windows instead:
# .venv\Scripts\python -m pip install -r requirements.txt
# .venv\Scripts\python run_workshop.py
```

Open `http://127.0.0.1:4173/room/` on the server computer. The server prints the location of its newly generated facilitator key, normally `.room-data/facilitator-key.txt`. Open that local text file, then paste its key into the website's **Facilitator** tab. Create a room and save its separate private management key.

For a trusted room network, explicitly listen on the network interface:

```bash
.venv/bin/python run_workshop.py --host 0.0.0.0 --port 4173
```

Use the computer's actual LAN IP address in participant links, for example `http://YOUR-LAN-IP:4173/room/`. Open that address yourself before creating/copying the room link. **A participant link containing `localhost` or `127.0.0.1` points at the participant's own computer, not yours.** Firewall rules and institutional Wi-Fi isolation can prevent access; test from two physical devices on the intended network. Do not treat the development container used to author this project as a persistent server.

Plain HTTP is only appropriate for a controlled demonstration with non-sensitive material and a trusted network. The room and management keys travel over that connection. For any internet-accessible use, provision HTTPS and appropriate access controls first.

## Facilitator workflow

Create the room and share only its participant URL and eight-character code. Keep the server key and room management key private. Participants with the room code can view and download included slides without individual accounts. This is not identity-authenticated private storage.

The facilitator can close submissions, exclude/include contributions, reorder them, delete individual contributions, present the gallery, download cleaned individual slides with a checksum manifest, or combine included slides into an editable `.pptx`. Excluded submissions are removed from the participant gallery and from public per-slide downloads, but remain visible to the facilitator until deleted. New submissions are included by default, not pre-moderated.

The browser's participant key makes resubmission replace the same participant's earlier slide. It also authorises withdrawal. Save the private receipt before closing the page. Different devices, private browsing, cleared browser data or another browser have a different participant key; those can create another submission. The facilitator can remove duplicates. When browser storage is blocked, keys and draft notes survive only in the current page memory, so saving the private key/receipt is essential. A saved receipt can be used for API withdrawal with its participant token; the UI does not currently import receipts into another browser.

## Accepted slide format and merge limits

Use the supplied template or standard PowerPoint Widescreen, 13 1/3 by 7.5 inches. Submit exactly one standard Open XML `.pptx`, at most 8 MiB. Keep it to native text and shapes, with embedded PNG/JPEG images if needed. Macros, ActiveX, charts, SmartArt, embedded files, embedded fonts, other media, animations and transitions are rejected with an actionable error. Strict Open XML and password-protected presentations are not accepted.

An optional matching 16:9 PNG is at most 3 MiB and between 320 by 180 and 4096 by 2304 pixels. The gallery shows that participant-supplied PNG. Without a PNG, it clearly shows extracted text, **not** an actual slide rendering. The website cannot verify that an uploaded PNG matches the PowerPoint; participants must check that.

A room supports up to 60 slides. A merged export is limited to 120 MiB total input. Exclude some slides and export batches for larger rooms. The merger namespaces source packages and rewrites their relationships, retaining editable text, shapes, embedded images, masters and layouts rather than flattening them to images. Test exports opened with python-pptx and rendered with LibreOffice. **Microsoft PowerPoint itself, arbitrary participant-generated decks and the intended deployment environment have not been verified here.** Reopen and inspect the combined deck on the actual presenting computer, especially fonts and line wrapping.

## Storage, privacy and operations

FastAPI serves the static course and same-origin room API. SQLite stores room metadata and uploaded files outside the public folder. `WORKSHOP_DATA` changes the data directory. `WORKSHOP_HOST_KEY` can supply a securely generated server key of at least 24 characters instead of using the generated key file. Never hardcode a real key in the public files or source repository.

Use one ASGI worker and one server instance with a durable local volume. Do not place the database on ephemeral storage and assume persistence. Do not mount `.room-data` into the public directory. The app bounds uploads, validates archive paths and XML, strips common notes/comments/document properties/hyperlink actions from shared copies, checks facilitator and withdrawal tokens, rejects cross-origin writes and applies limited in-process request throttling. **It is not a malware scanner, an identity provider, an institutional research-data repository, or an independently security-audited public service.** These measures do not detect all sensitive content. Use public, fictional or non-sensitive ideas only.

The facilitator determines retention. Room deletion removes active database records. It cannot recall downloaded copies, delete external backups or guarantee forensic erasure from SQLite free pages/WAL. A production host must define retention, backups, access controls, rate limits, request limits and incident handling. Configure any HTTPS reverse proxy's forwarded headers consistently with the app's origin checks. The startup script does not trust forwarded headers by default.

For Sites, see `SITES_HANDOFF.md`. This Python server is not claimed to be a verified drop-in Sites runtime. No Sites project ID, hosted URL, provisioned storage or published deployment is invented.

## Development and verification

```bash
python build-room.py
python -m pip install -r requirements-dev.txt
python -m pytest -q tests/room/test_room.py
python tests/room/browser_room.py
```

`build-room.py` rebuilds the self-contained room page and mirrors `public/` into `dist/`. It preserves the existing course. Its additional standalone review HTML is written beside the project folder. Rebuilding the original course with `source/build_site.py` must be followed by `python build-room.py` to restore the room navigation/card.

The browser harness needs Chromium. Set `CHROMIUM_PATH` when it is not `/usr/bin/chromium`. This authoring environment blocks browser URL navigation, so that harness injects the document and bridges fetch requests to the real API. The bridge exists **only in the test harness**, not in the distributed website. API tests and separate real HTTP requests exercise the server. See `ROOM_TEST_REPORT.md` for the checks performed and limitations. Older `TEST_RESULTS*` reports describe version 3, not a new certification of every old course feature.
