# Sites handoff: review version 3.0

This is an extension of the existing `codex_science_workshop_site` project, recovered from the user's Library and extended from its saved v2 source. The Sites editor was not exposed through the available tool directory in this session. No claim is made that a live Sites project or deployment was changed.

Use this updated project for review in the existing site, not to replace it with a slide viewer. `public/index.html` is the complete self-contained participant page; `public/` can be served statically. `npm run build` prepares `dist/` and does not publish.

Preserve every original file under `public/downloads/` and the existing practical storage key. Keep the descriptive practical, 90-minute guided route and prepared retrospective statistical example distinct. Do not grant the round A agent access to the whole website or other rounds.

Keep `recovery/`, `tests/`, source review records and any future private facilitator pack outside public deployment assets. Hidden panels are not access control. The current `public/` contains no facilitator materials or private account screenshot.

Before any authorised publication, review source dates and availability in the actual participant environment, confirm the workshop date, and test native storage and download behaviour on the intended host. Existing progress may require JSON export/import when moving origins.

**Save for review only. Publishing or replacing a live deployment requires approval.**
