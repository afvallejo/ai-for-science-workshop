# AI for science: extended Codex workshop companion

**Review version 3.0.0, saved 16 September 2026. Not published.**

This extends the recovered `codex_science_workshop_site` project. It is not the later PowerPoint slide viewer. The original descriptive practical and its download files remain unchanged. Recoverable baselines are `recovery/original_site_v1.zip` and `recovery/saved_site_v2.zip`. This revision edits the saved v2 source project rather than rebuilding a replacement site.

## Open the review version

Open `public/index.html` in a browser. It is self-contained: lessons, original downloads, synthetic data, figure images, scripts and styles are embedded. No account, API key, package installation or external AI call is needed to use its teaching interactions. Source links are opened only when selected.

For a local static preview with Node.js 18 or later:

```sh
npm start
```

Open the local address printed by the server. `npm run build` copies the ready-to-use public files into `dist`. It does not publish them. A static server is only a file-serving preview, not a participant-data backend.

## Teaching and independent reading

The guided route has 30 focused topic views reusing the existing interactive chapter content. Switch between “One topic at a time” and “Read whole chapter”. Topic links, previous/next controls and a chapter topic selector support teaching without embedding PowerPoint slides. Suggested timings total 90 minutes; they are not a running timer. The public teaching outline contains specific visual suggestions, discussion cues and transitions. View preference joins the existing version-2 progress export format.

## Two distinct routes

The guided 90-minute course follows six presentation sections. Its 28-minute cytometry chapter includes an abbreviated 9-minute point-tracing activity. The original full 50-minute A/B/C practical remains separate, descriptive and unchanged. The authorised retrospective statistical example is another clearly labelled section, not a revision to the descriptive exercise.

The date field is intentionally blank and editable. The supplied title slide says 9 September 2026; the appended figures record 15 September. No event date is inferred from the PowerPoint filename.

## Existing practical and progress

All 16 original files in `public/downloads/` are byte-identical to the recovered project, including the CSV, study context, prompts, SKILL.md, participant pack and separate A/B/C ZIPs. Existing relative links remain valid. Original scorecards and practical progress retain the `codex-science-workshop-v1` browser storage key. New course fields use `codex-science-course-v2`.

Existing browser storage is origin-dependent: keeping the same browser and site address is needed for automatic recovery. Moving to another host or file location may not carry saved values across. The new JSON export/import includes course fields and all three practical scorecards. When storage is unavailable, entries remain in memory until the page closes and can still be exported. Do not enter confidential information into the local notes or exports.

Round A must never receive the whole website, the parent pack, the supplied skill, another round's outputs or facilitator materials. Open only the appropriate round folder in Codex.

## Rebuild and test

The prebuilt website requires no build tools. To edit and rebuild content, use Python 3 with Jinja2 and beautifulsoup4:

```sh
python3 source/expand_site.py
npm run build
```

`source/build_site.py` and its original templates preserve the original practical. `source/expand_site.py` decorates that build using the course templates and scripts. The new builder never modifies original download files. Rebuilding does not fetch sources or verify current policies automatically.

Regression testing also requires Python Playwright and a Chromium executable. Set `CHROMIUM_PATH` when it is not `/usr/bin/chromium`:

```sh
python3 tests/run_all.py
```

See `TEST_RESULTS.md` and `TEST_RESULTS.json` for the checks actually run and their environment limitations. This build used direct document injection because browser policy blocked ordinary URL navigation. Real Blob downloads and blocked-storage fallback were tested; persistence and migration used an explicitly labelled storage shim. A native hosted-origin reload was not tested.

## Evidence and remaining dependencies

`CONTENT_MAP.md` maps every one of the 50 actual slide positions, including image-only slides and the deliberately skipped blank slide. `SOURCE_VERIFICATION.md` distinguishes dated presentation examples from points rechecked on 16 September 2026 and failed retrievals. `CHANGE_SUMMARY.md` records the extension and limitations.

The three comparison PNGs are unchanged images extracted from the supplied presentation, not editable figure masters. Numerical, diagnostic, production and regeneration claims for those runs are attributed to the presentation. This build did not rerun those analyses.

Not supplied: the selected FCS dataset and executed notebook; the optional audit CSV fixture and expected-report files; the revised statistical skill, original editable figure masters and run evidence. Missing dependencies are identified in the site rather than invented. The full presentation, private interface screenshot and facilitator materials are excluded from `public/`.

No deployment, analytics, participant-response upload or background task has been added.
