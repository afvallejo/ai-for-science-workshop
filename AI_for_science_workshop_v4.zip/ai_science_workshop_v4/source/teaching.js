'use strict';
(() => {
 const $=id=>document.getElementById(id);
 const topics=JSON.parse($('teaching-data').textContent);
 const field=$('teaching-view-field');
 const chapters=[...new Set(topics.map(t=>t.chapter))];
 const active=Object.fromEntries(chapters.map(c=>[c,topics.find(t=>t.chapter===c).id]));
 let currentTarget=null;
 function saveMode(mode){field.value=mode;field.dispatchEvent(new Event('input',{bubbles:true}));refresh();}
 function reveal(target){
  currentTarget=target;
  const topic=target?.closest('.teaching-topic');
  const chapter=target?.closest('main > section')?.id;
  if(topic)active[chapter]=topic.id;
  else if(chapters.includes(chapter))active[chapter]=topics.find(t=>t.chapter===chapter).id;
  refresh();
 }
 function refresh(){
  $('trace-arithmetic-feedback').textContent='';
  const focus=field.value==='focus';document.body.dataset.teachingMode=focus?'focus':'read';
  document.querySelectorAll('[data-teaching-view]').forEach(b=>b.setAttribute('aria-pressed',String((focus?'focus':'read')===b.dataset.teachingView)));
  document.querySelectorAll('.teaching-topic').forEach(e=>e.hidden=focus&&e.id!==active[e.dataset.chapter]);
  for(const chapter of chapters){
   const group=topics.filter(t=>t.chapter===chapter), t=group.find(t=>t.id===active[chapter])||group[0];
   const toolbar=$(chapter).querySelector('.teaching-toolbar');
   toolbar.querySelector('select').value=t.id;
   const n=topics.findIndex(x=>x.id===t.id)+1, count=group.findIndex(x=>x.id===t.id)+1;
   const elapsed=topics.slice(0,n-1).reduce((a,x)=>a+x.minutes,0);
   // No timer runs: this is the planned teaching position, not elapsed user time.
   toolbar.querySelector('.topic-status').textContent=`Topic ${count} of ${group.length} in this chapter · ${n} of ${topics.length} overall · suggested workshop minute ${elapsed}`;
   toolbar.querySelector('progress').value=n;
   toolbar.querySelector('[data-teach-prev]').textContent=n===1?'← Course home':'← Previous topic';
   toolbar.querySelector('[data-teach-next]').textContent=n===topics.length?'Finish at course home →':'Next topic →';
  }
 }
 function go(id){if(location.hash==='#'+id)window.WorkshopCourse.route();else location.hash=id;}
 function step(chapter,delta){const n=topics.findIndex(t=>t.id===active[chapter])+delta;go(n<0||n>=topics.length?'course':topics[n].id);}
 for(const chapter of chapters){
  const select=$('topic-select-'+chapter);
  topics.filter(t=>t.chapter===chapter).forEach((t,i)=>{const o=document.createElement('option');o.value=t.id;o.textContent=`${i+1}. ${t.title}`;select.append(o);});
  select.addEventListener('change',()=>go(select.value));
 }
 document.querySelectorAll('[data-teaching-view]').forEach(b=>b.addEventListener('click',()=>{
  saveMode(b.dataset.teachingView);
  if(b.dataset.teachingView==='focus')go(active[b.closest('section').id]);
 }));
 document.querySelectorAll('[data-teach-prev]').forEach(b=>b.addEventListener('click',()=>step(b.dataset.teachPrev,-1)));
 document.querySelectorAll('[data-teach-next]').forEach(b=>b.addEventListener('click',()=>step(b.dataset.teachNext,1)));
 document.querySelector('[data-start-guided]').addEventListener('click',e=>{e.preventDefault();saveMode('focus');go(topics[0].id);});
 document.querySelector('[data-read-guided]').addEventListener('click',e=>{e.preventDefault();saveMode('read');go('why');});
 document.addEventListener('keydown',e=>{
  if(field.value!=='focus'||!['ArrowLeft','ArrowRight'].includes(e.key)||e.altKey||e.ctrlKey||e.metaKey||e.shiftKey||document.querySelector('dialog[open]'))return;
  if(e.target.closest('input,textarea,select,button,a,summary,[contenteditable="true"],[role="tablist"],[role="region"]'))return;
  const section=document.querySelector('main>section:not([hidden])');if(!section||!chapters.includes(section.id))return;
  e.preventDefault();step(section.id,e.key==='ArrowRight'?1:-1);
 });
 $('check-trace-mean').addEventListener('click',()=>{
  const input=$('trace-your-mean'),value=Number(input.value),out=$('trace-arithmetic-feedback');
  if(input.value.trim()===''||!Number.isFinite(value)||value<0||value>100){out.textContent='Enter a percentage between 0 and 100 before checking.';return;}
  const d=$('trace-donor').value,t=$('trace-treatment').value,s=$('trace-stimulation').value;
  const mean=window.WorkshopCourse.culture(d,t,s);
  const same=Math.abs(value-mean)<0.00050000001;
  out.textContent=(same?'Matches the supplied two-aliquot mean. ':'Does not match the supplied two-aliquot mean. ')+`${d}, ${t}, ${s}: ${mean.toFixed(3)}%. This verifies arithmetic only, not gating or event counts.`;
 });
 for(const id of ['trace-donor','trace-treatment','trace-stimulation','trace-your-mean'])$(id).addEventListener('input',()=>$('trace-arithmetic-feedback').textContent='');
 window.WorkshopTeaching={reveal,refresh};
 let target;try{target=$(decodeURIComponent(location.hash.slice(1)))}catch(_){target=null;}
 reveal(target||$('course'));
})();
