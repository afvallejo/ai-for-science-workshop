#!/usr/bin/env python3
"""Build a dependency-free participant website from the supplied workshop files."""
from pathlib import Path
import base64, csv, io, json
from jinja2 import Environment, FileSystemLoader, select_autoescape
ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'public' / 'downloads'
read = lambda n: (ASSETS / n).read_text(encoding='utf-8')
rows = list(csv.DictReader(io.StringIO(read('data.csv'))))
assets = {}
for path in sorted(ASSETS.iterdir()):
    if path.is_file():
        mime = {'.zip':'application/zip','.csv':'text/csv','.txt':'text/plain','.md':'text/markdown'}.get(path.suffix,'application/octet-stream')
        assets[path.name] = {'base64':base64.b64encode(path.read_bytes()).decode('ascii'),'mime':mime}
def safe_json(value):
    return json.dumps(value,ensure_ascii=True,separators=(',',':')).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
context = dict(
    navigation=[('overview','Overview'),('setup','Setup'),('data','Study and data'),('rounds','Three rounds'),('skill','Scientific-figure skill'),('review','Review scorecard'),('resources','Downloads')],
    css=(ROOT/'source/site.css').read_text(), js=(ROOT/'source/site.js').read_text(),
    assets_json=safe_json(assets),rows_json=safe_json(rows),rows=rows,
    pack_kb=round((ASSETS/'participant_pack.zip').stat().st_size/1024),
    donors=sorted({r['donor_id'] for r in rows}),
    context=read('study_context.md'),skill=read('SKILL.md'),
    prompts={r:read('prompt_'+r+'.txt') for r in 'ABC'},
    tab_titles={'A':'A · Basic prompt','B':'B · Skill + basic','C':'C · Skill + loop'},
    round_titles={'A':'Start with the basic request.','B':'Add reusable scientific standards.','C':'Require evidence for each revision.'},
    round_descriptions={
        'A':'The model receives the data and complete study notes, but no workshop-supplied figure skill. Keep its first completed result.',
        'B':'Use the identical task with the supplied science-figure skill. Do not add an explicit multi-pass revision protocol.',
        'C':'Use the same task and skill, plus an initial version and at most two revision passes. Preserve the evidence for what changed.'},
    round_checks={
        'A':['Open the saved figure yourself and retain every requested deliverable.','Record settings, elapsed time, human interventions and any technical failure in run_log.csv.','Do not add the skill, coach the model or carry its output into another round.'],
        'B':['Confirm that the actual skill instructions were read; a claimed activation is not sufficient.','Retain the first completed result and record the loading method and any interventions.','Start C from its original inputs, not from the figure or code created here.'],
        'C':['Inspect the actual archived versions and compare them with iteration_log.md.','Check that claimed fixes occurred and did not create new problems. NOT VERIFIED is not a pass.','Record the version count, reason for stopping, elapsed time and remaining limitations.']},
    standards=[('Understand the design','Identify the endpoint, experimental unit, technical replication, pairing and intended contrasts.'),('Calculate from inputs','Use saved executable code. Aggregate technical measurements as specified and preserve all donor records.'),('Show biological variation','Make individual donor values and paired comparisons understandable, rather than hiding them behind summaries.'),('Make the figure readable','Use explicit units, legible marks and labels, appropriate axes and colour-independent cues.'),('Deliver reproducible files','Save the figure, plotted values, code, caption, regeneration command and software versions.'),('Verify what was produced','Run the code, compare values with the inputs, inspect the rendered image and disclose unresolved limitations.')],
    dictionary=[('donor_id','Simulated donor identifier and biological pairing key.'),('sample_id','Culture identifier; appears once for each of its two technical aliquots.'),('technical_replicate','Technical aliquot number, 1 or 2, within a culture.'),('treatment','Vehicle or Compound_X.'),('stimulation','Unstimulated or Stimulated.'),('activation_percent','CD69+CD137+ frequency in the specified CD8 parent, already in percent.'),('data_origin','Always synthetic.')],
    domains=[{'key':'scientific_integrity','title':'Scientific integrity','description':'Correct culture means, n = 10 donors per condition, units, CD8 denominator and contrasts. No changed, excluded or invented data.'},{'key':'design_communication','title':'Communication of the design','description':'Donor variation is visible. Pairing and treatment comparisons are apparent. Stimulation conditions remain distinguishable.'},{'key':'visual_quality','title':'Visual quality','description':'Text and marks are readable at the stated size. Nothing is clipped. Labels, legend and axes are clear and not misleading.'},{'key':'reproducibility','title':'Reproducibility','description':'Saved code actually regenerates the result in a fresh output directory from unchanged inputs. Values agree; command and versions are given.'},{'key':'reporting','title':'Reporting','description':'The legend defines synthetic status, endpoint, denominator, biological n, technical replication, aggregation, pairing and any summaries or error bars.'}],
    timeline=[('0 to 5','Introduce the design'),('5 to 13','Round A'),('13 to 21','Round B'),('21 to 33','Round C'),('33 to 43','Blind human review'),('43 to 50','Reveal and discuss')],
    downloads=[('participant_pack.zip','Complete participant pack','Three projects, prompts, skill, scorecard and run log.','ZIP'),('data.csv','Synthetic activation data','All 80 original technical measurements, unchanged.','CSV'),('study_context.md','Study context','Design, units, pairing and deliverable requirements.','MD'),('science_figure_skill.zip','Scientific-figure skill','Complete local skill folder, with metadata.','ZIP'),('SCORECARD.md','Printable review scorecard','Five domains and separate scientific/reproducibility gates.','MD'),('run_log.csv','Run log template','Record settings, time, interventions and outcomes.','CSV'),('PROMPTS.md','All three prompts','Exact workshop prompt text for A, B and C.','MD'),('SHA256SUMS.txt','Download checksums','SHA-256 hashes for the supplied downloads.','TXT')]
)
env=Environment(loader=FileSystemLoader(ROOT/'source'),autoescape=select_autoescape(default_for_string=True,default=True))
# Raw code and JSON are trusted local build inputs. All instructional content is escaped.
from markupsafe import Markup
for key in ['css','js','assets_json','rows_json']:
    context[key] = Markup(context[key])
html=env.get_template('site.html.j2').render(**context)
assert '\u2014' not in html and '\u2013' not in html
out=ROOT/'public/index.html';out.write_text(html,encoding='utf-8')
print(f'Built {out} ({out.stat().st_size:,} bytes) with {len(assets)} embedded downloads.')
