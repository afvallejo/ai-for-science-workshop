'use strict';
(() => {
  const assets = JSON.parse(document.getElementById('workshop-assets').textContent);
  const rows = JSON.parse(document.getElementById('workshop-data').textContent);
  const storageKey = 'codex-science-workshop-v1';
  const domainKeys = ['scientific_integrity','design_communication','visual_quality','reproducibility','reporting'];
  const emptyReview = () => ({label:'',reviewer:'',scores:{},evidence:{},scientificGate:'',regeneration:'',note:''});
  let state = {progress:{},reviews:[emptyReview(),emptyReview(),emptyReview()]};
  let storageAvailable = true;
  try {
    const stored = JSON.parse(localStorage.getItem(storageKey) || 'null');
    if (stored && typeof stored === 'object') {
      if (stored.progress && typeof stored.progress === 'object') state.progress = stored.progress;
      if (Array.isArray(stored.reviews) && stored.reviews.length === 3) {
        state.reviews = stored.reviews.map(r => ({...emptyReview(), ...r, scores:r.scores || {}, evidence:r.evidence || {}}));
      }
    }
  } catch (_) { storageAvailable = false; }
  let toastTimer;
  function toast(text) {
    const el = document.getElementById('toast');
    el.textContent = text; el.hidden = false;
    clearTimeout(toastTimer); toastTimer = setTimeout(() => { el.hidden = true; }, 3500);
  }
  function setStorageNotice() {
    if (!storageAvailable) {
      document.getElementById('storage-status').textContent = 'Browser storage is unavailable. Entries last only while this page stays open. Export your reviews before closing or reloading.';
      document.getElementById('side-storage-text').textContent = 'Browser storage is unavailable. Export your scorecards before closing this page.';
    }
  }
  function persist() {
    try { localStorage.setItem(storageKey, JSON.stringify(state)); }
    catch (_) { storageAvailable = false; setStorageNotice(); }
  }
  setStorageNotice();
  function saveBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url; link.download = filename; link.style.display = 'none';
    document.body.appendChild(link); link.click(); link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  }
  document.querySelectorAll('[data-download]').forEach(link => {
    link.addEventListener('click', event => {
      const filename = link.dataset.download;
      if (!assets[filename]) return; // Relative links remain a static-host fallback.
      event.preventDefault();
      try {
        const binary = atob(assets[filename].base64);
        const bytes = Uint8Array.from(binary, c => c.charCodeAt(0));
        saveBlob(new Blob([bytes], {type:assets[filename].mime}), filename);
        toast('Download requested: ' + filename);
      } catch (_) { toast('Download could not start. Use the extracted website package.'); }
    });
  });
  async function copyText(id, button) {
    const source = document.getElementById(id);
    const text = source.textContent;
    let copied = false;
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text); copied = true;
      }
    } catch (_) { /* Browser permissions may require the local fallback. */ }
    if (!copied) {
      const area = document.createElement('textarea');
      area.value = text; area.setAttribute('readonly','');
      area.style.cssText = 'position:fixed;left:-9999px;top:0;';
      document.body.appendChild(area); area.select();
      try { copied = document.execCommand('copy'); } catch (_) {}
      area.remove();
    }
    if (copied) {
      const old = button.textContent; button.textContent = 'Copied';
      toast('Complete text copied.'); setTimeout(() => {button.textContent = old;}, 2000);
    } else {
      const range = document.createRange(); range.selectNodeContents(source);
      const selection = window.getSelection(); selection.removeAllRanges(); selection.addRange(range);
      toast('Clipboard blocked. Text selected; use your browser copy command.');
    }
  }
  document.querySelectorAll('[data-copy]').forEach(button => button.addEventListener('click', () => copyText(button.dataset.copy,button)));
  function setRound(round, focus=false) {
    if (!'ABC'.includes(round) || round.length !== 1) return;
    document.querySelectorAll('[data-round]').forEach(tab => {
      const selected = tab.dataset.round === round;
      tab.setAttribute('aria-selected', String(selected)); tab.tabIndex = selected ? 0 : -1;
      document.getElementById('panel-'+tab.dataset.round).hidden = !selected;
      if (selected && focus) tab.focus();
    });
  }
  document.querySelectorAll('[data-round]').forEach(tab => {
    tab.addEventListener('click', () => setRound(tab.dataset.round));
    tab.addEventListener('keydown', event => {
      const i = 'ABC'.indexOf(tab.dataset.round);
      const targets = {ArrowRight:(i+1)%3,ArrowLeft:(i+2)%3,Home:0,End:2};
      if (Object.prototype.hasOwnProperty.call(targets,event.key)) {
        event.preventDefault(); setRound('ABC'[targets[event.key]],true);
      }
    });
  });
  document.querySelectorAll('[data-round-link]').forEach(link => link.addEventListener('click',() => setRound(link.dataset.roundLink)));
  document.getElementById('mobile-nav').addEventListener('change', event => { location.hash = event.target.value; });
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver(entries => {
      for (const entry of entries) if (entry.isIntersecting) {
        document.querySelectorAll('.sidebar nav a').forEach(link => {
          if (link.hash === '#' + entry.target.id) link.setAttribute('aria-current','location');
          else link.removeAttribute('aria-current');
        });
        document.getElementById('mobile-nav').value = entry.target.id;
      }
    }, {rootMargin:'-8% 0px -65% 0px',threshold:0});
    document.querySelectorAll('main>section').forEach(section => observer.observe(section));
  }
  let dataPage = 0;
  const pageSize = 10;
  function renderData() {
    const donor = document.getElementById('filter-donor').value;
    const stim = document.getElementById('filter-stimulation').value;
    const filtered = rows.filter(row => (!donor || row.donor_id === donor) && (!stim || row.stimulation === stim));
    const maxPage = Math.max(0,Math.ceil(filtered.length / pageSize)-1);
    dataPage = Math.min(dataPage,maxPage);
    const start = dataPage * pageSize;
    const tbody = document.getElementById('data-body'); tbody.replaceChildren();
    filtered.slice(start,start+pageSize).forEach(row => {
      const tr = document.createElement('tr');
      ['donor_id','sample_id','technical_replicate','treatment','stimulation','activation_percent'].forEach(key => {
        const td = document.createElement('td'); td.textContent = row[key];
        if (key === 'activation_percent') td.className = 'numeric';
        tr.appendChild(td);
      });
      tbody.appendChild(tr);
    });
    document.getElementById('data-count').textContent = filtered.length ? `Rows ${start+1} to ${Math.min(start+pageSize,filtered.length)} of ${filtered.length} · all synthetic` : 'No matching rows';
    document.getElementById('data-prev').disabled = dataPage === 0;
    document.getElementById('data-next').disabled = dataPage >= maxPage;
  }
  ['filter-donor','filter-stimulation'].forEach(id => document.getElementById(id).addEventListener('change', () => {dataPage=0;renderData();}));
  document.getElementById('data-prev').addEventListener('click',() => {dataPage--;renderData();});
  document.getElementById('data-next').addEventListener('click',() => {dataPage++;renderData();});
  renderData();
  function renderProgress() {
    const keys = ['setup','round-A','round-B','round-C','review'];
    const count = keys.filter(key => Boolean(state.progress[key])).length;
    document.querySelectorAll('[data-progress]').forEach(input => {input.checked = Boolean(state.progress[input.dataset.progress]);});
    document.getElementById('progress-text').textContent = `${count} / 5`;
    document.getElementById('progress-bar').style.width = `${count*20}%`;
    document.querySelector('.side-progress').setAttribute('aria-valuenow', String(count));
  }
  document.querySelectorAll('[data-progress]').forEach(input => input.addEventListener('change',() => {state.progress[input.dataset.progress]=input.checked;persist();renderProgress();}));
  renderProgress();
  let currentReview = 0;
  function scoreSummary() {
    const r = state.reviews[currentReview];
    const scored = domainKeys.filter(key => ['0','1','2'].includes(String(r.scores[key])));
    const total = scored.reduce((sum,key) => sum + Number(r.scores[key]),0);
    const totalEl = document.getElementById('score-total');
    totalEl.replaceChildren(document.createTextNode(String(total)+' '));
    const detail = document.createElement('small'); detail.textContent = `/ 10 · ${scored.length} of 5 scored`; totalEl.appendChild(detail);
    const status = document.getElementById('score-status'); status.className = 'score-status';
    if (r.scientificGate === 'FAIL') {
      status.textContent = 'Not ready for a manuscript. A material scientific error overrides the numerical score.';status.classList.add('fail');
    } else if (r.regeneration === 'FAIL') {
      status.textContent = 'Regeneration failed. Resolve the execution problem before accepting the output.';status.classList.add('fail');
    } else if (r.scientificGate !== 'PASS' || r.regeneration !== 'PASS' || scored.length < 5) {
      status.textContent = 'Review incomplete. Assess the scientific gate and demonstrate regeneration separately.';
    } else {
      const issues = domainKeys.some(key => Number(r.scores[key]) < 2);
      status.textContent = issues ? 'Gates marked PASS, but scored limitations remain. Document the required corrections.' : 'Local checks marked PASS. This is not independent publication approval.';
      if (!issues) status.classList.add('pass');
    }
  }
  function loadReview(index) {
    currentReview = index;
    document.querySelectorAll('[data-review]').forEach(b => b.setAttribute('aria-pressed',String(Number(b.dataset.review)===index)));
    const r=state.reviews[index];
    document.getElementById('review-label').value = r.label;
    document.getElementById('reviewer').value = r.reviewer;
    document.getElementById('scientific-gate').value = r.scientificGate;
    document.getElementById('regeneration').value = r.regeneration;
    document.getElementById('review-note').value = r.note;
    document.querySelectorAll('[data-score]').forEach(el => {el.value=r.scores[el.dataset.score] ?? '';});
    document.querySelectorAll('[data-evidence]').forEach(el => {el.value=r.evidence[el.dataset.evidence] ?? '';});
    scoreSummary();
  }
  function captureReview() {
    const r=state.reviews[currentReview];
    r.label=document.getElementById('review-label').value;
    r.reviewer=document.getElementById('reviewer').value;
    r.scientificGate=document.getElementById('scientific-gate').value;
    r.regeneration=document.getElementById('regeneration').value;
    r.note=document.getElementById('review-note').value;
    document.querySelectorAll('[data-score]').forEach(el => {r.scores[el.dataset.score]=el.value;});
    document.querySelectorAll('[data-evidence]').forEach(el => {r.evidence[el.dataset.evidence]=el.value;});
    persist();scoreSummary();
  }
  document.getElementById('review-form').addEventListener('input',captureReview);
  document.getElementById('review-form').addEventListener('change',captureReview);
  document.getElementById('review-form').addEventListener('submit',event => event.preventDefault());
  document.querySelectorAll('[data-review]').forEach(b => b.addEventListener('click',() => {captureReview();loadReview(Number(b.dataset.review));}));
  loadReview(0);
  // Prefix formula-like free text so an exported review is not executable in a spreadsheet.
  function csvCell(value) {
    let text = String(value ?? '');
    if (/^[\s\u0000-\u001f]*[=+@-]/.test(text)) text = "'" + text;
    return '"' + text.replaceAll('"','""') + '"';
  }
  document.getElementById('export-reviews').addEventListener('click',() => {
    captureReview();
    const header=['review_number','blind_figure_label','reviewer_group'];
    domainKeys.forEach(key => {header.push(key+'_0_2',key+'_evidence');});
    header.push('total_0_10','domains_scored','scientific_gate','regeneration_status','notes');
    const out=[header];
    state.reviews.forEach((r,i) => {
      const line=[i+1,r.label,r.reviewer];
      domainKeys.forEach(key => {line.push(r.scores[key] ?? '',r.evidence[key] ?? '');});
      const valid=domainKeys.filter(key => ['0','1','2'].includes(String(r.scores[key])));
      const total=valid.reduce((sum,key) => sum+Number(r.scores[key]),0);
      line.push(total,valid.length,r.scientificGate,r.regeneration,r.note);out.push(line);
    });
    saveBlob(new Blob(['\ufeff'+out.map(line=>line.map(csvCell).join(',')).join('\r\n')+'\r\n'],{type:'text/csv;charset=utf-8'}),'codex_workshop_reviews.csv');
    toast('Review export requested. It includes all three review records.');
  });
  document.getElementById('clear-work').addEventListener('click',() => {
    if (!window.confirm('Clear the saved progress and all three scorecards in this browser? Export your reviews first.')) return;
    state={progress:{},reviews:[emptyReview(),emptyReview(),emptyReview()]};persist();renderProgress();loadReview(0);toast('Saved workshop progress and scorecards cleared.');
  });
  document.getElementById('print-page').addEventListener('click',() => window.print());
})();
