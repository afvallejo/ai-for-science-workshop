#!/usr/bin/env python3
"""Rebuild the original practical, then extend it without changing its downloads.
Requires Python 3, Jinja2 and beautifulsoup4. No network or AI calls.
"""
from pathlib import Path
import base64, csv, hashlib, io, json, subprocess, sys
from bs4 import BeautifulSoup
from jinja2 import Environment, FileSystemLoader, select_autoescape
from course_content import CHAPTERS, NAVIGATION, MAP, SOURCES, GLOSSARY
from teaching import add_teaching
ROOT=Path(__file__).resolve().parents[1]
PUB=ROOT/'public'; SRC=ROOT/'source'
subprocess.run([sys.executable,str(SRC/'build_site.py')],check=True)
original=PUB/'downloads'; extras=PUB/'course-downloads'; extras.mkdir(exist_ok=True)
rows=list(csv.DictReader(io.StringIO((original/'data.csv').read_text())))
# Downloadable map and provenance are new files; originals are read-only inputs.
map_text='# Presentation content map\n\nActual 1-based slide positions, not printed slide numbers. Built 16 September 2026.\n\n| Position | Title / subject | Destination | Handling |\n|---|---|---|---|\n'
for r in MAP: map_text+='| '+ ' | '.join(str(r[k]).replace('|','/') for k in ('position','title','destination','handling'))+' |\n'
for p in (ROOT/'CONTENT_MAP.md',extras/'content_map.md'): p.write_text(map_text)
s=io.StringIO(newline=''); w=csv.DictWriter(s,fieldnames=['position','title','destination','handling']); w.writeheader();w.writerows(MAP)
(extras/'content_map.csv').write_text(s.getvalue())
source_text='# Source verification register\n\nWebsite build checks: 16 September 2026. Presentation check date: 9 September 2026 unless otherwise specified; statistical appendix: 15 September 2026.\n\n'
for id,title,url,status,kind,positions in SOURCES:
    source_text+=f'## {title}\n\nStatus: {kind}. Presentation positions: {positions}.\n\n{status}\n\n{url}\n\n'
(extras/'source_verification.md').write_text(source_text);(ROOT/'SOURCE_VERIFICATION.md').write_text(source_text)
# Annotated viewer displays byte-for-byte original section strings, no revised skill is invented.
skill=(original/'SKILL.md').read_text(); chunks=[]; current=[]
for line in skill.splitlines(keepends=True):
    if line.startswith('## ') and current: chunks.append(''.join(current));current=[]
    current.append(line)
if current:chunks.append(''.join(current))
explanations=['Metadata and purpose: tells the system when this workflow is relevant. It does not grant access or validate a method.','Establish the experimental design and calculate faithfully from supplied inputs. Technical repeats are not new donors.','Choose a visual representation that makes biological variation, units and comparisons interpretable.','Save reproducible files, reopen the actual rendering and state checks and limitations.','Define evidence required for acceptance. This quality standard is different from the explicit bounded loop in round C.']
skill_sections=[dict(title=(c.splitlines()[0][3:] if c.startswith('## ') else 'Skill metadata and purpose'),text=c,explanation=explanations[i]) for i,c in enumerate(chunks)]
figure_data=['data:image/png;base64,'+base64.b64encode((PUB/'assets'/f'figure-{i}.png').read_bytes()).decode() for i in (1,2,3)]
env=Environment(loader=FileSystemLoader(SRC),autoescape=select_autoescape(default=True))
course=env.get_template('course.html.j2').render(chapters=CHAPTERS,content_map=MAP,sources_list=SOURCES,source_names={s[0]:s[1].split(':')[0]+(': '+s[1].split(':',1)[1].strip()[:34] if ':' in s[1] else '') for s in SOURCES},glossary=GLOSSARY,skill_sections=skill_sections,figure_data=figure_data,donors=sorted({r['donor_id'] for r in rows}),audit_rows=[['S01','D01','A','B1'],['S03','D03','A','B1'],['S02','D02','A','B2'],['S03','D03','A','B1'],['S04','D04','B','B2'],['S05','D05','B',''],['S06','D06','B','B1']])
soup=BeautifulSoup((PUB/'index.html').read_text(),'html.parser')
soup.title.string='AI for science | Codex workshop companion'
soup.find('meta',attrs={'name':'description'})['content']='An interactive 90-minute AI for science course and the original 50-minute descriptive figure practical, with source-linked lessons, local progress, downloadable files and prepared examples.'
style=soup.new_tag('style');style.string=(SRC/'course.css').read_text()+'\n'+(SRC/'teaching.css').read_text();soup.head.append(style)
for nav in soup.select('.sidebar nav'):
    nav.clear()
    for idx,(ident,label) in enumerate(NAVIGATION):
        a=soup.new_tag('a',href='#'+ident);a.string=label
        if idx==0:a['aria-current']='location'
        nav.append(a)
soup.select_one('.brand')['href']='#course'
soup.select_one('.side-kicker').string='Workshop companion'
soup.select_one('.count-line span').string='Practical progress'
cc=soup.new_tag('p',attrs={'class':'side-course-count','id':'course-progress'});cc.string='Chapters: 0 / 6';soup.select_one('.side-bottom').insert(0,cc)
soup.select_one('.mobile-head a')['href']='#course'
select=soup.find(id='mobile-nav');select.clear()
for ident,label in NAVIGATION:
    o=soup.new_tag('option',value=ident);o.string=label;select.append(o)
soup.select_one('.topline').clear()
for text in ['AI FOR SCIENCE / WORKSHOP COMPANION','REVIEW VERSION 3.0 · SAVED, NOT PUBLISHED']:
    span=soup.new_tag('span');span.string=text;soup.select_one('.topline').append(span)
main=soup.find(id='main');course_soup=BeautifulSoup(course,'html.parser')
first_original=soup.find(id='overview')
# Six chapters and home precede the preserved practical; references follow it.
for sec in list(course_soup.find_all('section',recursive=False)):
    if sec['id'] in ['course']+[c[0] for c in CHAPTERS]: first_original.insert_before(sec.extract())
    else: main.append(sec.extract())
practicalnav=BeautifulSoup('<nav class="practical-nav" aria-label="Full practical sections">' + ''.join(f'<a href="#{x}">{label}</a>' for x,label in [('course','Course home'),('overview','Practical overview'),('setup','Setup'),('data','Study and data'),('rounds','A/B/C rounds'),('skill','Skill'),('review','Scorecards'),('run-log','Run log')])+'</nav>','html.parser').nav
first_original.insert(0,practicalnav)
# Add a complete editable run log matching the unchanged CSV schema.
headers=next(csv.reader(io.StringIO((original/'run_log.csv').read_text())))
pretty={'group_id':'Group ID','condition':'Round condition','run_order':'Run order','model_label':'Exact model label','reasoning_setting':'Reasoning setting','client_version':'Client version','environment':'Runtime and software environment','global_instructions_or_skills':'Global instructions or pre-existing skills','workshop_skill_loaded':'Was the supplied skill loaded?','skill_loading_method':'Skill loading method / evidence','elapsed_minutes':'Observed elapsed minutes','human_interventions':'Human interventions','rendered_versions':'Rendered versions','visual_inspection_evidence':'Actual rendering inspection evidence','usage_if_available':'Usage, only if observed','scientific_gate':'Scientific gate','regeneration_status':'Regeneration status','notes':'Notes and limitations'}
log='<div class="interaction" id="run-log"><span class="eyebrow">Full practical / run log</span><h2>Record what happened in each round.</h2><p>This form exports the unchanged run-log schema. Enter observed settings and outcomes, not predictions. Review each figure independently in the scorecards above; recording a score here does not score or approve it automatically.</p><div class="mini-log">'
for round in 'ABC':
    log+=f'<details><summary>Round {round}: settings, interventions and outcomes</summary><div class="details-body"><div class="fields">'
    for h in headers:
        if h=='condition':continue
        label=pretty.get(h,h.replace('_0_2',' (0 to 2)').replace('_',' ').capitalize())
        log+=f'<label><span>{label}</span><input type="text" data-course-field="log-{round}-{h}" aria-label="Round {round}: {label}"></label>'
    log+='</div></div></details>'
log+='</div><button type="button" class="btn primary" id="export-run-log">Export all three run logs (CSV)</button></div>'
soup.find(id='review').append(BeautifulSoup(log,'html.parser'))
# New progress and provenance controls are consolidated with original downloads.
resource_ext='''<div class="interaction" id="progress-tools"><span class="eyebrow">Local workspace</span><h2>Save your progress and evidence.</h2><p>Export includes course fields, the three original independent scorecards and practical progress. Import restores a local export. Nothing is sent to a server. Keep confidential data out of your notes.</p><p id="course-storage-status" role="status">Progress is stored in this browser where permitted. Export before moving devices.</p><div class="progress-tools"><button type="button" class="btn primary" id="export-progress">Export all progress (JSON)</button><label class="btn" for="import-progress">Import saved progress</label><input type="file" id="import-progress" accept=".json,application/json" class="sr-only"><button type="button" class="btn" id="reset-course">Reset course and practical</button></div><p id="import-status" class="small" aria-live="polite"></p></div><div class="interaction"><span class="eyebrow">New teaching and review files</span><h2>Content map and source record.</h2><p><a class="btn" data-course-download="content_map.md" href="course-downloads/content_map.md" download>Content map (Markdown)</a> <a class="btn" data-course-download="content_map.csv" href="course-downloads/content_map.csv" download>Content map (CSV)</a> <a class="btn" data-course-download="source_verification.md" href="course-downloads/source_verification.md" download>Source verification register</a></p><p class="small">The original downloads above are byte-for-byte preserved. No facilitator pack, private account screenshot or unavailable figure master is included.</p></div>'''
soup.find(id='resources').append(BeautifulSoup(resource_ext,'html.parser'))
dialog=BeautifulSoup('''<dialog id="figure-dialog" class="zoom-dialog" aria-labelledby="zoom-title"><div class="zoom-toolbar"><strong id="zoom-title">Prepared figure</strong><div class="choice-row"><button type="button" class="btn small" id="zoom-out" aria-label="Zoom out">−</button><button type="button" class="btn small" id="zoom-in" aria-label="Zoom in">+</button><button type="button" class="btn small" id="zoom-close">Close</button></div></div><p class="small">Use the scroll area at higher zoom. Escape closes this view.</p><div class="zoom-viewport" tabindex="0" role="region" aria-label="Zoomed figure scroll area"><img id="zoom-image" alt=""></div></dialog>''','html.parser').dialog
soup.body.append(dialog)
# Preserve the core script and storage key; expose validated state for export/import.
js=soup.find_all('script')[-1]
core=js.string or js.get_text()
core=core.replace("if ('IntersectionObserver' in window) {","if (false && 'IntersectionObserver' in window) {") # routing replaces scrollspy only
expose='''
  window.WorkshopPractical = {
    getState: () => { captureReview(); return JSON.parse(JSON.stringify(state)); },
    setState: incoming => {
      if (!incoming || !Array.isArray(incoming.reviews) || incoming.reviews.length !== 3) throw new Error('Invalid practical state');
      const clean={progress:{},reviews:incoming.reviews.map(r=>{
        if (!r || typeof r!=='object') throw new Error('Invalid review');
        const n=emptyReview();
        for (const k of ['label','reviewer','scientificGate','regeneration','note']) n[k]=typeof r[k]==='string'?r[k].slice(0,20000):'';
        for(const k of domainKeys){n.scores[k]=['0','1','2'].includes(String(r.scores?.[k]))?String(r.scores[k]):'';n.evidence[k]=typeof r.evidence?.[k]==='string'?r.evidence[k].slice(0,20000):'';}
        return n;
      })};
      for (const k of ['setup','round-A','round-B','round-C','review']) clean.progress[k]=incoming.progress?.[k]===true;
      state=clean; persist(); renderProgress(); loadReview(0);
    },
    clear: () => {state={progress:{},reviews:[emptyReview(),emptyReview(),emptyReview()]};persist();renderProgress();loadReview(0);},
    storageAvailable: () => storageAvailable
  };
'''
assert core.endswith('})();') or core.rstrip().endswith('})();')
core=core.rstrip()[:-5]+expose+'})();'
js.string=core
teaching_data=add_teaching(soup,ROOT)
extra_assets={p.name:{'base64':base64.b64encode(p.read_bytes()).decode(),'mime':'text/csv' if p.suffix=='.csv' else 'text/markdown'} for p in extras.iterdir() if p.is_file()}
data={'assets':extra_assets,'logHeaders':headers}
t=soup.new_tag('script',type='application/json',id='course-data');t.string=json.dumps(data,ensure_ascii=True).replace('<','\\u003c');soup.body.append(t)
t=soup.new_tag('script');t.string=(SRC/'course.js').read_text();soup.body.append(t)
t=soup.new_tag('script',type='application/json',id='teaching-data');t.string=json.dumps(teaching_data,ensure_ascii=True).replace('<','\\u003c');soup.body.append(t)
t=soup.new_tag('script');t.string=(SRC/'teaching.js').read_text();soup.body.append(t)
# Outbound references are user-initiated only, never requested automatically.
for a in soup.select('a[href^="https://"]'):a['rel']='noopener noreferrer';a['target']='_blank'
out=str(soup)
assert '\u2014' not in out and '\u2013' not in out, 'Em/en dash in website'
(PUB/'index.html').write_text(out,encoding='utf-8')
print('Extended website:',len(out.encode()),'bytes; all original downloads remain untouched.')
