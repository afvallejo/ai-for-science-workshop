"""A paced teaching view of the existing chapter DOM, not a second course.
Only public teaching cues derived from the supplied deck belong here.
"""
from pathlib import Path
from bs4 import BeautifulSoup

# chapter, start element, title, minutes, source positions, question, transition
TOPICS = [
('why','science-tasks','A polished answer is not yet a checked result',2,'1, 11','Would a plausible figure be enough to put in a paper? Name the file or calculation you would need to inspect.','Start with a task you can check, then distinguish the model from its working environment.'),
('why','working-contexts','The engine, the interface and the available actions',2,'1, 5, 7','An assistant can describe a calculation. What additional capability lets it actually run that calculation?','Now choose the working context for the task, not a universal winner.'),
('why','task-fit','Choose a task fit, not a favourite brand',1.5,'12, 13','Give both systems equivalent permitted inputs. What would make the comparison fair?','Test that choice against three concrete scientific tasks.'),
('why','mode-exercise','Which inputs, tools and outputs does this task need?',1.5,'16','Discuss one defensible working context for each scenario, and the evidence you would inspect.','Product choice does not tell us what AI-assisted writing estimates actually measure.'),
('why','writing-evidence','A population estimate is not a paper detector',3,'3','Does 89% mean 89% of every paper was generated? Explain why that interpretation is unsupported.','Writing assistance is one use. Agents add actions and feedback, which require explicit boundaries.'),
('agents','agent-loop','Inspect, choose, act, check',3,'8, 9, 10, 14, 15','When an audit finds a duplicate, should the next action be a merge or a request for evidence?','A useful loop needs a brief that defines what success means.'),
('agents','brief-builder','Replace “analyse my experiment” with a reviewable task',3,'17, 18','Write an outcome, exact inputs, boundaries, evidence and a stopping condition. Leave unresolved choices unresolved.','A clear brief makes a proposed plan easier to challenge.'),
('agents','plan-mode','Agree the approach before implementation',1.5,'19','Which parts are inspection, which are proposed actions, and which still require a decision?','Read-only inspection is not permission to repair scientific metadata.'),
('agents','plan-review','Three persuasive proposals that need a stop',2,'20','Challenge discarding duplicate records, filling batch labels and starting differential expression. What evidence is missing?','Turn the boundary into an explicit finish condition.'),
('agents','goal-conditions','Define “done”, including when to ask',1.5,'21','Could another researcher tell whether the objective had been met from the saved output alone?','Repeated tasks also benefit from inspectable procedures.'),
('agents','capabilities','A procedure is not a permission',2,'23','A laboratory protocol describes a procedure; it is not the instrument or the key to the laboratory. Which concept does each represent here?','Inspect the actual figure skill before asking the system to use it.'),
('agents','skill-inspector','Quality requirements are not an instruction to keep revising',5,'22, 45 to 50','Find a scientific requirement, a rendering check and a stop condition. Which additional protocol belongs only to round C?','The work needed for those checks, not the length of the final answer, affects usage.'),
('usage','token-concepts','A short answer can involve substantial processing',2,'24','Where could a one-sentence answer hide many file reads, model calls and reasoning tokens?','Hold a workload constant to understand rates, not to predict a whole task.'),
('usage','workload','Show the arithmetic, keep the assumptions visible',4,'25','Change cached input or the number of calls. Which assumptions are held constant and which costs are excluded?','A speed tier and reasoning effort are separate controls.'),
('usage','model-settings','Reasoning depth is different from latency',2,'26','Would faster model output necessarily make a workflow dominated by tool execution finish proportionally faster?','Account allowance is another separate quantity.'),
('usage','allowances','A budget is not a fixed number of prompts',2,'27','Why can two apparently similar requests consume different amounts of an allowance?','Before spending an allowance on research files, establish what happens to the information.'),
('privacy','data-boundary','Local files do not prove local-only processing',2,'28','The FCS file stays on a laptop, but a plot is sent to a cloud model. What information crossed the boundary?','Account terms change the answers, but do not replace institutional approval.'),
('privacy','account-comparison','Check the account and sign-in route',4,'29, 30','Separate personal, organisational, temporary or incognito, and API contexts. What evidence identifies the one actually being used?','A zero-retention claim needs an equally precise scope.'),
('privacy','zdr','Zero Data Retention is not a promise about every copy',2,'31','Which organisation, model, endpoint, feature and connected service does the agreement cover?','Record the evidence before sharing, rather than treating an account label as permission.'),
('privacy','before-sharing','Six questions before sharing data',4,'28 to 31','Complete the checklist for the synthetic workshop material. What would still need institutional confirmation for confidential research?','Use only the supplied synthetic endpoints for the practical.'),
('cytometry','fcs-boundary','Know what the available data cannot tell you',4,'32','Can a table of endpoint percentages reveal gate thresholds or event counts? What source files would be needed?','Follow the raw-data workflow conceptually, without pretending to run unavailable FCS data.'),
('cytometry','gating-concepts','Preserve the path from events to an endpoint',6,'32, 33','Where would you record acquisition quality, corrections, transforms, controls and losses at each gate?','Many measured events still belong to a finite number of independent biological units.'),
('cytometry','unit-inference','Eighty measurements are not eighty donors',5,'34','Explain 80 measurements, 40 cultures and 10 simulated donors without changing the unit of inference.','Choose each figure panel for the evidence it must communicate.'),
('cytometry','four-panels','Four panels, four distinct jobs',4,'35','Which proposed panels cannot be reconstructed from the supplied endpoint CSV?','Trace an actual culture summary and record one checked claim.'),
('cytometry','trace-point','Trace one plotted point to its two source rows',9,'36','Select a donor and condition, inspect the aliquots, check their arithmetic mean and name the parent population. Which underlying counts remain unavailable?','Checking one point demonstrates a method. It is not verification of the complete figure.'),
('verification','execution-states','Written, executed and checked are different states',1,'37','Which saved evidence would distinguish code that was written from code that actually ran?','A verification claim needs a specific observation or record.'),
('verification','verification-evidence','Ask what was checked, not how confident it sounds',2,'37','Record numerical readback, rendered inspection and regeneration evidence separately. Leave unperformed checks unmarked.','Scientific verification and permission to publish are distinct questions.'),
('verification','publication-policy','Publication use depends on the material',3,'4, 38, 39','Why are a conceptual workflow, a data plot and a primary microscopy image treated differently?','Apply the policy to concrete cases, preserving its conditions and exceptions.'),
('verification','publication-scenarios','Make the publication decision explicit',3,'38, 39','Identify the required disclosure or restriction. Does paying for an account itself satisfy peer-review confidentiality?','Finish with one bounded task from your own workflow.'),
('verification','take-home','One task, exact inputs, a result you can check',3,'40, 41','Write the task, inputs, expected output, verification and the point requiring a human decision. Export the plan.','Scientific judgement stays with the researcher. Expand the task only after inspecting its evidence.')]

VISUALS = {
 'science-tasks':'Compare the literature, identifier-audit, figure and manuscript examples. Point to the inspectable evidence for each.',
 'working-contexts':'Use the four-part HTML strip: model, interface, tools, environment. Do not display the private account screenshot.',
 'task-fit':'Read across the product-family table by task. Treat the football comparison as an analogy, not a model ranking.',
 'mode-exercise':'Use the three scenario cards. Reveal the rationale only after discussing inputs and evidence.',
 'writing-evidence':'Open the attributed estimate table. Contrast the December estimate with the whole-corpus count and the limitations beneath it.',
 'agent-loop':'Follow the four-step strip. Use the advice/task cards and expandable orchestration explanation to show where tool evidence enters.',
 'brief-builder':'Fill the five fields live, then inspect the generated draft for unresolved placeholders. No agent execution is simulated.',
 'plan-mode':'Read the bounded audit example and separate inspection from proposed implementation and validation.',
 'plan-review':'Use the three plan decisions and reveal why automatic repair or analysis would exceed the available evidence.',
 'goal-conditions':'Expand the finish-condition explanation. Identify the saved artifact and the unresolved choice that triggers a stop.',
 'capabilities':'Read the tool, skill, plugin, connection and MCP table as distinct roles, not interchangeable names.',
 'skill-inspector':'Expand each original SKILL.md section and its purpose annotation. Contrast acceptance criteria with the explicit round C loop.',
 'token-concepts':'Use the input, processing and output cards to separate context capacity from time-window usage.',
 'workload':'Change one assumption in the calculator and read the formula and rate table. The numbers are arithmetic, not a benchmark.',
 'model-settings':'Contrast reasoning effort with service speed in the text and source-status note. No private usage screenshot is required.',
 'allowances':'Contrast context capacity, reset windows, credits and API charges. Do not turn a remaining percentage into a prompt count.',
 'data-boundary':'Trace the four questions in the HTML strip. Contrast a local FCS file with information extracted and sent to a model.',
 'account-comparison':'Read the OpenAI and Anthropic account tables alongside their dated-source labels. Do not imply institutional approval.',
 'zdr':'Use the scoped-agreement explanation and current covered-model update. Ask which copy or service each promise concerns.',
 'before-sharing':'Complete the six evidence-backed checks. Leave unavailable information blank and observe that no certificate is issued.',
 'fcs-boundary':'Read the explicit endpoint-table boundary before drawing any conclusions about raw acquisition.',
 'gating-concepts':'Follow the conceptual FCS-to-endpoint strip. No sample-specific gate thresholds or event counts are invented.',
 'unit-inference':'Use the replication cards to distinguish 80 measurements, 40 culture means and 10 simulated donors.',
 'four-panels':'Inspect the four labelled conceptual cards: gating evidence, distributions, replicate summaries and effect/uncertainty.',
 'trace-point':'Use the donor/condition selectors, the two actual aliquot values, arithmetic check and browser-calculated paired preview.',
 'execution-states':'Use the four-state strip to separate advice, code written, code executed and outputs checked.',
 'verification-evidence':'Record concrete observations next to each check. Show that a tick without evidence remains incomplete.',
 'publication-policy':'Compare manuscript support with research and peer-review uses, then inspect the definition of private supportive use.',
 'publication-scenarios':'Switch among the eight scenarios, including primary images, graphical abstracts and cover art; inspect the source-linked conditions.',
 'take-home':'Complete the five take-home fields, then export the text plan with an explicit human decision point.'}

def add_teaching(soup, root):
    """Wrap existing topic content. Keep all old IDs and form controls intact."""
    source = Path(root)/'source'
    first=soup.find(id='verification').select_one(':scope > .flow-strip')
    first['id']='execution-states'
    data=[]
    chapter_titles={s:soup.find(id=s).h1.get_text(' ',strip=True) for s in dict.fromkeys(t[0] for t in TOPICS)}
    for chapter in chapter_titles:
        section=soup.find(id=chapter)
        group=[t for t in TOPICS if t[0]==chapter]
        boundaries=[soup.find(id=t[1]) for t in group]
        if any(x.parent is not section for x in boundaries):raise ValueError('Topic boundary moved: '+chapter)
        end=section.select_one(':scope > .source-note')
        for i,t in enumerate(group):
            _,start,title,minutes,positions,question,transition=t
            ident=f'teach-{chapter}-{i+1}'
            boundary=boundaries[i+1] if i+1<len(boundaries) else end
            nodes=[];node=boundaries[i]
            while node is not boundary:
                if node is None:raise ValueError('Missing teaching boundary')
                nodes.append(node);node=node.next_sibling
            wrapper=soup.new_tag('div',id=ident,attrs={'class':'teaching-topic','data-topic':ident,'data-chapter':chapter,'aria-labelledby':ident+'-title'})
            nodes[0].insert_before(wrapper)
            header=BeautifulSoup('<header class="teaching-heading"><p class="eyebrow"></p><h2></h2><p class="teaching-question"></p></header>','html.parser').header
            header.p.string=f'Topic {i+1} of {len(group)} · {minutes:g} min suggested · presentation positions {positions}'
            header.h2['id']=ident+'-title';header.h2['tabindex']='-1';header.h2.string=title
            header.select_one('.teaching-question').string=question
            wrapper.append(header)
            for node in nodes:wrapper.append(node.extract())
            notes=BeautifulSoup('<details class="teaching-notes"><summary>Discussion cue and transition</summary><div class="details-body"><p></p><p></p></div></details>','html.parser').details
            ps=notes.select('p');ps[0].string=question;ps[1].string='Next: '+transition
            v=soup.new_tag('p');v.string='Visual to inspect: '+VISUALS[start];notes.select_one('.details-body').insert(1,v)
            wrapper.append(notes)
            data.append(dict(id=ident,chapter=chapter,title=title,minutes=minutes,positions=positions,question=question,transition=transition,visual=VISUALS[start]))
        toolbar=BeautifulSoup(f'''<div class="teaching-toolbar" aria-label="Chapter teaching controls"><div class="teaching-view"><span class="small">View</span><button class="btn small" type="button" data-teaching-view="read" aria-pressed="true">Read whole chapter</button><button class="btn small" type="button" data-teaching-view="focus" aria-pressed="false">One topic at a time</button></div><div class="topic-controls"><label for="topic-select-{chapter}" class="sr-only">Choose topic in {chapter_titles[chapter]}</label><select id="topic-select-{chapter}" data-topic-select="{chapter}"></select><div class="choice-row"><button class="btn small" type="button" data-teach-prev="{chapter}">← Previous topic</button><button class="btn small" type="button" data-teach-next="{chapter}">Next topic →</button></div><p class="topic-status small" role="status" aria-live="polite"></p><progress max="30" value="0" aria-label="Position in the guided teaching sequence"></progress></div></div>''','html.parser').div
        section.select_one(':scope > .lead').insert_after(toolbar)
    # Existing course-state export/import includes this preference, with no new store.
    field=soup.new_tag('input',id='teaching-view-field',type='hidden',value='read',attrs={'data-course-field':'teaching-view'})
    soup.find(id='course').append(field)
    start=soup.select_one('.route-card a[href="#why"]');start['data-start-guided']='';start.string='Teach the guided route →'
    extra=soup.new_tag('a',href='#why',attrs={'class':'reading-entry','data-read-guided':''});extra.string='Read independently instead'
    start.insert_after(extra)
    # The opening problem is a scientific accountability question, not a fictional success story.
    hook=BeautifulSoup('''<div class="opening-question"><span class="eyebrow">The question for this workshop</span><p>A figure looks ready for a paper. <strong>What would convince you that it is right?</strong></p><p class="small">Follow one chain of evidence: exact inputs, limited authority, saved output, independent checks. The endpoint measurements used here are entirely synthetic.</p></div>''','html.parser').div
    soup.select_one('.route-grid').insert_before(hook)
    # A small optional arithmetic interaction uses the same immutable source rows.
    calc=BeautifulSoup('''<div class="arithmetic-check"><label for="trace-your-mean">Check your arithmetic: mean of the selected two aliquots (%)</label><div class="choice-row"><input id="trace-your-mean" type="number" min="0" max="100" step="0.001" inputmode="decimal" data-course-field="trace-your-mean" aria-describedby="trace-arithmetic-help"><button class="btn" id="check-trace-mean" type="button">Check calculation</button></div><p class="small" id="trace-arithmetic-help">Use the two supplied percentages, add them and divide by two. Compare to three decimal places. This checks aggregation, not underlying event counts.</p><p id="trace-arithmetic-feedback" role="status" aria-live="polite"></p></div>''','html.parser').div
    soup.find(id='trace-results').insert_after(calc)
    # Public outline includes teaching cues only, not private facilitator materials.
    outline='# AI for science: guided teaching sequence\n\nReview version 3.0, saved 16 September 2026. Workshop date remains editable.\n\nScientific judgement stays with the researcher. Use exact inputs, limited authority, verifiable outputs and stopping conditions.\n\n30 interactive topic views, not embedded slides. Suggested topic timings total 90 minutes, including the 9-minute abbreviated activity. The original 50-minute A/B/C practical is a separate route. No raw FCS dataset or executed FCS notebook is supplied.\n\n'
    for chapter in chapter_titles:
        outline+=f'## {chapter_titles[chapter]}\n\n'
        for t in [t for t in data if t['chapter']==chapter]:
            outline+=f"### {t['title']} ({t['minutes']:g} minutes)\n\nWebsite section: #{t['id']}. Original presentation positions: {t['positions']}.\n\nDiscussion: {t['question']}\n\nTransition: {t['transition']}\n\nVisual: {t['visual']}\n\n"
    outline+='## Prepared example and fallback\n\nThe prepared statistical comparison remains a separate extension, not part of the descriptive A/B/C instructions. Retrospective authorisation does not mean preregistration. Figures are unchanged embedded PNG assets from positions 46 to 48.\n\nThe optional audit reproduces only the visible sample table and matrix identifiers from positions 43 and 44. Missing fixtures are not invented.\n'
    (Path(root)/'public/course-downloads/teaching_outline.md').write_text(outline)
    (Path(root)/'TEACHING_OUTLINE.md').write_text(outline)
    a=soup.new_tag('a',href='course-downloads/teaching_outline.md',download='',attrs={'class':'btn','data-course-download':'teaching_outline.md'});a.string='Teaching sequence and discussion cues'
    soup.find(id='resources').select_one('a[data-course-download]').parent.append(a)
    return data
