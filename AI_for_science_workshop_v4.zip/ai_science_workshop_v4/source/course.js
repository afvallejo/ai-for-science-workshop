'use strict';
(() => {
  const $=id=>document.getElementById(id);
  const config=JSON.parse($('course-data').textContent);
  const rows=JSON.parse($('workshop-data').textContent);
  const KEY='codex-science-course-v2';
  const chapterIds=['why','agents','usage','privacy','cytometry','verification'];
  const practicalIds=['overview','setup','data','rounds','skill','review'];
  let state={fields:{}}, storageOK=true;
  let toastTimeout;
  function tell(message){$('toast').textContent=message;$('toast').hidden=false;clearTimeout(toastTimeout);toastTimeout=setTimeout(()=>$('toast').hidden=true,4000);}
  function saveFile(text,name,mime='text/plain;charset=utf-8'){
    const blob=text instanceof Blob?text:new Blob([text],{type:mime});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);
  }
  function storageNotice(){
    $('course-storage-status').textContent=storageOK&&window.WorkshopPractical.storageAvailable()?'Progress is stored in this browser. Export before moving devices or changing the website address.':'Browser storage is unavailable. Your entries remain in this open page only. Export before closing or reloading.';
  }
  function persist(){try{localStorage.setItem(KEY,JSON.stringify(state));}catch(_){storageOK=false;}storageNotice();}
  // Choices are stored in the same explicitly whitelisted form-field namespace.
  for(const type of ['mode','plan'])for(let n=1;n<=3;n++){
    const field=document.createElement('input');field.type='hidden';field.dataset.courseField=`${type}-choice-${n}`;document.body.append(field);
  }
  const fieldElements=[...document.querySelectorAll('[data-course-field]')];
  const defaults=new Map(fieldElements.map(e=>[e.dataset.courseField,e.type==='checkbox'?e.checked:e.value]));
  const allowedFields=new Set(defaults.keys());
  function sanitiseFields(input){
    const clean={};if(!input||typeof input!=='object'||Array.isArray(input))throw new Error('Course fields must be an object.');
    for(const [key,val] of Object.entries(input)){
      if(!allowedFields.has(key))continue;
      const element=fieldElements.find(e=>e.dataset.courseField===key);
      if(element.tagName==='SELECT' && (typeof val!=='string'||![...element.options].some(o=>o.value===val)))throw new Error('Invalid saved choice for '+key+'.');
      if(element.type==='checkbox' && typeof val!=='boolean')throw new Error('Invalid saved progress marker for '+key+'.');
      if(typeof val==='boolean'||typeof val==='string')clean[key]=typeof val==='string'?val.slice(0,20000):val;
    }
    return clean;
  }
  try{const stored=JSON.parse(localStorage.getItem(KEY)||'null');if(stored?.fields)state.fields=sanitiseFields(stored.fields);}catch(_){storageOK=false;}
  function restoreFields(){for(const e of fieldElements){const value=state.fields[e.dataset.courseField]??defaults.get(e.dataset.courseField);if(e.type==='checkbox')e.checked=value===true;else e.value=typeof value==='string'?value:'';}}
  restoreFields();
  function captureFields(){for(const e of fieldElements)state.fields[e.dataset.courseField]=e.type==='checkbox'?e.checked:e.value;}
  function field(key){return fieldElements.find(e=>e.dataset.courseField===key);}
  function setChoice(key,value){field(key).value=value;captureFields();persist();}
  function progress(){const n=chapterIds.filter(x=>field('complete-'+x).checked).length;$('course-progress').textContent=`Chapters: ${n} / 6`;}
  // Hash routes preserve all old practical anchors, plus deep links in the course.
  function route(){
    let ident;try{ident=decodeURIComponent(location.hash.slice(1))||'course';}catch(_){ident='course';}
    let target=$(ident);let section=target?.closest('main > section');
    if(ident==='main'){section=$('course');target=section;}
    if(!section){section=$('course');target=section;}
    const practical=practicalIds.includes(section.id);
    document.querySelectorAll('main > section').forEach(s=>s.hidden=practical?!practicalIds.includes(s.id):s!==section);
    const active=practical?'overview':section.id;
    document.querySelectorAll('.sidebar nav a').forEach(a=>{if(a.hash==='#'+active)a.setAttribute('aria-current','location');else a.removeAttribute('aria-current');});
    $('mobile-nav').value=active;
    for(let p=target.parentElement;p&&p!==section;p=p.parentElement)if(p.tagName==='DETAILS')p.open=true;
    if(target.tagName==='DETAILS')target.open=true;
    const panel=target.closest('[role=tabpanel]');if(panel){$('tab-'+panel.id.slice(-1))?.click();}
    window.WorkshopTeaching?.reveal(target);
    const focus=target===section?section.querySelector('h1,h2'):target;
    requestAnimationFrame(()=>{target.scrollIntoView({block:'start',behavior:'instant'});if(focus){if(!focus.hasAttribute('tabindex'))focus.tabIndex=-1;focus.focus({preventScroll:true});}});
    document.title=(section.querySelector('h1,h2')?.textContent.trim()||'AI for science')+' | Codex workshop';
  }
  window.addEventListener('hashchange',route);
  document.addEventListener('click',e=>{const a=e.target.closest('a[href^="#"]');if(a&&a.hash===location.hash){e.preventDefault();route();}});

  const modeAnswers={
    1:'Chat is a sensible starting point. Provide the interval, model and sample-size context when relevant. Inspect the explanation against a trusted statistical source. Work or Codex can also do this; tools are useful when a numerical example needs calculation.',
    2:'Work is a sensible starting point, but a tool-enabled chat or Codex can also create the table. Provide all five permitted papers. Inspect population, methods and limitations against page or section locators, not only generated citations.',
    3:'Codex is a sensible project context. Provide the exact files and identifier columns, permit read-only checks and a saved report, and inspect every duplicate and mismatch. Other tool-enabled contexts may work when they have equivalent file access and execution.'
  };
  function showMode(n,choice){const box=$('mode-answer-'+n);box.hidden=!choice;box.textContent=choice?`Your choice: ${choice}. ${modeAnswers[n]}`:'';document.querySelectorAll(`[data-mode-group="${n}"] [data-mode]`).forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.mode===choice)));}
  document.querySelectorAll('[data-mode]').forEach(b=>b.addEventListener('click',()=>{setChoice('mode-choice-'+b.dataset.scenario,b.dataset.mode);showMode(b.dataset.scenario,b.dataset.mode);}));
  const planAnswers={
    1:'Audit and ask. A duplicate could represent different source problems. Establish the correct record and reconcile unmatched identifiers before deleting anything. Report exact IDs and preserve both files.',
    2:'Audit and ask. The most common batch is not evidence of the missing sample’s batch. Find supporting metadata or leave the value explicitly unresolved. Do not invent a repair.',
    3:'Audit and ask. There is no authorised contrast, checked assay provenance or established design. Resolve these before fitting a model. A desired significance result is not a valid analysis objective.'
  };
  function showPlan(n,choice){const box=$('plan-answer-'+n);box.hidden=!choice;box.textContent=choice?`Selected: ${choice}. ${planAnswers[n]}`:'';document.querySelectorAll(`[data-plan="${n}"]`).forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.choice===choice)));}
  document.querySelectorAll('[data-plan]').forEach(b=>b.addEventListener('click',()=>{setChoice('plan-choice-'+b.dataset.plan,b.dataset.choice);showPlan(b.dataset.plan,b.dataset.choice);}));
  function buildBrief(){
    const parts=[['outcome','Outcome'],['inputs','Exact inputs'],['boundaries','Boundaries'],['checks','Evidence and checks'],['stop','Stopping conditions and human decisions']];
    $('brief-output').textContent=parts.map(([id,label])=>`${label}\n${$('brief-'+id).value.trim()||'[TO BE SPECIFIED BY THE RESEARCHER]'}`).join('\n\n')+'\n\nThis is a proposed brief. No task has been executed.';
  }
  $('build-brief').addEventListener('click',()=>{buildBrief();tell('Draft assembled from your entries. Official practical prompts remain unchanged.');});
  const rates={luna:[5,.5,30],terra:[50,5,300],astra:[250,25,1250]};
  function workload(){
    const ids=['cost-input','cost-cache','cost-output','cost-calls','cost-speed'];const v=ids.map(x=>Number($(x).value));
    const [input,cache,output,calls,mult]=v;
    const valid=ids.every(x=>$(x).value!=='')&&v.every(Number.isFinite)&&input>=0&&input<=1e7&&output>=0&&output<=1e7&&cache>=0&&cache<=100&&calls>=1&&calls<=1000&&Number.isInteger(calls)&&[1,2.5].includes(mult);
    $('cost-error').hidden=valid;
    if(!valid){$('cost-error').textContent='Use non-negative token counts up to 10,000,000; cached input from 0 to 100%; and 1 to 1,000 whole calls.';Object.keys(rates).forEach(k=>$('cost-'+k).textContent='Not calculated');$('cost-formula').textContent='Correct the inputs before interpreting this illustration.';return;}
    const cached=input*cache/100,uncached=input-cached;
    for(const [name,[ir,cr,orr]] of Object.entries(rates)){$('cost-'+name).textContent=((uncached*ir+cached*cr+output*orr)/1e6*calls*mult).toLocaleString('en-GB',{minimumFractionDigits:2,maximumFractionDigits:4});}
    $('cost-formula').textContent=`Credits = calls × multiplier × [(uncached input × input rate) + (cached input × cached rate) + (total output × output rate)] / 1,000,000\n\nUncached input = ${uncached.toLocaleString('en-GB')}\nCached input = ${cached.toLocaleString('en-GB')}\nTotal output, including reasoning = ${output.toLocaleString('en-GB')}\nCalls = ${calls}; multiplier = ${mult}\n\nLuna: ${calls} × ${mult} × [(${uncached} × 5) + (${cached} × 0.5) + (${output} × 30)] / 1,000,000${mult===2.5?'\n\nPresentation Fast-mode assumption: the official rate card freshly confirms Astra at 2.5 times Standard. The same multiplier for Terra and Luna is retained from the dated slide example, not independently reverified here.':''}`;
  }
  // Exact aggregation on the source's two-decimal percentage grid; no inferential tests.
  const hundredths=value=>{if(!/^\d+(\.\d{1,2})?$/.test(value))throw new Error('Unexpected source precision');const [i,f='']=value.split('.');return Number(i)*100+Number(f.padEnd(2,'0'));};
  function culture(donor,treatment,stimulation){
    const selected=rows.filter(r=>r.donor_id===donor&&r.treatment===treatment&&r.stimulation===stimulation).sort((a,b)=>Number(a.technical_replicate)-Number(b.technical_replicate));
    if(selected.length!==2||new Set(selected.map(r=>r.technical_replicate)).size!==2||new Set(selected.map(r=>r.sample_id)).size!==1)throw new Error('Expected exactly two technical aliquots per culture.');
    const mean=(hundredths(selected[0].activation_percent)+hundredths(selected[1].activation_percent))/200;
    return {selected,mean};
  }
  let traceRecord='';
  function trace(){
    const donor=$('trace-donor').value,treatment=$('trace-treatment').value,stim=$('trace-stimulation').value;
    try{
      const c=culture(donor,treatment,stim),vehicle=culture(donor,'Vehicle',stim),compound=culture(donor,'Compound_X',stim);
      // Values and identifiers originate solely from the embedded immutable workshop CSV.
      const difference=Number((compound.mean-vehicle.mean).toFixed(3));
      $('trace-results').innerHTML=`<div class="trace-result"><div class="card"><strong>${c.selected[0].sample_id}</strong><p>Aliquot 1: ${c.selected[0].activation_percent}%<br>Aliquot 2: ${c.selected[1].activation_percent}%</p><div class="trace-number" id="trace-mean">${c.mean.toFixed(3)}%</div><div class="trace-formula">(${c.selected[0].activation_percent} + ${c.selected[1].activation_percent}) / 2 = ${c.mean.toFixed(3)}%</div></div><div class="card"><strong>Paired within ${donor}</strong><p>Vehicle culture mean: ${vehicle.mean.toFixed(3)}%<br>Compound_X culture mean: ${compound.mean.toFixed(3)}%</p><div class="trace-number" id="trace-difference">${difference.toFixed(3)} pp</div><p>Compound_X minus Vehicle. A descriptive arithmetic difference, not an inferential test.</p></div></div><p><strong>Endpoint:</strong> CD69+CD137+ events as a percentage of live, singlet CD3+CD8+ T cells. Two technical aliquots do not change n = 10 simulated donors per condition.</p>`;
      const y=v=>180-v*1.45;
      $('trace-plot').innerHTML=`<svg viewBox="0 0 610 235" role="img" aria-label="Descriptive culture means for ${donor} in ${stim}: Vehicle ${vehicle.mean.toFixed(3)} percent and Compound_X ${compound.mean.toFixed(3)} percent."><text x="15" y="20" font-size="13" fill="#142b40">Activation (%) · ${donor} · ${stim}</text><line x1="70" y1="35" x2="70" y2="180" stroke="#657783"/><line x1="70" y1="180" x2="570" y2="180" stroke="#657783"/><text x="40" y="185" font-size="12">0</text><text x="30" y="40" font-size="12">100</text><line x1="215" y1="${y(vehicle.mean)}" x2="440" y2="${y(compound.mean)}" stroke="#96a6ad" stroke-width="2"/><circle cx="215" cy="${y(vehicle.mean)}" r="6" fill="#647789"/><rect x="434" y="${y(compound.mean)-6}" width="12" height="12" fill="#16736e"/><text x="215" y="${y(vehicle.mean)-13}" text-anchor="middle" font-size="12">${vehicle.mean.toFixed(3)}</text><text x="440" y="${y(compound.mean)-13}" text-anchor="middle" font-size="12">${compound.mean.toFixed(3)}</text><text x="215" y="205" text-anchor="middle" font-size="13">Vehicle (circle)</text><text x="440" y="205" text-anchor="middle" font-size="13">Compound_X (square)</text></svg><p class="small muted">Browser-calculated descriptive preview from the actual CSV. Each marker is one culture mean. Not an FCS event plot or a Codex-generated manuscript figure.</p>`;
      traceRecord=`Synthetic point trace\nDonor: ${donor}\nStimulation: ${stim}\nTreatment: ${treatment}\nSample: ${c.selected[0].sample_id}\nAliquot 1: ${c.selected[0].activation_percent}%\nAliquot 2: ${c.selected[1].activation_percent}%\nArithmetic mean: ${c.mean.toFixed(3)}%\nPaired difference, Compound_X minus Vehicle: ${difference.toFixed(3)} percentage points\nEndpoint: CD69+CD137+ frequency among live, singlet CD3+CD8+ T cells.\nNo underlying event counts or gate thresholds are supplied. This is a descriptive calculation, not an inferential test.\n`;
    }catch(err){$('trace-results').textContent='Trace unavailable: '+err.message;$('trace-plot').replaceChildren();traceRecord='Trace unavailable.';}
  }
  $('export-trace').addEventListener('click',()=>saveFile(traceRecord+'\nMy caption:\n'+$('trace-caption').value+'\n\nUnresolved check:\n'+$('trace-unresolved').value,'synthetic_point_trace.txt'));
  function checklist(prefix,keys,output){
    let checked=0,withEvidence=0;
    for(const k of keys)if(field(`${prefix}-${k}`).checked){checked++;if(field(`${prefix}-evidence-${k}`).value.trim())withEvidence++;}
    const missing=checked-withEvidence;
    $(output).textContent=`${withEvidence} / ${keys.length} items marked with written evidence. ${missing?`${missing} ticked item${missing===1?' lacks':'s lack'} supporting evidence. `:''}${prefix==='privacy'?'This does not authorise data sharing or certify compliance. Resolve all unknowns through institutional review.':'Self-reported evidence only. No independent pass or publication approval is issued.'}`;
  }
  const publication={
    diagram:'Conceptual diagrams: permitted with verification and appropriate disclosure of tool, version and use in the caption and AI statement. The image must explain a concept, not masquerade as observed experimental evidence.',
    plot:'Data plots and heatmaps: derive faithfully from the actual data through reproducible methods. Report the relevant AI tool, version and developer in Methods as required. Generated code does not excuse checking values, axes and statistical choices.',
    image:'Primary research images: do not use generative AI to create or alter experimental evidence. A generated western blot or fabricated microscopy panel is not a conceptual diagram. A formal, reported AI research method is a distinct exception, not general permission for edits.',
    method:'AI as a formal research method: the policy distinguishes this from generative alteration of evidence. Describe the method reproducibly in Methods, including the tool/model, version and relevant implementation details. Preserve scientific integrity and the evidence needed to evaluate the result.',
    abstract:'Graphical abstracts: the stated policy does not permit general-purpose image generation. Use dedicated scientific illustration tools within the policy and licensing conditions. Permission for conceptual diagrams does not automatically extend to graphical abstracts.',
    cover:'Cover art: obtain prior permission from the journal editor and publisher, and satisfy rights, attribution and other stated conditions. Do not assume a normal manuscript disclosure is sufficient.',
    review:'Peer review: never upload a submitted manuscript, or parts of it, to AI tools. Any private supportive use must preserve confidentiality, remain under human oversight and follow the policy’s disclosure requirements. The reviewer remains responsible for the assessment. Private means the submitted content is not retained beyond service needs, reused, shared or used for training. A paid or enterprise label alone does not establish this. The manuscript-upload prohibition still applies.',
    grammar:'Basic spelling, grammar and punctuation checking is exempt from the manuscript AI declaration. This does not exempt substantive rewriting, content generation or research analysis. Apply the specific scope in the live policy.'
  };
  function publicationCase(){const key=$('publication-case').value;$('publication-answer').hidden=!key;$('publication-answer').textContent=publication[key]||'';}
  $('export-take-home').addEventListener('click',()=>{
    const keys=[['task','Task'],['inputs','Exact permitted inputs'],['output','Expected saved output'],['verification','Verification'],['decision','Human decision / stopping point']];
    const text='My bounded scientific task\n\n'+keys.map(([key,label])=>label+'\n'+($('take-'+key).value.trim()||'[NOT YET SPECIFIED]')).join('\n\n')+'\n\nThis is a plan, not an executed analysis or a data-sharing approval.\n';saveFile(text,'my_scientific_task_plan.txt');
  });
  function glossary(){const query=$('glossary-search').value.trim().toLocaleLowerCase();let n=0;document.querySelectorAll('[data-term]').forEach(e=>{e.hidden=!e.dataset.term.toLocaleLowerCase().includes(query);if(!e.hidden)n++;});$('glossary-count').textContent=`${n} terms shown`;$('glossary-empty').hidden=n!==0;}
  function refresh(){progress();workload();trace();publicationCase();glossary();checklist('privacy',['classification','workspace','processing','training','retention','connections'],'privacy-status');checklist('verify',['numerical','design','render','regenerate','record'],'verify-status');for(let n=1;n<=3;n++){showMode(n,field('mode-choice-'+n).value);showPlan(n,field('plan-choice-'+n).value);}window.WorkshopTeaching?.refresh();}
  fieldElements.forEach(e=>{const handler=()=>{captureFields();persist();if(e.id?.startsWith('cost-'))workload();else if(['trace-donor','trace-treatment','trace-stimulation'].includes(e.id))trace();else if(e.id==='glossary-search')glossary();else if(e.id==='publication-case')publicationCase();else if(e.dataset.courseField.startsWith('privacy-'))checklist('privacy',['classification','workspace','processing','training','retention','connections'],'privacy-status');else if(e.dataset.courseField.startsWith('verify-'))checklist('verify',['numerical','design','render','regenerate','record'],'verify-status');else if(e.dataset.courseField.startsWith('complete-'))progress();};e.addEventListener('input',handler);e.addEventListener('change',handler);});
  // Inspection controls alter labels/layout, never image bytes or data.
  let revealed=false;
  const figureLabels=['A · Basic prompt and common brief','B · Revised skill and basic prompt','C · Revised skill and bounded loop'];
  const figureNotes=['The presentation reports one completed design without the supplied skill and successful fresh regeneration. The shared statistical plan and production brief already supported a strong baseline.','The presentation reports a corrected missing legend glyph, with unchanged statistics. This was normal rendering debugging. The earlier defective image and run records are not supplied here.','The presentation reports a documented bounded review, archived v1 and zero revisions. The loop stopped because no revision was required. Fresh regeneration is reported, not re-executed by this page.'];
  $('reveal-figures').addEventListener('click',()=>{revealed=!revealed;$('reveal-figures').setAttribute('aria-pressed',String(revealed));$('reveal-figures').textContent=revealed?'Conceal instruction labels':'Reveal instruction labels';for(let i=1;i<=3;i++){$('figure-label-'+i).textContent=revealed?figureLabels[i-1]:'Figure '+i;$('figure-reveal-'+i).hidden=!revealed;$('figure-reveal-'+i).textContent=revealed?figureNotes[i-1]:'';}});
  $('figure-layout').addEventListener('click',()=>{const wide=$('figure-comparison').classList.toggle('figure-wide');$('figure-layout').setAttribute('aria-pressed',String(wide));$('figure-layout').textContent=wide?'Compare side by side':'Use full-width figures';});
  let zoom=100,zoomReturn=null;
  document.querySelectorAll('[data-zoom]').forEach(b=>b.addEventListener('click',()=>{const i=Number(b.dataset.zoom);zoomReturn=b;zoom=100;$('zoom-image').src=b.querySelector('img').src;$('zoom-image').alt=b.querySelector('img').alt;$('zoom-image').style.width='100%';$('zoom-title').textContent=revealed?figureLabels[i-1]:'Prepared figure '+i;$('figure-dialog').showModal();$('zoom-close').focus();}));
  $('zoom-in').addEventListener('click',()=>{zoom=Math.min(400,zoom+50);$('zoom-image').style.width=zoom+'%';});
  $('zoom-out').addEventListener('click',()=>{zoom=Math.max(100,zoom-50);$('zoom-image').style.width=zoom+'%';});
  $('zoom-close').addEventListener('click',()=>$('figure-dialog').close());$('figure-dialog').addEventListener('close',()=>zoomReturn?.focus());
  // Download original-schema logs, with formula-safe free-text cells.
  function csvCell(v){let text=String(v??'');if(/^[\s\u0000-\u001f]*[=+@-]/.test(text))text="'"+text;return '"'+text.replaceAll('"','""')+'"';}
  $('export-run-log').addEventListener('click',()=>{const table=[config.logHeaders];for(const r of 'ABC')table.push(config.logHeaders.map(k=>k==='condition'?r:field(`log-${r}-${k}`).value));saveFile('\ufeff'+table.map(line=>line.map(csvCell).join(',')).join('\r\n')+'\r\n','workshop_run_log.csv','text/csv;charset=utf-8');});
  document.querySelectorAll('[data-course-download]').forEach(a=>a.addEventListener('click',e=>{const file=config.assets[a.dataset.courseDownload];if(!file)return;e.preventDefault();const bytes=Uint8Array.from(atob(file.base64),c=>c.charCodeAt(0));saveFile(new Blob([bytes],{type:file.mime}),a.dataset.courseDownload); }));
  $('export-progress').addEventListener('click',()=>{captureFields();const payload={format:'codex-science-workshop-progress',version:2,exportedAt:new Date().toISOString(),course:state,practical:window.WorkshopPractical.getState()};saveFile(JSON.stringify(payload,null,2),'codex_workshop_progress.json','application/json');tell('Local progress export requested. It includes your written notes and three scorecards.');});
  $('import-progress').addEventListener('change',async e=>{
    const file=e.target.files?.[0];if(!file)return;
    try{
      if(file.size>3e6)throw new Error('The file is too large for a workshop progress export.');
      const payload=JSON.parse(await file.text());if(payload.format!=='codex-science-workshop-progress'||payload.version!==2)throw new Error('This is not a version 2 workshop progress export.');
      const clean=sanitiseFields(payload.course?.fields);if(!payload.practical||!Array.isArray(payload.practical.reviews)||payload.practical.reviews.length!==3)throw new Error('The three practical scorecards are missing.');
      if(!window.confirm('Replace course entries and all three practical scorecards with this local export?'))return;
      window.WorkshopPractical.setState(payload.practical);state={fields:clean};restoreFields();persist();refresh();buildBrief();$('import-status').textContent='Imported locally. Three independent scorecards and course fields restored.';
    }catch(err){$('import-status').textContent='Import not applied: '+err.message;}finally{e.target.value='';}
  });
  $('reset-course').addEventListener('click',()=>{if(!window.confirm('Reset all course fields, practical progress and all three scorecards in this browser? Export first.'))return;state={fields:{}};restoreFields();persist();window.WorkshopPractical.clear();refresh();$('brief-output').textContent='Complete the fields, then build your draft. Scientific choices are not filled automatically.';$('import-status').textContent='Course entries and practical scorecards reset.';});
  refresh();storageNotice();route();
  // Pure arithmetic hook used by the included regression tests. No hidden reference answers.
  window.WorkshopCourse={culture:(d,t,s)=>culture(d,t,s).mean,refresh,route};
})();
