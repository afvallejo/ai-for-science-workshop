# Change summary

Saved 16 September 2026, review version 3.0.0. No public deployment or live Sites project was changed.

## What this revision changes

The recovered v2 source project is extended in place. Existing chapters and interactions are reused, not duplicated. A 30-topic guided teaching view adds an opening evidence question, step-specific titles, exact source positions, discussion prompts, visual suggestions and transitions, with previous/next topic controls and chapter selectors. Topic timings sum to the six original 90-minute slots. A whole-chapter reading mode remains available.

The trace-point activity now also lets participants enter and check the arithmetic mean of the selected two actual aliquot percentages. It checks arithmetic only, not unavailable event counts or gates. A downloadable public teaching outline supports teaching and independent revision. The new view preference and arithmetic field use the existing course storage key and compatible progress export format. Progress import now rejects invalid selection values before changing any saved entries.

The source register was re-reviewed. The official pricing page confirms Astra Fast at 2.5 times Standard. The shared multiplier for Terra/Luna remains an explicitly dated assumption. The current Anthropic covered-model policy requires specified retention; the notice-based exception in the original deck was not confirmed by the retrieved text. Elsevier's definition of private supportive peer-review use is expanded without weakening the manuscript-upload prohibition. The biomedical-writing figures remain attributed to the presentation because primary full-text retrieval failed; PubMed corroborates the Nature news metadata.

## Complete site retained

Six source-linked chapters cover tool choice, bounded agents, models/tokens/usage, privacy, cytometry and verification/publication. Interactions include working-mode scenarios, brief building, plan review, the exact skill viewer, workload arithmetic, evidence-backed privacy/verification checklists, actual-data point tracing, publication scenarios and a take-home text export. The glossary, original-schema run logs, independent scorecards, data filtering and downloads remain available.

The guided route is 90 minutes, with a 28-minute cytometry chapter and a 9-minute abbreviated activity. The original full figure practical remains a separate 50-minute route. The authorised retrospective statistical comparison is a separate prepared example, using unchanged PNG assets embedded in positions 46, 47 and 48. Numerical, production and regeneration findings remain presentation-attributed, not newly reproduced.

## Preserved and recoverable

All 16 original downloads are byte-identical to both the original v1 and immediate v2 baselines, including data, study context, prompts, skill, scorecard, participant pack and separate A/B/C projects. No hypothesis tests or significance annotations were added to the descriptive task. The original 10 simulated donors, 80 technical measurements, 40 arithmetic culture means, parent population and donor pairing remain intact.

Every v2 control ID, deep-link target and course progress field is retained. Original practical storage uses codex-science-workshop-v1; course storage remains codex-science-course-v2. The recovery folder contains the original v1 and saved v2 packages. Public assets contain no facilitator files, private account screenshot, raw presentation, credentials or fabricated figure masters.

## Executed checks and limitations

See TEST_RESULTS.md for the final combined test count and the exact harness. Chromium document-injection tests exercised original and new controls, native Blob downloads, keyboard navigation, modal zoom, local exports/imports and the storage-unavailable fallback. Stored-state migration was tested with an explicitly labelled storage shim. Browser policy blocked both localhost and file URL navigation, so normal hosted-origin persistence is not claimed. Static HTTP serving is checked separately, including private-path and write rejection.

The selected FCS dataset/notebook, optional audit fixture files, revised statistical skill, original editable figure masters and run receipts/diagnostics were not available in the supplied project or located in the scoped Library search. The site identifies these dependencies rather than inventing them. No Codex A/B/C run or FCS analysis was executed in this website revision. No journal acceptance, institutional approval or compliance certificate is claimed.

Safari, Firefox, screen-reader use, physical print, vector-editor round trips, native hosted storage and the intended Sites deployment still require testing. Recheck dated product and policy claims before teaching or publishing. Publishing requires separate approval.
