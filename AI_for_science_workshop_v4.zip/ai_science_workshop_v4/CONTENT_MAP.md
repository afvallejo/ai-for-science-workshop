# Presentation content map

Actual 1-based slide positions, not printed slide numbers. Built 16 September 2026.

| Position | Title / subject | Destination | Handling |
|---|---|---|---|
| 1 | AI for science | #course | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 2 | The 90-minute workshop | #course | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 3 | Most biomedical publications show signs of LLM-assisted writing | #writing-evidence | Original population estimate, corpus, date and caveats retained. Primary preprint could not be retrieved in this verification pass. |
| 4 | What authors may use AI for in a paper (image-only) | #publication-policy | Image-only teaching content inspected and translated to HTML. Conceptual, not an executed workflow. |
| 5 | Chat, Work and Codex | #working-contexts | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 6 | Blank slide | Not applicable | Blank. Intentionally no empty chapter. |
| 7 | ChatGPT interface screenshot (image-only) | #working-contexts | Private account screenshot excluded from public assets. Generic interface concepts only; screenshot is not current documentation. |
| 8 | What is an Agent? (image-only) | #agent-loop | Image-only teaching content inspected and translated to HTML. Conceptual, not an executed workflow. |
| 9 | What is an agent? | #agent-loop | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 10 | Inside Codex: Agents in Action (image-only) | #orchestration | Image-only teaching content inspected and translated to HTML. Conceptual, not an executed workflow. |
| 11 | Scientific tasks worth trying | #science-tasks | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 12 | Claude vs ChatGPT: Messi vs Ronaldo | #task-fit | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 13 | What actually differs | #task-fit | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 14 | Why running tools matters | #agent-evidence | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 15 | A prompt and an agent task | #agent-evidence | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 16 | Exercise: choose the working mode | #mode-exercise | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 17 | A useful task brief | #brief-builder | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 18 | Exercise: improve this request | #brief-builder | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 19 | Plan mode | #plan-mode | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 20 | Exercise: review a proposed plan | #plan-review | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 21 | Goals | #goal-conditions | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 22 | Skills | #skill-inspector | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 23 | Plugins, connections and MCP | #capabilities | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 24 | Tokens: what the model processes | #token-concepts | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 25 | Luna, Terra and Astra: usage trade-offs | #workload | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 26 | Reasoning effort and Fast mode | #model-settings | Presentation effort/speed distinction retained. The current pricing page confirms Astra Fast at 2.5 times Standard; other shared multipliers remain dated illustrative assumptions. |
| 27 | Weekly allowance and reset windows | #allowances | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 28 | Training, retention and access | #data-boundary | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 29 | ChatGPT accounts and Codex | #account-comparison | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 30 | Claude accounts and Claude Code | #account-comparison | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 31 | Zero Data Retention (ZDR) | #zdr | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 32 | Flow cytometry: raw files to a figure | #fcs-boundary | Raw FCS analysis remains conceptual because the selected FCS project is unavailable. Hands-on activity uses the actual synthetic endpoint CSV instead. |
| 33 | Flow cytometry: analysis and gating | #gating-concepts | Raw FCS analysis remains conceptual because the selected FCS project is unavailable. Hands-on activity uses the actual synthetic endpoint CSV instead. |
| 34 | Flow cytometry: the unit of inference | #unit-inference | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 35 | The flow-cytometry figure | #four-panels | Raw FCS analysis remains conceptual because the selected FCS project is unavailable. Hands-on activity uses the actual synthetic endpoint CSV instead. |
| 36 | Hands-on: inspect the cytometry figure | #trace-point | Raw FCS analysis remains conceptual because the selected FCS project is unavailable. Hands-on activity uses the actual synthetic endpoint CSV instead. |
| 37 | What we check before using a result | #verification-evidence | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 38 | Elsevier: manuscripts and peer review | #publication-policy | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 39 | Elsevier: figures and images | #publication-scenarios | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 40 | A first task for this week | #take-home | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 41 | Questions and a task to take away | #take-home | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 42 | Sources and further reading | #sources | Adapted into HTML teaching content and/or an interaction; original slide position, not printed number. |
| 43 | Demonstration: the sample-sheet audit | #audit | Available slide table transcribed. Referenced audit CSV files and run records unavailable; no invented matrix values or download. |
| 44 | Hands-on: audit the demo files | #audit | Available slide table transcribed. Referenced audit CSV files and run records unavailable; no invented matrix values or download. |
| 45 | Paper figures with a verified statistical plan | #prepared-plan | Separate authorised retrospective statistical example. Numerical and regeneration claims attributed to presentation, not newly reproduced. |
| 46 | A: Basic prompt with the common brief | #prepared-figures | Unmodified embedded figure image extracted. Zoom and concealed instruction labels added; editable masters not available. |
| 47 | B: Revised skill and basic prompt | #prepared-figures | Unmodified embedded figure image extracted. Zoom and concealed instruction labels added; editable masters not available. |
| 48 | C: Revised skill and bounded review loop | #prepared-figures | Unmodified embedded figure image extracted. Zoom and concealed instruction labels added; editable masters not available. |
| 49 | All three reproduce the same paired statistics | #prepared-results | Separate authorised retrospective statistical example. Numerical and regeneration claims attributed to presentation, not newly reproduced. |
| 50 | The final masters pass the recorded Nature checks | #prepared-findings | Separate authorised retrospective statistical example. Numerical and regeneration claims attributed to presentation, not newly reproduced. |
