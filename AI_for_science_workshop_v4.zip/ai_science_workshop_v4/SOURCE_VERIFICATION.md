# Source verification register

Website build checks: 16 September 2026. Presentation check date: 9 September 2026 unless otherwise specified; statistical appendix: 15 September 2026.

## Nature News: Kaia Glickman, 20 August 2026

Status: limited. Presentation positions: 3.

Nature page retrieval failed in this review on 16 September 2026. PubMed confirms the news title, Kaia Glickman byline and arXiv reference. The 20 August online date remains attributed to the presentation; PubMed indexes the September print issue.

https://www.nature.com/articles/d41586-026-02551-z

## Holzwarth, González-Márquez and Kobak, arXiv:2608.10715v1

Status: limited. Presentation positions: 3.

Primary arXiv HTML and abstract retrieval failed on 16 September 2026. The population estimates, corpus and limitations remain attributed to the supplied slide 3 notes. No new replication or independent confirmation is claimed.

https://arxiv.org/html/2608.10715v1

## OpenAI: ChatGPT Work overview

Status: limited. Presentation positions: 5, 13, 14, 15, 16, 23, 28, 37.

Presentation checked 9 September 2026. Direct recheck, including Markdown form, failed on 16 September 2026. Product-family examples are dated, not a claim of exact feature parity.

https://learn.chatgpt.com/docs/enterprise/chatgpt-work-overview

## OpenAI: ChatGPT and Codex changelog

Status: dated. Presentation positions: 5, 13.

Presentation attributes the desktop integration to the 9 July 2026 entry, checked 9 September. Not separately reverified for this build.

https://learn.chatgpt.com/docs/changelog

## Anthropic: navigating Claude desktop

Status: dated. Presentation positions: 12, 13.

Presentation checked 9 September 2026. Chat, Cowork and Claude Code are presented as dated workflow examples.

https://academy.claude.com/tutorials/navigating-the-claude-desktop-app

## Anthropic: Building effective agents

Status: dated. Presentation positions: 9, 14, 15.

19 December 2024. Conceptual workflow/agent distinction from the presentation, not a claim about current product availability.

https://www.anthropic.com/engineering/building-effective-agents

## OpenAI: developer commands

Status: checked. Presentation positions: 19, 21.

Plan and goal command documentation inspected 16 September 2026. Read-only planning and implementation boundaries follow the supplied teaching example; actual participant clients were not inspected.

https://learn.chatgpt.com/docs/developer-commands

## OpenAI: follow a goal

Status: dated. Presentation positions: 21.

Original source checked 9 September 2026. Durable objective concept also supported by developer commands inspected 16 September. No goal is executed by this site.

https://learn.chatgpt.com/use-cases/follow-goals

## OpenAI: skills

Status: dated. Presentation positions: 22, 23.

Original presentation check: 9 September 2026. The actual workshop SKILL.md is available unchanged for inspection.

https://developers.openai.com/plugins/concepts/skills

## OpenAI: plugin architecture

Status: dated. Presentation positions: 13, 23.

Original presentation check: 9 September 2026. Packages, instructions and authorised access are separate concepts.

https://developers.openai.com/plugins/concepts/plugins

## OpenAI: MCP server

Status: dated. Presentation positions: 23.

Original presentation check: 9 September 2026. Not every tool uses MCP.

https://developers.openai.com/plugins/concepts/mcp-server

## OpenAI: usage and credit rates

Status: checked. Presentation positions: 24 to 27.

Presentation check: 9 September 2026. Rechecked 16 September 2026: input/cached/output rates per million, Luna 5/0.5/30, Terra 50/5/300, Astra 250/25/1250 credits. The pricing page also confirms Astra Fast at 2.5 times Standard. These are rate-card figures, not balances or invoices.

https://learn.chatgpt.com/docs/pricing

## OpenAI: model and reasoning choices

Status: checked. Presentation positions: 25, 26.

Documentation inspected 16 September 2026. Specific controls depend on model/client/permissions; workshop task-fit examples are heuristics, not benchmarks.

https://learn.chatgpt.com/docs/models

## OpenAI: speed and Fast mode

Status: limited. Presentation positions: 26.

Presentation check: 9 September 2026. Speed-page retrieval on 16 September did not expose sufficient rate detail. The pricing page independently confirms Astra Fast at 2.5 times Standard; the shared Terra/Luna multiplier remains a dated presentation assumption. Do not apply these credits to API invoices.

https://learn.chatgpt.com/docs/agent-configuration/speed

## OpenAI: reasoning tokens

Status: dated. Presentation positions: 24, 26.

Original presentation check: 9 September 2026. Reasoning usage differs from visible answer length.

https://developers.openai.com/api/docs/guides/reasoning#how-reasoning-works

## OpenAI: Work usage and cost

Status: dated. Presentation positions: 24, 25, 27.

Original presentation check: 9 September 2026. Shared usage, credits and invoice charges must not be conflated.

https://learn.chatgpt.com/docs/enterprise/chatgpt-work-usage-and-cost

## OpenAI: how data is used to improve models

Status: checked. Presentation positions: 28, 29.

Inspected 16 September 2026. Consumer training controls, feedback exceptions, and the separate full-environment Codex control were checked. Actual account settings were not inspected.

https://help.openai.com/en/articles/5722486-how-your-data-is-used-to-improve-model-performance

## OpenAI: chat and file retention

Status: dated. Presentation positions: 28, 29.

Presentation checked 9 September 2026. Retention table is dated; security/legal and de-identification exceptions apply.

https://help.openai.com/en/articles/8983778-chat-and-file-retention-policies-in-chatgpt

## OpenAI: Temporary Chat

Status: dated. Presentation positions: 29.

Presentation checked 9 September 2026. Temporary status, saving and feature behaviour must be checked in the actual account.

https://help.openai.com/en/articles/8914046-temporary-chat-faq

## OpenAI: enterprise privacy

Status: dated. Presentation positions: 29.

Presentation checked 9 September 2026. Institutional approval and account configuration are not established by this website.

https://openai.com/enterprise-privacy/

## OpenAI: API data controls

Status: checked. Presentation positions: 29, 31.

Inspected 16 September 2026. Abuse logs and application state are different. Approved ZDR is scope-dependent; ineligible features and safety/legal/model exceptions remain.

https://developers.openai.com/api/docs/guides/your-data

## OpenAI: connected-service data handling

Status: dated. Presentation positions: 28, 31.

Presentation checked 9 September 2026. Connected services have separate access and retention rules.

https://learn.chatgpt.com/docs/enterprise/apps-and-connectors#understand-data-flow-and-security

## Anthropic: consumer retention

Status: checked. Presentation positions: 30.

Article dated 1 July 2026, inspected 16 September. Account consent, deletion, training copies and exceptions are distinct.

https://privacy.claude.com/en/articles/10023548-how-long-do-you-store-my-data

## Anthropic: commercial model training

Status: dated. Presentation positions: 30.

Presentation checked 9 September 2026. No training by default; sharing/feedback exceptions retained.

https://privacy.claude.com/en/articles/7996868-is-my-data-used-for-model-training

## Anthropic: commercial retention

Status: dated. Presentation positions: 30.

Presentation checked 9 September 2026. Standard API deletion, saved conversations and exceptions remain separate.

https://privacy.claude.com/en/articles/7996866-how-long-do-you-store-my-organization-s-data

## Anthropic: incognito chats

Status: dated. Presentation positions: 30.

Presentation checked 9 September 2026. Organisation controls and stated exceptions apply.

https://support.claude.com/en/articles/12260368-use-incognito-chats

## Anthropic: Enterprise retention controls

Status: dated. Presentation positions: 30.

Presentation checked 9 September 2026. Default indefinite; custom minimum 30 days in that source. Not separately reverified.

https://privacy.claude.com/en/articles/10440198-configure-custom-data-retention-controls-for-enterprise-plans

## Anthropic: ZDR coverage

Status: checked. Presentation positions: 30, 31.

Inspected 16 September 2026. Eligible approved API paths and Claude Code Enterprise, not ordinary chat/Cowork; classifier outputs and legal/safety restrictions remain.

https://privacy.claude.com/en/articles/8956058-i-have-a-zero-data-retention-agreement-with-anthropic-what-products-does-it-apply-to

## Anthropic: covered-model retention

Status: limited. Presentation positions: 30, 31.

Official article dated 9 July 2026, inspected 16 September. It requires 30-day retention for designated covered models on affected ZDR paths, with flagged-content and legal exceptions. The notice-based exemption in the original presentation was not confirmed by this retrieved text. Check the actual agreement.

https://privacy.claude.com/en/articles/15425996-data-retention-practices-for-covered-models

## Cossarizza et al.: flow cytometry guidelines, third edition

Status: dated. Presentation positions: 32, 33, 35.

European Journal of Immunology 51 (2021), 2708 to 3145. Methodological reference supplied in slide notes, not the workshop dataset; not reread in full for this website build.

https://doi.org/10.1002/eji.202170126

## FlowIO: FCS reading and writing

Status: dated. Presentation positions: 32, 33, 35.

Referenced by the presentation for a future selected FCS dataset. This site does not execute FlowIO or assert an installed version.

https://github.com/whitews/FlowIO

## Elsevier: generative AI policies for journals

Status: checked. Presentation positions: 4, 38, 39.

Policy states updated June 2026; inspected 16 September 2026. Category-specific permissions, disclosure, peer-review confidentiality and exceptions retained. Check the target journal before submission.

https://www.elsevier.com/about/policies-and-standards/generative-ai-policies-for-journals

## Nature: building and exporting figure panels

Status: dated. Presentation positions: 45 to 50.

Appendix states checked 15 September 2026. Reported production checks are presentation claims, not rerun here.

https://research-figure-guide.nature.com/figures/building-and-exporting-figure-panels/

## Nature: figure specifications

Status: dated. Presentation positions: 45 to 50.

Appendix checked 15 September 2026. The selected 183 mm production profile is source-specific, not a guarantee of journal acceptance.

https://research-figure-guide.nature.com/figures/preparing-figures-our-specifications/

## SciPy: paired t-test

Status: dated. Presentation positions: 45.

Implementation reference in the supplied retrospective plan. Slide notes report SciPy 1.17.1 in that run; the browser does not run that environment.

https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.ttest_rel.html

## statsmodels: multiple-testing correction

Status: dated. Presentation positions: 45.

Implementation reference in supplied plan; explicit method=holm over exactly two tests. Slide notes report statsmodels 0.14.6.

https://www.statsmodels.org/stable/generated/statsmodels.stats.multitest.multipletests.html

## PubMed: Nature news metadata

Status: checked. Presentation positions: 3.

Metadata inspected 16 September 2026: news title, Kaia Glickman, DOI and the cited preprint. The September 2026 print issue is not the 20 August online date reported in the presentation.

https://pubmed.ncbi.nlm.nih.gov/42625041/

