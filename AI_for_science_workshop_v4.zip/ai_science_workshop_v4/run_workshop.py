"""Start the shared workshop on a trusted network. No hosting is performed."""
import argparse, os, socket
from pathlib import Path
import uvicorn
if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--host', default='127.0.0.1', help='Use 0.0.0.0 only on a trusted workshop network.')
    parser.add_argument('--port', type=int, default=4173)
    args=parser.parse_args()
    from room_app import KEY_FILE
    print(f'\nParticipant page: http://localhost:{args.port}/room/')
    print(f'Facilitator server key: {KEY_FILE}')
    print('Open that local text file to create a room. Do not give the key to participants.')
    if args.host=='0.0.0.0':
        print('Network access enabled. Share the computer LAN address, not localhost.')
        print('Use only non-sensitive exercise content. Public hosting requires HTTPS and access controls.')
    uvicorn.run('room_app:app',host=args.host,port=args.port,workers=1,proxy_headers=False)
