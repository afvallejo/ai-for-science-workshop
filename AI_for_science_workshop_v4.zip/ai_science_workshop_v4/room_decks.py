"""Bounded single-slide PowerPoint intake and editable Open XML package merge.
No Office process, macro execution, network fetch, or archive extraction is used.
This is a workshop-format validator, not a malware scanner.
"""
from __future__ import annotations
from io import BytesIO
import posixpath
import re
from zipfile import ZipFile, ZIP_DEFLATED, BadZipFile
from lxml import etree as E
from PIL import Image

P = 'http://schemas.openxmlformats.org/presentationml/2006/main'
A = 'http://schemas.openxmlformats.org/drawingml/2006/main'
R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
PKG = 'http://schemas.openxmlformats.org/package/2006/relationships'
CT = 'http://schemas.openxmlformats.org/package/2006/content-types'
W, H = 12192000, 6858000
MAX_PPTX = 8 * 1024 * 1024
MAX_PNG = 3 * 1024 * 1024
PPTX_MIME = 'application/vnd.openxmlformats-officedocument.presentationml.presentation'

class DeckError(ValueError):
    pass

def xml(data: bytes):
    if b'<!DOCTYPE' in data.upper() or b'<!ENTITY' in data.upper():
        raise DeckError('XML document types and entities are not accepted.')
    try:
        return E.fromstring(data, E.XMLParser(resolve_entities=False, no_network=True, huge_tree=False))
    except E.XMLSyntaxError as exc:
        raise DeckError('The PowerPoint contains malformed XML.') from exc

def serial(root) -> bytes:
    return E.tostring(root, encoding='UTF-8', xml_declaration=True, standalone=True)

def source_part(rels_path: str) -> str:
    if rels_path == '_rels/.rels':
        return ''
    folder, leaf = rels_path.rsplit('/_rels/', 1)
    return folder + '/' + leaf[:-5]

def resolve(part: str, target: str) -> str:
    if '\\' in target or '\x00' in target or re.search(r'^[a-zA-Z]+:', target):
        raise DeckError('Unsupported package relationship.')
    name = posixpath.normpath(target.lstrip('/') if target.startswith('/') else posixpath.join(posixpath.dirname(part), target))
    if name.startswith('../') or name == '..':
        raise DeckError('Package relationship escapes the presentation.')
    return name

def skip(name: str) -> bool:
    s = name.lower()
    return s.startswith('docprops/') or any(x in s for x in ['/notesslides/', '/notesmasters/', '/comments/', '/commentauthors', '/persons/'])

def unzip(data: bytes) -> dict[str, bytes]:
    if not data or len(data) > MAX_PPTX:
        raise DeckError('Use a .pptx of at most 8 MB.')
    try:
        with ZipFile(BytesIO(data)) as z:
            infos = [i for i in z.infolist() if not i.is_dir()]
            if len(infos) > 400 or sum(i.file_size for i in infos) > 40*1024*1024:
                raise DeckError('The unpacked presentation is too large or complex.')
            names = set()
            for i in infos:
                n = i.filename
                if n in names or n.startswith('/') or '\\' in n or '\x00' in n or '..' in n.split('/') or posixpath.normpath(n) != n:
                    raise DeckError('Invalid or duplicate archive paths.')
                names.add(n)
                if i.flag_bits & 1 or i.file_size > 8*1024*1024 or i.file_size / max(1, i.compress_size) > 300:
                    raise DeckError('Encrypted or excessively compressed files are not accepted.')
            return {i.filename: z.read(i) for i in infos}
    except (BadZipFile, RuntimeError, NotImplementedError) as exc:
        raise DeckError('This is not a readable .pptx file. Save it again in PowerPoint.') from exc

def zip_parts(parts: dict[str, bytes]) -> bytes:
    stream = BytesIO()
    with ZipFile(stream, 'w', ZIP_DEFLATED) as z:
        for name, data in parts.items():
            z.writestr(name, data)
    return stream.getvalue()

def validate_and_clean(data: bytes) -> tuple[bytes, str]:
    parts = unzip(data)
    for needed in ['[Content_Types].xml', '_rels/.rels', 'ppt/presentation.xml', 'ppt/_rels/presentation.xml.rels']:
        if needed not in parts:
            raise DeckError('Save the file as a standard PowerPoint presentation (.pptx).')
    for name, blob in parts.items():
        low = name.lower()
        if any(x in low for x in ['vbaproject', 'activex', '/embeddings/', '/charts/', '/fonts/', '/diagrams/', 'customxml/', '_xmlsignatures/']):
            raise DeckError('Use text, shapes and embedded PNG/JPEG images only. Remove macros, charts, SmartArt, embedded files and embedded fonts.')
        if '/media/' in low and not low.endswith(('.png', '.jpg', '.jpeg')):
            raise DeckError('Use embedded PNG or JPEG images only. Remove other media formats.')
        if low.endswith(('.xml', '.rels')):
            root = xml(blob)
            if root.find('.//{%s}timing' % P) is not None or root.find('.//{%s}transition' % P) is not None:
                raise DeckError('Remove animations and slide transitions for the shared deck.')
    presentation = xml(parts['ppt/presentation.xml'])
    if presentation.tag != '{%s}presentation' % P:
        raise DeckError('Use standard PowerPoint Open XML, not Strict Open XML.')
    ids = presentation.findall('.//{%s}sldId' % P)
    slides = [n for n in parts if re.fullmatch(r'ppt/slides/slide\d+\.xml', n)]
    if len(ids) != 1 or len(slides) != 1:
        raise DeckError('Submit exactly one slide, not the complete workshop deck.')
    size = presentation.find('{%s}sldSz' % P)
    try:
        width = int(size.get('cx', '0')) if size is not None else 0
        height = int(size.get('cy', '0')) if size is not None else 0
    except (TypeError, ValueError):
        raise DeckError('The slide dimensions are invalid.')
    if size is None or abs(width - W) > 6000 or abs(height - H) > 3400:
        raise DeckError('Use PowerPoint Widescreen: 13 1/3 × 7.5 inches (33.867 × 19.05 cm). The downloadable template has this size.')
    rels = xml(parts['ppt/_rels/presentation.xml.rels'])
    sid = ids[0].get('{%s}id' % R)
    matched = [n for n in rels if n.get('Id') == sid and n.get('Type', '').endswith('/slide')]
    if len(matched) != 1 or resolve('ppt/presentation.xml', matched[0].get('Target', '')) != slides[0]:
        raise DeckError('The presentation slide reference is invalid.')
    cleaned = {}
    for name, blob in parts.items():
        if skip(name):
            continue
        if name.endswith('.rels'):
            root = xml(blob)
            if root.tag != '{%s}Relationships' % PKG:
                raise DeckError('Invalid relationships file.')
            seen = set()
            for rel in list(root):
                if rel.get('Id') in seen:
                    raise DeckError('Duplicate relationship identifiers.')
                seen.add(rel.get('Id'))
                if rel.get('TargetMode') == 'External':
                    if rel.get('Type', '').endswith('/hyperlink'):
                        root.remove(rel)
                        continue
                    raise DeckError('External linked content is not accepted. Embed images and remove links to files.')
                target = resolve(source_part(name), rel.get('Target', ''))
                if skip(target):
                    root.remove(rel)
                elif target not in parts:
                    raise DeckError('A presentation attachment or relationship is missing.')
            blob = serial(root)
        elif name.endswith('.xml'):
            root = xml(blob)
            if name == '[Content_Types].xml':
                for child in list(root):
                    if skip(child.get('PartName', '').lstrip('/')):
                        root.remove(child)
                    if 'macroEnabled' in child.get('ContentType', ''):
                        raise DeckError('Macro-enabled files are not accepted.')
            # Remove notes, comments and clickable hyperlinks from the shared copy.
            for el in list(root.iter()):
                if isinstance(el.tag, str) and E.QName(el).localname in ('notesMasterIdLst', 'hlinkClick', 'hlinkMouseOver', 'cmLst', 'cmAuthorLst', 'custDataLst'):
                    if el.getparent() is not None:
                        el.getparent().remove(el)
            blob = serial(root)
        cleaned[name] = blob
    texts = xml(cleaned[slides[0]]).findall('.//{%s}t' % A)
    text = ' '.join(t.text or '' for t in texts).strip()
    return zip_parts(cleaned), text[:6000]

def clean_png(data: bytes) -> bytes:
    if len(data) > MAX_PNG:
        raise DeckError('The optional PNG preview must be at most 3 MB.')
    try:
        with Image.open(BytesIO(data)) as im:
            if im.format != 'PNG' or not (320 <= im.width <= 4096 and 180 <= im.height <= 2304) or abs(im.width / im.height - 16/9) > .03:
                raise DeckError('Use a 16:9 PNG preview between 320 × 180 and 4096 × 2304 pixels.')
            im.load()
            out = BytesIO()
            im.convert('RGB').save(out, format='PNG', optimize=True)
            return out.getvalue()
    except (OSError, Image.DecompressionBombError) as exc:
        raise DeckError('The preview is not a readable PNG image.') from exc

def merge_decks(inputs: list[bytes]) -> bytes:
    """Combine supported single-slide files, keeping native text/shapes/images.
    Each source package is namespaced. All internal relationship targets and
    content-type paths are rewritten, retaining each source master and layout.
    """
    if not 1 <= len(inputs) <= 60:
        raise DeckError('Choose between 1 and 60 slides.')
    if sum(map(len, inputs)) > 120*1024*1024:
        raise DeckError('The selected decks exceed 120 MB. Export fewer slides at a time.')
    out = {}
    types = E.Element('{%s}Types' % CT, nsmap={None: CT})
    E.SubElement(types, '{%s}Default' % CT, Extension='rels', ContentType='application/vnd.openxmlformats-package.relationships+xml')
    presentation = E.Element('{%s}presentation' % P, nsmap={'a': A, 'r': R, 'p': P})
    masters = E.SubElement(presentation, '{%s}sldMasterIdLst' % P)
    slides = E.SubElement(presentation, '{%s}sldIdLst' % P)
    prels = E.Element('{%s}Relationships' % PKG, nsmap={None: PKG})
    master_index = 0
    for ix, data in enumerate(inputs, 1):
        cleaned, _ = validate_and_clean(data)
        src = unzip(cleaned)
        prefix = f'ppt/room{ix}/'
        stypes = xml(src['[Content_Types].xml'])
        defaults = {e.get('Extension'): e.get('ContentType') for e in stypes if isinstance(e.tag, str) and E.QName(e).localname == 'Default'}
        overrides = {e.get('PartName').lstrip('/'): e.get('ContentType') for e in stypes if isinstance(e.tag, str) and E.QName(e).localname == 'Override'}
        omitted = {'[Content_Types].xml', '_rels/.rels', 'ppt/presentation.xml', 'ppt/_rels/presentation.xml.rels'}
        for name, blob in src.items():
            if name in omitted:
                continue
            newname = prefix + name
            if name.endswith('.rels'):
                root = xml(blob)
                for rel in list(root):
                    target = resolve(source_part(name), rel.get('Target', ''))
                    if target in omitted:
                        root.remove(rel)
                    else:
                        rel.set('Target', '/' + prefix + target)
                blob = serial(root)
            else:
                ctype = overrides.get(name) or defaults.get(name.rsplit('.', 1)[-1])
                if not ctype:
                    raise DeckError('A file content type is missing.')
                E.SubElement(types, '{%s}Override' % CT, PartName='/' + newname, ContentType=ctype)
            out[newname] = blob
        for rel in xml(src['ppt/_rels/presentation.xml.rels']):
            typ = rel.get('Type', '')
            if typ.endswith('/slide'):
                rid = f'rIdSlide{ix}'
                E.SubElement(prels, '{%s}Relationship' % PKG, Id=rid, Type=R+'/slide', Target='/'+prefix+resolve('ppt/presentation.xml', rel.get('Target')))
                node = E.SubElement(slides, '{%s}sldId' % P, id=str(255+ix))
                node.set('{%s}id' % R, rid)
            elif typ.endswith('/slideMaster'):
                master_index += 1
                rid = f'rIdMaster{master_index}'
                E.SubElement(prels, '{%s}Relationship' % PKG, Id=rid, Type=R+'/slideMaster', Target='/'+prefix+resolve('ppt/presentation.xml', rel.get('Target')))
                node = E.SubElement(masters, '{%s}sldMasterId' % P, id=str(2147483647+master_index))
                node.set('{%s}id' % R, rid)
    E.SubElement(presentation, '{%s}sldSz' % P, cx=str(W), cy=str(H), type='screen16x9')
    E.SubElement(presentation, '{%s}notesSz' % P, cx='6858000', cy='9144000')
    E.SubElement(presentation, '{%s}defaultTextStyle' % P)
    rootrels = E.Element('{%s}Relationships' % PKG, nsmap={None: PKG})
    E.SubElement(rootrels, '{%s}Relationship' % PKG, Id='rId1', Type=R+'/officeDocument', Target='ppt/presentation.xml')
    E.SubElement(types, '{%s}Override' % CT, PartName='/ppt/presentation.xml', ContentType='application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml')
    out.update({'[Content_Types].xml': serial(types), '_rels/.rels': serial(rootrels), 'ppt/presentation.xml': serial(presentation), 'ppt/_rels/presentation.xml.rels': serial(prels)})
    return zip_parts(out)
