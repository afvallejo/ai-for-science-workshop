# Codex for science: one dataset, three workflows

## Goal
Create a figure that is scientifically defensible, readable and reproducible.
Compare the resulting work, not the confidence of the assistant's answer.
The dataset is entirely synthetic. No real study data are needed.

## Your three projects
| Project | What changes |
| --- | --- |
| round_A | Basic prompt; no workshop-supplied figure skill. |
| round_B | The same basic task, plus the science-figure skill. |
| round_C | The same task and skill, plus an explicit bounded review loop. |

The data and study context are identical in all three projects. The skill
in B and C is identical. Open ONE round folder as a project, not this entire
participant pack or a folder containing instructor materials. Start a new
thread for each round. Never copy an earlier figure, code or conversation
into a later project. Each round must start from the original inputs.

Use the same available model, reasoning setting, tool permissions and
software environment throughout. Record these in run_log.csv. Any differences
between attendees' environments should be acknowledged in the comparison.
Keep approval safeguards in place. Do not provide access to unrelated files,
credentials, real patient data or external services.

## Before the session
Verify that Codex can execute Python and use your installed plotting library.
This pack is designed for a local Python environment with matplotlib; CSV
handling and the instructor checker can use the Python standard library.
There is no need to install packages or fetch biological data during the
exercise. The facilitator should establish the same working environment
before timing begins. If your group uses R, standardise it for all three
rounds and record the change; the numeric CSV checks remain applicable.

Global instructions and pre-existing skills may affect the baseline.
Disclose them to the facilitator. Do not install the workshop figure skill
in a global skills folder, where it could leak into A. Do not delete unrelated
personal configuration. A clean dedicated workshop profile is preferable
when the facilitator has tested one in advance.

## During each round
Open the selected round folder, create a fresh thread and paste PROMPT.txt.
For B and C, explicitly select the science-figure skill in the available
skill picker when possible. The prompt also names its exact local path,
so its instructions can be read directly. Record whether the skill was
recognised and loaded as a skill or only read as a file; do not silently
count an unrecognised skill as successfully activated.

Submit once. Normal agent tool calls, debugging and self-checks are allowed
in every round. Do not provide extra coaching or revisions during A and B.
C's loop is already in its prompt. Handle only essential execution or
approval questions during generation, and record human interventions.

Do not ask the assistant to make the result more significant. Do not keep
rerunning a condition to obtain a preferred outcome. Keep the first completed
run, plus any documented technical failure. Record elapsed time, human
interventions and available usage information. Do not estimate missing tokens.

Open the saved figure yourself. Compare it with the study context, source
data and saved code. Use SCORECARD.md after generation. A good-looking plot
with incorrect sample size or units does not pass scientific review.

For C, inspect the iteration log and the actual archived figure versions.
Check whether the claimed fixes occurred. NOT VERIFIED is an honest status,
not a successful check. Finishing after the initial version is valid when
all checks actually pass; extra cosmetic iterations are not a goal.

## Comparison
Exchange anonymised outputs with another pair. Hide condition names and
iteration logs until the figure and caption have been scored; then examine
code and provenance. Use arbitrary display labels rather than A, B and C.
Only conceal the workflow label, never the synthetic-data notice or methods.
Record scores before revealing which workflow produced the output.

There is no guaranteed winner. A may already be good, and C may add time
without improving quality. The exercise compares these particular workflows
in your environment, not a universal ranking of models or proof that skills
or self-review always improve scientific work.
