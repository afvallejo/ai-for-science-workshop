---
name: science-figure
description: Create reproducible scientific figures from tabular experimental data and study metadata, preserving replication, pairing, units and transparent reporting.
---

# Scientific figure workflow

Use the supplied study context as the source of truth. This skill defines
quality requirements, not a preferred scientific result or a fixed plot type.
Do not add literature claims or an analysis that the task does not request.

## Understand and calculate
Read the data and study metadata before choosing a figure. Identify the
question, endpoint, units, experimental unit, biological replication,
repeated measurements, pairing, factors and intended contrasts. Inspect
schema, missingness, duplicate keys, valid ranges and group sizes. Do not
invent missing experimental facts. Report any consequential ambiguity.

Preserve the input files. Apply the stated aggregation of technical
measurements before across-biological-unit summaries. Preserve matching
by identifiers, not row order. Do not treat cells, aliquots or repeated
measurements as extra biological replicates. Keep each requested factor
and comparison identifiable. Distinguish percentage points from percentage
change. Never remove an observation merely because it weakens a pattern.

Use the project's available plotting environment. Compute every plotted
quantity from the supplied data in saved executable code. Prefer established
scientific plotting libraries. Do not use generative image tools for data
marks, axes, statistical annotations or other quantitative evidence.

## Design
Choose an encoding that makes the scientific comparison easy to read.
Show individual biological-unit values for small samples and make paired
comparisons visible, through linked observations or within-unit contrasts.
Technical observations may be added only with unambiguous visual distinction.
Do not hide all biological variation behind summary bars.

Define all summaries and error bars. Calculate variability and uncertainty at
the appropriate biological level. SD, SEM and confidence intervals are not
interchangeable. Do not add hypothesis tests or significance decorations
unless requested and justified for the actual design.

Use readable labels, explicit units, concise panel titles and consistent
encodings. Use restrained visual styling, sufficient contrast, and labels
or symbols that do not depend solely on colour. Do not distort axes or
clip observations to exaggerate effects. Zero is required for magnitude-
encoding bars; other axes must be appropriate and transparently labelled.
Choose and record a physical figure size. Check text and marks at that size,
not just when zoomed in. Avoid decorative effects and overlapping labels.

## Deliver and verify
Export the requested PDF and PNG from the same code. Include plotted data,
a caption and a regeneration command with the environment versions. Keep
paths portable. Seed any stochastic display operation and keep data values
unchanged. The caption must explain the endpoint and parent denominator,
biological n, technical replication, pairing, aggregation, units, any
summary/error bars and the synthetic status when applicable.

Run the code. Check resulting counts and plotted values against the inputs.
Open the rendered image and inspect labels, marks, legends, clipping and
readability. If image inspection is unavailable, say so explicitly. Do not
claim a visual review based only on inspecting code. Report what was actually
verified and any unresolved issues; do not claim manuscript acceptance.

## Acceptance criteria
- Data and labels match the original inputs; no unjustified exclusions.
- Replication, aggregation, pairing, units and comparisons match the study.
- Individual biological variation and the intended contrasts are readable.
- Labels, legends and marks are legible at the stated size, with no clipping.
- The saved code regenerates the outputs from unchanged input files.
- The caption and source-data table accurately explain the figure.

Normal debugging and verification are part of this workflow. An explicit
bounded revision protocol, version archive or iteration log is added only
when requested; do not invent a requirement for repeated cosmetic changes.
