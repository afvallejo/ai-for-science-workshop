# Human figure review scorecard

Reviewer: __________   Blind figure label: __________
Review the figure and caption first, then the code and source-data table.
Do not use the assistant's self-score as your score.

Score each domain: 0 = absent or wrong; 1 = partly satisfied or not fully
verified; 2 = satisfied with evidence. Record a concrete issue or file.

| Domain | Full-credit evidence | Score 0, 1 or 2 | Evidence or issue |
| --- | --- | --- | --- |
| Scientific integrity | Correct culture means; n = 10 donors per condition; correct units and CD8 parent; complete data retained; correct contrasts and no invented results. | | |
| Communication of the design | Donor-level variation is visible; pairing is apparent through links or donor-level contrasts; stimulation conditions and treatment comparisons are distinguishable. | | |
| Visual quality | Text and marks are readable at the stated size; nothing clipped; useful labels and legend; restrained, accessible encodings; no misleading axes. | | |
| Reproducibility | Saved script successfully regenerates the results in a fresh output directory from unchanged inputs; source-data values agree; command and versions provided. | | |
| Reporting | Legend defines synthetic status, endpoint, parent denominator, biological n, technical replication, aggregation, pairing, summaries and any error bars. | | |

Total: ____ / 10. This is a teaching rubric, not a validated measurement scale.

## Scientific and reproducibility gates
Mark NOT READY FOR MANUSCRIPT when there is a material scientific error:
wrong denominator or scaling; technical measurements presented as biological
replicates; incorrect pairing in a contrast; silently changed or excluded
values; invented p values, significance or biological conclusions. A high
visual score cannot compensate for these errors.

Separately mark REPRODUCIBILITY NOT VERIFIED when rerunning the saved code
has not been demonstrated. A present script is not the same as a working one.
A missing output schema needs investigation, not automatic rejection of an
otherwise scientifically valid figure. No figure is publication-ready merely
because it passes this local rubric.

Scientific gate: PASS / FAIL / NOT VERIFIED
Regeneration: PASS / FAIL / NOT VERIFIED
One most consequential correction needed: _____________________________

## After unblinding
Was the supplied skill actually read? _________________________________
How many figure versions and review cycles actually occurred? __________
Did the loop fix a documented issue, add only cosmetics, or introduce one?
______________________________________________________________________
Time and human interventions: _________________________________________
Would you accept the figure unchanged? Why or why not? __________________
