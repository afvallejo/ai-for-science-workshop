# Prompts

Use each prompt in its own fresh project and thread. Do not paste the entire
file into a single thread. The task wording is identical across conditions.

## A. Basic prompt, no supplied figure skill

```text
Use data.csv and study_context.md to create a publication-quality figure
showing how treatment affects CD8 T-cell activation, with and without
stimulation. Save the figure as PDF and PNG, the plotted data as CSV,
the plotting code, and a figure legend in outputs/.
```

## B. Skill and the same basic task

```text
Use the science-figure skill at .agents/skills/science-figure/SKILL.md.

Use data.csv and study_context.md to create a publication-quality figure
showing how treatment affects CD8 T-cell activation, with and without
stimulation. Save the figure as PDF and PNG, the plotted data as CSV,
the plotting code, and a figure legend in outputs/.
```

## C. Skill and bounded review loop

```text
Use the science-figure skill at .agents/skills/science-figure/SKILL.md.

Use data.csv and study_context.md to create a publication-quality figure
showing how treatment affects CD8 T-cell activation, with and without
stimulation. Save the figure as PDF and PNG, the plotted data as CSV,
the plotting code, and a figure legend in outputs/.

Use the acceptance criteria in the skill and study_context.md. Complete a
bounded create, inspect, revise loop, with an initial version and no more
than two revision passes (three rendered versions in total).

1. Create and run the plotting code. Preserve the initial outputs in
   outputs/iterations/v1/ before making revisions.
2. Inspect the actual rendered image at its intended publication size.
   Check the source data, aggregation, pairing, units, labels and caption.
   Run numerical checks and test the regeneration command in a clean
   output directory. Do not treat code inspection as visual inspection.
3. For each acceptance criterion, record PASS, FAIL or NOT VERIFIED,
   with concrete evidence such as a file, command result or observed
   visual issue. Prioritise scientific errors, then reproducibility,
   then visual presentation.
4. Fix identified problems in the code, not by editing the figure
   manually. Save each revised version separately, re-render it, and
   repeat the checks. Check that a fix has not introduced a new error.
5. Stop early when all criteria pass, or stop after the third rendered
   version. If a required tool is unavailable or a blocker remains,
   stop and report the limitation rather than claiming success.

Do not manufacture faults to justify another iteration. Do not alter the
input data, silently exclude observations, change the study question,
weaken checks or invent results to obtain a pass. Correct a scientifically
wrong analysis decision when necessary and explain the correction. Keep
correct analysis choices fixed during purely visual revisions.

Save iteration_log.md with the issues, changes, evidence, remaining
limitations and reason for stopping. Put the final deliverables directly
in outputs/. Report which checks were executed, which were only inspected,
and which still require human review. A self-assigned PASS is not
independent validation.
```

Skill selection differs by client. Select the named skill explicitly where
supported. Codex CLI and IDE clients document `$science-figure` mentions;
ChatGPT clients document `@` selection. The file-path wording above also makes
the requested instructions explicit. Verify loading rather than assuming a
particular UI shortcut works in every installed version.
