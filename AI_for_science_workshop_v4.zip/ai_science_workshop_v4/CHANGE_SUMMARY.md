# Version 4 changes

Added a guided Plan mode interview, reviewed brief, genuine-computer-use creation prompt and separately approved sharing prompt. Added the participant room page, shared SQLite-backed uploads, validation, authentic receipts, replacement and withdrawal, facilitator management, gallery, native editable PowerPoint combination and source ZIP export. Added a one-slide template and automated tests.

The existing course is retained with a navigation link and home-page card to the new exercise. All 16 original practical downloads remain byte-identical. Original teaching content, data, prompts, skills, scorecards and progress logic have not been rewritten.

Runtime: Python ASGI server with persistent SQLite. The original static server remains available only for previews. No deployment was performed. See README.md, ROOM_TEST_REPORT.md and SITES_HANDOFF.md. Historical version 3 notes are retained separately.
