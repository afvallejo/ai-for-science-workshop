"""AI for science shared-room server. Single ASGI instance + durable SQLite.
Run: python run_workshop.py. Application data must never be publicly served.
"""
from __future__ import annotations
import hashlib, hmac, io, json, os, re, secrets, sqlite3, threading, time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from starlette.concurrency import run_in_threadpool
from room_decks import validate_and_clean, clean_png, merge_decks, DeckError, PPTX_MIME, MAX_PPTX, MAX_PNG

ROOT = Path(__file__).resolve().parent
DATA = Path(os.environ.get('WORKSHOP_DATA', str(ROOT / '.room-data'))).resolve()
DATA.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA / 'rooms.sqlite3'
KEY_FILE = DATA / 'facilitator-key.txt'
if os.environ.get('WORKSHOP_HOST_KEY'):
    HOST_KEY = os.environ['WORKSHOP_HOST_KEY']
else:
    if not KEY_FILE.exists():
        KEY_FILE.write_text(secrets.token_urlsafe(32), encoding='utf-8')
        try: KEY_FILE.chmod(0o600)
        except OSError: pass
    HOST_KEY = KEY_FILE.read_text(encoding='utf-8').strip()
if len(HOST_KEY) < 24:
    raise RuntimeError('WORKSHOP_HOST_KEY must contain at least 24 random characters.')

@contextmanager
def db():
    con = sqlite3.connect(DB_PATH, timeout=30)
    con.row_factory = sqlite3.Row
    con.execute('PRAGMA foreign_keys=ON')
    try:
        yield con
        con.commit()
    finally:
        con.close()

with db() as c:
    c.execute('PRAGMA journal_mode=WAL')
    c.executescript('''
    CREATE TABLE IF NOT EXISTS rooms (
      code TEXT PRIMARY KEY, title TEXT NOT NULL, owner_hash TEXT NOT NULL,
      created TEXT NOT NULL, accepting INTEGER NOT NULL DEFAULT 1);
    CREATE TABLE IF NOT EXISTS submissions (
      id TEXT PRIMARY KEY, room TEXT NOT NULL REFERENCES rooms(code) ON DELETE CASCADE,
      participant_hash TEXT NOT NULL, alias TEXT NOT NULL, title TEXT NOT NULL,
      theme TEXT NOT NULL, method TEXT NOT NULL, created TEXT NOT NULL,
      included INTEGER NOT NULL DEFAULT 1, position INTEGER NOT NULL,
      sha256 TEXT NOT NULL, deck BLOB NOT NULL, preview BLOB, slide_text TEXT NOT NULL,
      UNIQUE(room, participant_hash));
    CREATE INDEX IF NOT EXISTS by_room ON submissions(room, position, created);
    ''')

app = FastAPI(title='AI for science workshop room', docs_url=None, redoc_url=None, openapi_url=None)

class BodyLimit(Exception): pass
class LimitedBody:
    def __init__(self, app): self.app = app
    async def __call__(self, scope, receive, send):
        if scope['type'] != 'http':
            return await self.app(scope, receive, send)
        count = 0
        async def bounded_receive():
            nonlocal count
            msg = await receive()
            count += len(msg.get('body', b''))
            if count > 12*1024*1024: raise BodyLimit()
            return msg
        try:
            await self.app(scope, bounded_receive, send)
        except BodyLimit:
            await JSONResponse({'detail':'The total request exceeds 12 MB.'}, status_code=413)(scope, receive, send)
app.add_middleware(LimitedBody)

@app.middleware('http')
async def security(request: Request, call_next):
    if request.method not in ('GET', 'HEAD', 'OPTIONS'):
        origin = request.headers.get('origin')
        if origin and origin != f'{request.url.scheme}://{request.url.netloc}':
            return JSONResponse({'detail':'Cross-origin writes are not allowed.'}, status_code=403)
    res = await call_next(request)
    res.headers['X-Content-Type-Options'] = 'nosniff'
    res.headers['Referrer-Policy'] = 'no-referrer'
    res.headers['X-Frame-Options'] = 'SAMEORIGIN'
    if request.url.path.startswith('/api/'):
        res.headers['Cache-Control'] = 'no-store'
    return res

@app.exception_handler(DeckError)
async def deck_error(request, exc): return JSONResponse({'detail':str(exc)}, status_code=422)

RATE = {}
LOCK = threading.Lock()
def limit(key: str, maximum=30, seconds=60):
    now = time.monotonic()
    with LOCK:
        if len(RATE) > 10000:
            for k in list(RATE):
                if now - RATE[k][0] > 600: del RATE[k]
        start, n = RATE.get(key, (now, 0))
        if now-start > seconds: start, n = now, 0
        if n >= maximum: raise HTTPException(429, 'Too many attempts. Please try again after one minute.')
        RATE[key] = (start, n+1)

def digest(value: str) -> str: return hashlib.sha256(value.encode()).hexdigest()
def now() -> str: return datetime.now(timezone.utc).isoformat()
async def object_body(req: Request):
    try: data = await req.json()
    except (ValueError, UnicodeDecodeError): raise HTTPException(422, 'Send a valid JSON object.')
    if not isinstance(data, dict): raise HTTPException(422, 'Send a JSON object, not a list or scalar.')
    return data
def text(value, label, maximum, required=True):
    if not isinstance(value, str): raise HTTPException(422, f'{label} must be text.')
    value = value.strip()
    if (required and not value) or len(value) > maximum or any(ord(x)<32 and x not in '\n\t' for x in value):
        raise HTTPException(422, f'{label} is required and must be at most {maximum} characters.')
    return value

def room_for(code):
    if not re.fullmatch('[A-Z2-9]{8}', code): raise HTTPException(404, 'Room not found. Check the eight-character room code.')
    with db() as c: row = c.execute('SELECT * FROM rooms WHERE code=?', (code,)).fetchone()
    if not row: raise HTTPException(404, 'Room not found. Check the room code or ask the facilitator.')
    return row

def bearer(req): return req.headers.get('authorization','').removeprefix('Bearer ')
def is_owner(req, room): return hmac.compare_digest(digest(bearer(req)), room['owner_hash'])
def owner(req, room):
    if not is_owner(req, room): raise HTTPException(403, 'A valid facilitator room key is required.')

def public_row(row):
    return {k:row[k] for k in ('id','alias','title','theme','method','created','included','position','sha256','slide_text')} | {'has_preview':bool(row['preview'])}

@app.get('/api/health')
def health(): return {'status':'ready', 'storage':'server-side SQLite', 'version':'4.0.0', 'max_slides':60}

@app.post('/api/rooms')
async def create_room(req: Request):
    limit('create:'+(req.client.host if req.client else 'unknown'), 12)
    if not hmac.compare_digest(req.headers.get('x-facilitator-key',''), HOST_KEY):
        raise HTTPException(403, 'The server facilitator key is incorrect.')
    data = await object_body(req)
    title = text(data.get('title','AI for science'), 'Room title', 100)
    code = ''.join(secrets.choice('ABCDEFGHJKLMNPQRSTUVWXYZ23456789') for _ in range(8))
    token = secrets.token_urlsafe(32)
    with db() as c:
        if c.execute('SELECT COUNT(*) FROM rooms').fetchone()[0] >= 100:
            raise HTTPException(409, 'Room limit reached. Delete old workshop rooms first.')
        c.execute('INSERT INTO rooms (code,title,owner_hash,created) VALUES (?,?,?,?)', (code,title,digest(token),now()))
    return {'code':code, 'title':title, 'owner_token':token}

@app.get('/api/rooms/{code}')
def get_room(code: str, req: Request):
    room = room_for(code)
    host = is_owner(req,room)
    with db() as c:
        rows = c.execute('SELECT * FROM submissions WHERE room=? ORDER BY position, created', (code,)).fetchall()
    visible = rows if host else [r for r in rows if r['included']]
    return {'code':code,'title':room['title'],'accepting':bool(room['accepting']), 'count':len(visible), 'host':host, 'submissions':[public_row(r) for r in visible]}

@app.patch('/api/rooms/{code}')
async def update_room(code: str, req: Request):
    room = room_for(code); owner(req,room)
    data = await object_body(req)
    if 'accepting' in data and not isinstance(data['accepting'],bool): raise HTTPException(422, 'accepting must be true or false.')
    with db() as c:
        if 'accepting' in data: c.execute('UPDATE rooms SET accepting=? WHERE code=?', (int(data['accepting']),code))
        if 'order' in data:
            order = data['order']
            actual = {r[0] for r in c.execute('SELECT id FROM submissions WHERE room=?',(code,))}
            if not isinstance(order,list) or not all(isinstance(x,str) for x in order) or len(order)!=len(actual) or set(order)!=actual:
                raise HTTPException(409, 'Room contents changed. Refresh before reordering.')
            for ix, sid in enumerate(order): c.execute('UPDATE submissions SET position=? WHERE id=? AND room=?',(ix,sid,code))
    return {'ok':True}

@app.post('/api/rooms/{code}/submissions')
async def upload(code: str, req: Request):
    room = room_for(code)
    if not room['accepting']: raise HTTPException(409, 'The facilitator has closed submissions.')
    form = await req.form(max_files=2,max_fields=10,max_part_size=1024*1024)
    token = form.get('participant_token','')
    if not isinstance(token,str) or not re.fullmatch('[A-Za-z0-9_-]{24,100}',token): raise HTTPException(422, 'A participant submission key is required.')
    phash = digest(token)
    limit('upload:'+code+phash, 10)
    if form.get('consent') != 'yes': raise HTTPException(422, 'Review and explicitly approve room sharing first.')
    alias = text(form.get('alias',''), 'Display name or alias', 60)
    title = text(form.get('title',''), 'Idea title', 100)
    theme = text(form.get('theme','Other'), 'Theme', 40)
    method = form.get('method','')
    if method not in ('Computer use','Manual fallback'): raise HTTPException(422, 'Choose how the slide was created.')
    file = form.get('deck')
    if not file or not getattr(file,'filename','').lower().endswith('.pptx'): raise HTTPException(422, 'Choose a single-slide .pptx file.')
    raw = await file.read(MAX_PPTX+1)
    cleaned, slide_text = await run_in_threadpool(validate_and_clean, raw)
    preview = form.get('preview')
    png = None
    if preview and getattr(preview,'filename',''):
        png = await run_in_threadpool(clean_png, await preview.read(MAX_PNG+1))
    sha = hashlib.sha256(cleaned).hexdigest()
    stamp = now()
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        current = c.execute('SELECT accepting FROM rooms WHERE code=?',(code,)).fetchone()
        if not current or not current[0]: raise HTTPException(409, 'This room is no longer accepting submissions.')
        old = c.execute('SELECT id,position,included FROM submissions WHERE room=? AND participant_hash=?',(code,phash)).fetchone()
        count = c.execute('SELECT COUNT(*) FROM submissions WHERE room=?',(code,)).fetchone()[0]
        if not old and count>=60: raise HTTPException(409, 'This workshop room is full (60 slides).')
        sid = old['id'] if old else secrets.token_urlsafe(18)
        position = old['position'] if old else c.execute('SELECT COALESCE(MAX(position),-1)+1 FROM submissions WHERE room=?',(code,)).fetchone()[0]
        included = old['included'] if old else 1
        c.execute('''INSERT INTO submissions VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(room,participant_hash) DO UPDATE SET alias=excluded.alias,title=excluded.title,
        theme=excluded.theme,method=excluded.method,created=excluded.created,sha256=excluded.sha256,
        deck=excluded.deck,preview=excluded.preview,slide_text=excluded.slide_text''',
        (sid,code,phash,alias,title,theme,method,stamp,included,position,sha,cleaned,png,slide_text))
    return {'id':sid,'code':code,'created':stamp,'sha256':sha,'replaced':bool(old),'shared':bool(included), 'message':'Slide stored on the workshop server.'}

def submission(code,sid):
    with db() as c: row = c.execute('SELECT * FROM submissions WHERE id=? AND room=?',(sid,code)).fetchone()
    if not row: raise HTTPException(404,'Slide not found.')
    return row

@app.get('/api/rooms/{code}/submissions/{sid}/{kind}')
def get_file(code: str,sid: str,kind: str,req: Request):
    room = room_for(code); row = submission(code,sid)
    if not row['included'] and not is_owner(req,room): raise HTTPException(404,'Slide not found.')
    if kind=='pptx':
        return Response(row['deck'],media_type=PPTX_MIME,headers={'Content-Disposition':f'attachment; filename="workshop_{sid}.pptx"'})
    if kind=='png' and row['preview']:
        return Response(row['preview'],media_type='image/png')
    raise HTTPException(404,'Preview not supplied.')

@app.patch('/api/rooms/{code}/submissions/{sid}')
async def moderate(code: str,sid: str,req: Request):
    room=room_for(code); owner(req,room); submission(code,sid)
    data=await object_body(req)
    if not isinstance(data.get('included'),bool): raise HTTPException(422,'included must be true or false.')
    with db() as c: c.execute('UPDATE submissions SET included=? WHERE room=? AND id=?',(int(data['included']),code,sid))
    return {'ok':True}

@app.delete('/api/rooms/{code}/submissions/{sid}')
def remove_submission(code: str,sid: str,req: Request):
    room=room_for(code); row=submission(code,sid)
    token=req.headers.get('x-participant-token','')
    if not is_owner(req,room) and not hmac.compare_digest(digest(token),row['participant_hash']):
        raise HTTPException(403,'Use the same browser or your saved participant key to withdraw this slide.')
    with db() as c: c.execute('DELETE FROM submissions WHERE id=? AND room=?',(sid,code))
    return {'ok':True}

@app.get('/api/rooms/{code}/export/{kind}')
def export(code: str,kind: str,req: Request):
    room=room_for(code); owner(req,room)
    limit('export:'+code,8)
    with db() as c: rows=c.execute('SELECT * FROM submissions WHERE room=? AND included=1 ORDER BY position,created',(code,)).fetchall()
    if not rows: raise HTTPException(409,'There are no included slides to export.')
    if kind=='pptx':
        blob=merge_decks([r['deck'] for r in rows])
        return Response(blob,media_type=PPTX_MIME,headers={'Content-Disposition':f'attachment; filename="AI_for_science_{code}.pptx"','X-Slide-Count':str(len(rows))})
    if kind=='zip':
        output=io.BytesIO(); manifest=[]
        with ZipFile(output,'w',ZIP_DEFLATED) as z:
            for i,r in enumerate(rows,1):
                name=f'{i:02d}_{r["id"]}.pptx'
                z.writestr(name,r['deck'])
                if r['preview']: z.writestr(name.replace('.pptx','.png'),r['preview'])
                manifest.append({k:r[k] for k in ('id','alias','title','theme','method','created','sha256')}|{'file':name})
            z.writestr('manifest.json',json.dumps({'room':code,'title':room['title'],'slides':manifest,'note':'Shared copies have notes, comments, document properties and hyperlink actions removed.'},indent=2))
        return Response(output.getvalue(),media_type='application/zip',headers={'Content-Disposition':f'attachment; filename="AI_for_science_{code}_sources.zip"'})
    raise HTTPException(404,'Unknown export format.')

@app.delete('/api/rooms/{code}')
def delete_room(code: str,req: Request):
    room=room_for(code); owner(req,room)
    with db() as c: c.execute('DELETE FROM rooms WHERE code=?',(code,))
    return {'ok':True,'message':'Room and submissions removed from the active database. Downloaded copies are unaffected.'}

app.mount('/',StaticFiles(directory=ROOT/'public',html=True),name='website')
