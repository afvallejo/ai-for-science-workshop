# Review screenshots

Rendered in Chromium from the exact built HTML using Playwright document injection on 16 September 2026. These are website previews, not source figures or an executed Codex analysis.

- homepage.png: desktop, 1440 by 1000 pixels.
- teaching-viewport.png: desktop focused teaching view, 1440 by 1000 pixels.
- mobile-trace-viewport.png: point-tracing topic, 390 by 844 pixels.

Document injection lacks a normal origin, so the screenshots correctly display the storage-unavailable fallback. This is not evidence that hosted browser storage fails.
